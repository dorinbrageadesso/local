package eu.wittgruppe.dias.domain;

import org.apache.commons.lang.builder.ToStringBuilder;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity(name = "Saison")
@Table(name = "saison")
public class Saison implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "AKTKZ")
	private String aktuellKennzeichen = null;

	@Column(name = "GRAPHIK_FARBE")
	private Long graphikFarbe = null;

	@Column(name = "GRAPHIK_ZEICHEN")
	private String graphikZeichen = null;

	@Column(name = "ID")
	private String id = null;

	@Id
	@Column(name = "SAISON")
	private Long saison = null;

	@Column(name = "SAISONBEZ")
	private String saisonBezeichnung = null;

	@Column(name = "SAISONKURZBEZ")
	private String saisonKurzbezeichnung = null;

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public String getAktuellKennzeichen() {
		return aktuellKennzeichen;
	}

	public void setAktuellKennzeichen(String aktuellKennzeichen) {
		this.aktuellKennzeichen = aktuellKennzeichen;
	}

	public Long getGraphikFarbe() {
		return graphikFarbe;
	}

	public void setGraphikFarbe(Long graphikFarbe) {
		this.graphikFarbe = graphikFarbe;
	}

	public String getGraphikZeichen() {
		return graphikZeichen;
	}

	public void setGraphikZeichen(String graphikZeichen) {
		this.graphikZeichen = graphikZeichen;
	}

	public String getId() {
		return id;
	}

	public Long getSaison() {
		return saison;
	}

	public void setSaison(Long saison) {
		this.saison = saison;
	}

	public String getSaisonBezeichnung() {
		return saisonBezeichnung;
	}

	public void setSaisonBezeichnung(String saisonBezeichnung) {
		this.saisonBezeichnung = saisonBezeichnung;
	}

	public String getSaisonKurzbezeichnung() {
		return saisonKurzbezeichnung;
	}

	public void setSaisonKurzbezeichnung(String saisonKurzbezeichnung) {
		this.saisonKurzbezeichnung = saisonKurzbezeichnung;
	}
}

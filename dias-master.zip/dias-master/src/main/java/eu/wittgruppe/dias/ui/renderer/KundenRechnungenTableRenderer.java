package eu.wittgruppe.dias.ui.renderer;

import eu.wittgruppe.dias.bean.GroupableKunderechnungsposition;
import eu.wittgruppe.dias.bean.KunderechnungspositionBean;

import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;

public class KundenRechnungenTableRenderer extends DiasTableBlockCellRenderer {
    
	
	 public KundenRechnungenTableRenderer() {
		 
	 }	
	 public Component getTableCellRendererComponent( 
	        JTable table, Object value, boolean isSelected, boolean hasFocus,
	        int row, int column ) {  
		 
		  	super.getTableCellRendererComponent(table, value, isSelected, hasFocus, 
                  row, column);
	      
	        
	        int prevRow = row - 1 < 0 ? row : row - 1;
	        KunderechnungspositionBean rechPos = ((GroupableKunderechnungsposition)value).getPos();
	        KunderechnungspositionBean prevRechPos = ((GroupableKunderechnungsposition)table.getModel()
													.getValueAt( prevRow, column)).getPos();
	        
	        	        
	        // Hilfsklasse für Formatierungen von Datum 
	        SimpleDateFormat sdfmt = new SimpleDateFormat("dd.MM.yyyy");
	        this.setHorizontalAlignment(SwingConstants.LEFT);
	        
	        switch (column) {
	        // Rechdat
			case 0:				
				this.setText("");				
				if (!rechPos.getRechnungsdatum().equals(prevRechPos.getRechnungsdatum()) || 
					row == 0) {
					this.setText(sdfmt.format(rechPos.getRechnungsdatum().getTime()));				
				}				
				break;
            // Retschl
			case 1:
				this.setText("");
				if (!rechPos.getRetoureschluessel().equals(prevRechPos.getRetoureschluessel()) || 
					row == 0) {
					this.setText(rechPos.getRetoureschluessel().toString());
				}			
				break;			       
	        //Posnr
			case 2:
				this.setText((rechPos.getPositionsnummer() == null ? "" : 
							  rechPos.getPositionsnummer().toString()));				
				break;
//				Artnr6
			case 3:
				this.setText(rechPos.getArtikelnummerWitt().toString());
				break;
//				Promnr
			case 4:
				this.setText(rechPos.getPromotionnummer());
				break;
//				Artgr
			case 5:
				this.setText(rechPos.getArtikelgroesse());
				break;				
//				Artbez
			case 6:
				
				this.setText((rechPos.getArtikelbezeichnung() == null ? "" : 
							  rechPos.getArtikelbezeichnung()));
				break;				
//				Farbe
			case 7:
				this.setText((rechPos.getFarbe() == null ? "" : 
							  rechPos.getFarbe()));
				break;
//				bestmg
			case 8:
				this.setText(rechPos.getBestellmenge().toString());				
				break;	
			// bestellbetrag
			case 9:				
		        this.setHorizontalAlignment(SwingConstants.RIGHT);        
				DecimalFormat fmt = new DecimalFormat("##0.00");
				this.setText(fmt.format((rechPos.getBestellbetrag() == null ? new Double(0.0) : 
					  					 rechPos.getBestellbetrag())));
				break;
//				gurschrmg
			case 10:
				this.setText((rechPos.getGutschriftmenge() == null ? "" : 
							  rechPos.getGutschriftmenge().toString()));
				break;
//				Gutschrkz
			case 11:
				
				//int gutschrkz = (rechPos.getGutschriftkennzeichen() == null ? 0 : 
				//rechPos.getGutschriftkennzeichen().intValue());
				
				//TODO Hier muss noch das Gutschriftskennzeichen (z.B. "1,2") als String ermittelt werden und der 
				//Variable 'gutschrKzText' als Wert zugewiesen werden... (Bei Fragen bitte an Patrick Meier unter
				//0961 - 400 1312 wenden) 
				
				String gutschrKzText = rechPos.getGutschriftkennzeichen(); //<--
				
				if (gutschrKzText != null && !gutschrKzText.equals("") ){
					this.setToolTipText("1: Gutschrift Warenrücklauf, 2: Sondergutschrift, 3: Gutschrift Fehlerraum, -1: Kontosperre (DI)");
				}
				this.setText(gutschrKzText != null ? gutschrKzText : "");
				break;						
			//Likz
			case 12:
				
				String lieferStatus = "";
				
				if (rechPos.getLieferkennzeichen() != null) {
					lieferStatus = rechPos.getLieferkennzeichen().getLiKennzeichenKurzBezeichnung();											
				}				
				this.setText(lieferStatus);
				this.setToolTipText(rechPos.getLieferkennzeichen().getLiKennzeichenBezeichnung());
				break;
//				NN/RK
			case 13:				
				
				if (rechPos.getKundenrechnungskopfBean().getZahlungskennzeichen().equals("RK")) {
					this.setToolTipText("Rechnungskauf");
				}
				else {
					this.setToolTipText("Nachnahme");
				}
				this.setText(rechPos.getKundenrechnungskopfBean().getZahlungskennzeichen());			
				break;			 	      
	        // Ratenanzahl
			case 14:				
				this.setText((rechPos.getRatenkennzeichen() == null ? "" : 
					  		  rechPos.getRatenkennzeichen().toString()));
				break;
			// Naliwochen
			case 15:			
				
				Long naliWo = rechPos.getNALIWoche();
				this.setText("");
				if (naliWo != null) {
					this.setText(naliWo.toString());
					if (naliWo.longValue() > 0) {
						this.setBackground(Color.yellow);
					}					
				}
				break;
			
	        }	
	        return this;		        
	 }
	 
}

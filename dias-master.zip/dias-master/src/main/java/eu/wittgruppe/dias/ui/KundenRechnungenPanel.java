package eu.wittgruppe.dias.ui;

import eu.wittgruppe.dias.bean.GroupableKunderechnungsposition;
import eu.wittgruppe.dias.bean.KunderechnungspositionBean;
import eu.wittgruppe.dias.controller.KundenMatchDialogController;
import eu.wittgruppe.dias.controller.KundenRechnungenPanelController;
import eu.wittgruppe.dias.ui.renderer.KundenRechnungenTableRenderer;
import eu.wittgruppe.dias.util.GenericTableModel;
import eu.wittgruppe.dias.util.Images;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import witt.josef.uiswing.ui.LimitedDocument;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;

public class KundenRechnungenPanel extends JPanel {

    private KundenRechnungenPanelController controller = null;

    private final String tableColumns[] = { "RechDat", "RetSchl", "PosNr", "ArtNr", "PromNr", "ArtGr", "ArtBez", "Farbe", "BestMg", "BestBetrag", "GutschrMg", "GutschrKz", "LiKz", "Zahlart", "Raten", "NaliWo" };
    private GenericTableModel tableModel;

    private GradientPanel northPanel = null;
    private JPanel centerPanel = null;
    private JLabel kdnrLabel = null;
    private JTextField kdnrTextField = null;
    private JButton matchKundeButton = null;
    private JButton suchenButton = null;
    private JLabel jLabel = null;
    private JScrollPane rechposScrollPane = null;
    private JTable rechposTable = null;

    private JTextField vornameTextField = null;

    private JTextField nachnameTextField = null;

    private JTextField strasseTextField = null;

    private JTextField hsnrTextField = null;

    private JTextField plzTextField = null;
    private JTextField ortTextField = null;

    private JTextField retschlTextField = null;

    private JLabel jLabel1 = null;

    private JTextField kdfirmTextField = null;

    private JTextField displayKdnrTextField = null;

    private JLabel printLabel = null;

    private JLabel runDiadem2Label = null;

    public KundenRechnungenPanel( KundenRechnungenPanelController controller ) {
        super();
        this.controller = controller;
        initialize();
    }

    /**
     * This method initializes this
     * 
     * @return void
     */
    private void initialize() {
        this.setLayout( new BorderLayout() );
        this.setSize( 800, 600 );
        this.add( getNorthPanel(), java.awt.BorderLayout.NORTH );
        this.add( getCenterPanel(), java.awt.BorderLayout.CENTER );
        this.tableModel = new GenericTableModel( tableColumns, 0 );
        getRechposTable().setModel( tableModel );
        getRechposTable().setRowHeight( 20 );
        getRechposTable().setDefaultRenderer( Object.class, new KundenRechnungenTableRenderer() );
        LimitedDocument doc = new LimitedDocument( 8, LimitedDocument.NUMBER );
        getKdnrTextField().setDocument( doc );

    }

    /**
     * This method initializes northPanel
     * 
     * @return javax.swing.JPanel
     */
    private JPanel getNorthPanel() {
        if( northPanel == null ) {
            GridBagConstraints gridBagConstraints31 = new GridBagConstraints();
            gridBagConstraints31.gridx = 2;
            gridBagConstraints31.insets = new java.awt.Insets( 12, 5, 2, 0 );
            gridBagConstraints31.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints31.gridy = 0;
            jLabel1 = new JLabel();
            jLabel1.setHorizontalAlignment( SwingConstants.LEFT );
            jLabel1.setText( "Retoureschlüssel:" );
            GridBagConstraints gridBagConstraints21 = new GridBagConstraints();
            gridBagConstraints21.fill = java.awt.GridBagConstraints.NONE;
            gridBagConstraints21.gridy = 1;
            gridBagConstraints21.weightx = 0.0;
            gridBagConstraints21.insets = new java.awt.Insets( 2, 2, 8, 5 );
            gridBagConstraints21.gridx = 2;
            GridBagConstraints gridBagConstraints9 = new GridBagConstraints();
            gridBagConstraints9.gridx = 4;
            gridBagConstraints9.weightx = 1.0;
            gridBagConstraints9.gridy = 1;
            jLabel = new JLabel();
            jLabel.setMaximumSize( new Dimension( 1111111, 16 ) );
            jLabel.setPreferredSize( new Dimension( 1, 16 ) );
            jLabel.setText( "JLabel" );
            jLabel.setMinimumSize( new Dimension( 1, 16 ) );
            GridBagConstraints gridBagConstraints8 = new GridBagConstraints();
            gridBagConstraints8.gridx = 3;
            gridBagConstraints8.insets = new java.awt.Insets( 0, 2, 10, 0 );
            gridBagConstraints8.gridy = 1;
            GridBagConstraints gridBagConstraints7 = new GridBagConstraints();
            gridBagConstraints7.gridx = 1;
            gridBagConstraints7.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints7.insets = new java.awt.Insets( 0, 2, 2, 0 );
            gridBagConstraints7.gridy = 1;
            GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
            gridBagConstraints1.fill = java.awt.GridBagConstraints.NONE;
            gridBagConstraints1.gridx = 0;
            gridBagConstraints1.gridy = 1;
            gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints1.insets = new java.awt.Insets( 2, 5, 8, 0 );
            gridBagConstraints1.weightx = 0.0;
            GridBagConstraints gridBagConstraints = new GridBagConstraints();
            gridBagConstraints.gridx = 0;
            gridBagConstraints.insets = new java.awt.Insets( 12, 5, 2, 0 );
            gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints.gridy = 0;
            kdnrLabel = new JLabel();
            kdnrLabel.setText( "Kundennummer:" );
            kdnrLabel.setHorizontalAlignment( javax.swing.SwingConstants.LEFT );
            northPanel = new GradientPanel();
            northPanel.setLayout( new GridBagLayout() );
            northPanel.setComponentOrientation( java.awt.ComponentOrientation.LEFT_TO_RIGHT );
            northPanel.setCursor( new java.awt.Cursor( java.awt.Cursor.DEFAULT_CURSOR ) );
            northPanel.add( kdnrLabel, gridBagConstraints );
            northPanel.add( getKdnrTextField(), gridBagConstraints1 );
            northPanel.add( getJButton(), gridBagConstraints7 );
            northPanel.add( getSuchenButton(), gridBagConstraints8 );
            northPanel.add( jLabel, gridBagConstraints9 );
            northPanel.add( getRetschlTextField(), gridBagConstraints21 );
            northPanel.add( jLabel1, gridBagConstraints31 );

        }
        return northPanel;
    }

    /**
     * This method initializes centerPanel
     * 
     * @return javax.swing.JPanel
     */
    private JPanel getCenterPanel() {
        if( centerPanel == null ) {
            GridBagConstraints gridBagConstraints15 = new GridBagConstraints();
            gridBagConstraints15.gridx = 6;
            gridBagConstraints15.anchor = GridBagConstraints.SOUTHWEST;
            gridBagConstraints15.gridwidth = 1;
            gridBagConstraints15.insets = new Insets( 0, 5, 0, 0 );
            gridBagConstraints15.gridy = 4;
            runDiadem2Label = new JLabel( Images.RUN_DEBUAR );
            runDiadem2Label.setMaximumSize( new Dimension( 21, 21 ) );
            runDiadem2Label.setPreferredSize( new Dimension( 21, 21 ) );
            runDiadem2Label.setToolTipText( "Starte Kontobild in Diadem2" );
            runDiadem2Label.setDisplayedMnemonic( KeyEvent.VK_UNDEFINED );
            runDiadem2Label.setText( "" );

            runDiadem2Label.setMinimumSize( new Dimension( 21, 21 ) );
            runDiadem2Label.addMouseListener( new MouseEnteredOnLabel() );
            runDiadem2Label.addMouseListener( new MouseExitedOnLabel() );
            runDiadem2Label.addMouseListener( new OnDiadem2RunClicked() );
            GridBagConstraints gridBagConstraints13 = new GridBagConstraints();
            gridBagConstraints13.gridx = 5;
            gridBagConstraints13.anchor = GridBagConstraints.SOUTHWEST;
            gridBagConstraints13.insets = new Insets( 0, 5, 0, 0 );
            gridBagConstraints13.gridwidth = 1;
            gridBagConstraints13.gridy = 4;
            printLabel = new JLabel( Images.PRINT );
            printLabel.setMaximumSize( new Dimension( 21, 21 ) );
            printLabel.setPreferredSize( new Dimension( 21, 21 ) );
            printLabel.setToolTipText( "Rechnungspositionen drucken" );
            printLabel.setText( "" );
            printLabel.addMouseListener( new OnPrintLabelClicked() );
            printLabel.addMouseListener( new MouseEnteredOnLabel() );
            printLabel.addMouseListener( new MouseExitedOnLabel() );
            printLabel.setDisplayedMnemonic( KeyEvent.VK_UNDEFINED );
            printLabel.setMinimumSize( new Dimension( 21, 21 ) );
            GridBagConstraints gridBagConstraints14 = new GridBagConstraints();
            gridBagConstraints14.fill = java.awt.GridBagConstraints.NONE;
            gridBagConstraints14.gridy = 0;
            gridBagConstraints14.weightx = 0.0;
            gridBagConstraints14.insets = new java.awt.Insets( 10, 2, 0, 0 );
            gridBagConstraints14.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints14.gridwidth = 2;
            gridBagConstraints14.gridx = 1;
            GridBagConstraints gridBagConstraints12 = new GridBagConstraints();
            gridBagConstraints12.fill = java.awt.GridBagConstraints.NONE;
            gridBagConstraints12.gridy = 0;
            gridBagConstraints12.weightx = 0.0;
            gridBagConstraints12.insets = new java.awt.Insets( 10, 2, 0, 0 );
            gridBagConstraints12.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints12.gridwidth = 3;
            gridBagConstraints12.gridx = 3;
            GridBagConstraints gridBagConstraints11 = new GridBagConstraints();
            gridBagConstraints11.fill = java.awt.GridBagConstraints.NONE;
            gridBagConstraints11.gridy = 4;
            gridBagConstraints11.weightx = 0.0;
            gridBagConstraints11.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints11.insets = new java.awt.Insets( 10, 2, 0, 0 );
            gridBagConstraints11.gridwidth = 5;
            gridBagConstraints11.gridx = 2;
            GridBagConstraints gridBagConstraints10 = new GridBagConstraints();
            gridBagConstraints10.fill = java.awt.GridBagConstraints.NONE;
            gridBagConstraints10.gridy = 4;
            gridBagConstraints10.weightx = 0.0;
            gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints10.insets = new java.awt.Insets( 10, 2, 0, 0 );
            gridBagConstraints10.gridwidth = 1;
            gridBagConstraints10.gridx = 1;
            GridBagConstraints gridBagConstraints6 = new GridBagConstraints();
            gridBagConstraints6.fill = java.awt.GridBagConstraints.NONE;
            gridBagConstraints6.gridy = 3;
            gridBagConstraints6.weightx = 0.0;
            gridBagConstraints6.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints6.insets = new java.awt.Insets( 2, 2, 0, 0 );
            gridBagConstraints6.gridwidth = 1;
            gridBagConstraints6.gridx = 4;
            GridBagConstraints gridBagConstraints5 = new GridBagConstraints();
            gridBagConstraints5.fill = java.awt.GridBagConstraints.NONE;
            gridBagConstraints5.gridy = 3;
            gridBagConstraints5.weightx = 0.0;
            gridBagConstraints5.insets = new java.awt.Insets( 2, 2, 0, 0 );
            gridBagConstraints5.gridwidth = 3;
            gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints5.gridx = 1;
            GridBagConstraints gridBagConstraints4 = new GridBagConstraints();
            gridBagConstraints4.fill = java.awt.GridBagConstraints.NONE;
            gridBagConstraints4.gridy = 2;
            gridBagConstraints4.weightx = 0.0;
            gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints4.insets = new java.awt.Insets( 10, 2, 0, 0 );
            gridBagConstraints4.gridwidth = 4;
            gridBagConstraints4.gridx = 3;
            GridBagConstraints gridBagConstraints3 = new GridBagConstraints();
            gridBagConstraints3.fill = java.awt.GridBagConstraints.NONE;
            gridBagConstraints3.gridx = 1;
            gridBagConstraints3.gridy = 2;
            gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints3.insets = new java.awt.Insets( 10, 2, 0, 0 );
            gridBagConstraints3.gridwidth = 2;
            gridBagConstraints3.weightx = 0.0;
            GridBagConstraints gridBagConstraints2 = new GridBagConstraints();
            gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
            gridBagConstraints2.gridx = 0;
            gridBagConstraints2.gridy = 7;
            gridBagConstraints2.weightx = 1.0;
            gridBagConstraints2.weighty = 1.0;
            gridBagConstraints2.gridwidth = 7;
            gridBagConstraints2.insets = new java.awt.Insets( 15, 5, 15, 5 );
            centerPanel = new JPanel();
            centerPanel.setLayout( new GridBagLayout() );
            centerPanel.add( getRechposScrollPane(), gridBagConstraints2 );
            centerPanel.add( getVornameTextField(), gridBagConstraints3 );
            centerPanel.add( getNachnameTextField(), gridBagConstraints4 );
            centerPanel.add( getStrasseTextField(), gridBagConstraints5 );
            centerPanel.add( getHsnrTextField(), gridBagConstraints6 );
            centerPanel.add( getPlzTextField(), gridBagConstraints10 );
            centerPanel.add( getOrtTextField(), gridBagConstraints11 );
            centerPanel.add( getKdfirmTextField(), gridBagConstraints12 );
            centerPanel.add( getDisplayKdnrTextField(), gridBagConstraints14 );
            centerPanel.add( printLabel, gridBagConstraints13 );
            centerPanel.add( runDiadem2Label, gridBagConstraints15 );
        }
        return centerPanel;
    }

    /**
     * This method initializes kdnrTextField
     * 
     * @return javax.swing.JTextField
     */
    public JTextField getKdnrTextField() {
        if( kdnrTextField == null ) {
            kdnrTextField = new JTextField();
            LimitedDocument doc = new LimitedDocument( 6, LimitedDocument.NUMBER );
            kdnrTextField.setDocument( doc );
            kdnrTextField.setPreferredSize( new java.awt.Dimension( 104, 21 ) );
            kdnrTextField.setMaximumSize( new java.awt.Dimension( 104, 21 ) );
            kdnrTextField.setHorizontalAlignment( SwingConstants.LEFT );
            kdnrTextField.setMinimumSize( new java.awt.Dimension( 104, 21 ) );
            kdnrTextField.addKeyListener( new PressedEnterKeyOnKdnrField() );
        }
        return kdnrTextField;
    }

    /**
     * This method initializes jTextField
     * 
     * @return javax.swing.JTextField
     */
    private JTextField getRetschlTextField() {
        if( retschlTextField == null ) {
            retschlTextField = new JTextField();
            retschlTextField.setMaximumSize( new Dimension( 104, 21 ) );
            retschlTextField.setPreferredSize( new Dimension( 104, 21 ) );
            retschlTextField.setDocument( new LimitedDocument( 8, LimitedDocument.NUMBER ) );
            retschlTextField.setHorizontalAlignment( SwingConstants.LEFT );
            retschlTextField.setMinimumSize( new Dimension( 104, 21 ) );
            retschlTextField.addKeyListener( new PressedEnterKeyOnRetschlField() );
        }
        return retschlTextField;
    }

    /**
     * This method initializes jButton
     * 
     * @return javax.swing.JButton
     */
    private JButton getJButton() {
        if( matchKundeButton == null ) {
            matchKundeButton = new JButton();
            matchKundeButton.setMaximumSize( new Dimension( 33, 16 ) );
            matchKundeButton.setPreferredSize( new Dimension( 33, 16 ) );
            matchKundeButton.setToolTipText( "Kunde suchen" );
            matchKundeButton.setText( "..." );
            matchKundeButton.setMinimumSize( new Dimension( 33, 16 ) );
            matchKundeButton.addActionListener( new OnMatchKundeButton() );
        }
        return matchKundeButton;
    }

    /**
     * This method initializes jButton1
     * 
     * @return javax.swing.JButton
     */
    private JButton getSuchenButton() {
        if( suchenButton == null ) {
            suchenButton = new JButton();

            suchenButton.setMaximumSize( new Dimension( 115, 26 ) );
            suchenButton.setPreferredSize( new Dimension( 115, 26 ) );
            suchenButton.setText( "Suchen (F3)" );
            suchenButton.setToolTipText( "Kundenrechnungen suchen" );
            suchenButton.setMinimumSize( new Dimension( 115, 26 ) );

            ClickedOnSearchButton listener = new ClickedOnSearchButton();
            suchenButton.addActionListener( listener );

            suchenButton.registerKeyboardAction( listener, "F3", KeyStroke.getKeyStroke( KeyEvent.VK_F3, 0 ), JComponent.WHEN_IN_FOCUSED_WINDOW );
        }
        return suchenButton;
    }

    /**
     * This method initializes rechposScrollPane
     * 
     * @return javax.swing.JScrollPane
     */
    private JScrollPane getRechposScrollPane() {
        if( rechposScrollPane == null ) {
            rechposScrollPane = new JScrollPane();
            rechposScrollPane.setViewportView( getRechposTable() );
        }
        return rechposScrollPane;
    }

    /**
     * This method initializes rechposTable
     * 
     * @return javax.swing.JTable
     */
    public JTable getRechposTable() {
        if( rechposTable == null ) {
            rechposTable = new JTable();
            rechposTable.addMouseListener( new DoubleClickedOnRechPostable() );
        }
        return rechposTable;
    }

    /**
     * This method initializes vornameTextField
     * 
     * @return javax.swing.JTextField
     */
    public JTextField getVornameTextField() {
        if( vornameTextField == null ) {
            vornameTextField = new JTextField();
            vornameTextField.setPreferredSize( new java.awt.Dimension( 120, 20 ) );
            vornameTextField.setMaximumSize( new java.awt.Dimension( 120, 20 ) );
            vornameTextField.setEnabled( false );
            vornameTextField.setDisabledTextColor( java.awt.Color.black );
            vornameTextField.setBackground( new java.awt.Color( 231, 235, 235 ) );
            vornameTextField.setToolTipText( "Vorname" );
            vornameTextField.setMinimumSize( new java.awt.Dimension( 120, 20 ) );
        }
        return vornameTextField;
    }

    /**
     * This method initializes jTextField
     * 
     * @return javax.swing.JTextField
     */
    public JTextField getNachnameTextField() {
        if( nachnameTextField == null ) {
            nachnameTextField = new JTextField();
            nachnameTextField.setMaximumSize( new java.awt.Dimension( 150, 20 ) );
            nachnameTextField.setPreferredSize( new java.awt.Dimension( 150, 20 ) );
            nachnameTextField.setEnabled( false );
            nachnameTextField.setDisabledTextColor( java.awt.Color.black );
            nachnameTextField.setBackground( new java.awt.Color( 231, 235, 235 ) );
            nachnameTextField.setToolTipText( "Nachname" );
            nachnameTextField.setMinimumSize( new java.awt.Dimension( 150, 20 ) );
        }
        return nachnameTextField;
    }

    /**
     * This method initializes strasseTextField
     * 
     * @return javax.swing.JTextField
     */
    public JTextField getStrasseTextField() {
        if( strasseTextField == null ) {
            strasseTextField = new JTextField();
            strasseTextField.setPreferredSize( new java.awt.Dimension( 180, 20 ) );
            strasseTextField.setMaximumSize( new java.awt.Dimension( 180, 20 ) );
            strasseTextField.setEnabled( false );
            strasseTextField.setDisabledTextColor( java.awt.Color.black );
            strasseTextField.setBackground( new java.awt.Color( 231, 235, 235 ) );
            strasseTextField.setToolTipText( "Strasse" );
            strasseTextField.setMinimumSize( new java.awt.Dimension( 180, 20 ) );
        }
        return strasseTextField;
    }

    /**
     * This method initializes hsnrTextField
     * 
     * @return javax.swing.JTextField
     */
    public JTextField getHsnrTextField() {
        if( hsnrTextField == null ) {
            hsnrTextField = new JTextField();
            hsnrTextField.setMinimumSize( new java.awt.Dimension( 90, 20 ) );
            hsnrTextField.setMaximumSize( new java.awt.Dimension( 90, 20 ) );
            hsnrTextField.setEnabled( false );
            hsnrTextField.setDisabledTextColor( java.awt.Color.black );
            hsnrTextField.setBackground( new java.awt.Color( 231, 235, 235 ) );
            hsnrTextField.setToolTipText( "Hausnummer" );
            hsnrTextField.setPreferredSize( new java.awt.Dimension( 90, 20 ) );
        }
        return hsnrTextField;
    }

    /**
     * This method initializes plzTextField
     * 
     * @return javax.swing.JTextField
     */
    public JTextField getPlzTextField() {
        if( plzTextField == null ) {
            plzTextField = new JTextField();
            plzTextField.setPreferredSize( new java.awt.Dimension( 50, 20 ) );
            plzTextField.setMaximumSize( new java.awt.Dimension( 50, 20 ) );
            plzTextField.setEnabled( false );
            plzTextField.setDisabledTextColor( java.awt.Color.black );
            plzTextField.setBackground( new java.awt.Color( 231, 235, 235 ) );
            plzTextField.setToolTipText( "PLZ" );
            plzTextField.setMinimumSize( new java.awt.Dimension( 50, 20 ) );
        }
        return plzTextField;
    }

    /**
     * This method initializes ortTextField
     * 
     * @return javax.swing.JTextField
     */
    public JTextField getOrtTextField() {
        if( ortTextField == null ) {
            ortTextField = new JTextField();
            ortTextField.setPreferredSize( new java.awt.Dimension( 220, 20 ) );
            ortTextField.setMaximumSize( new java.awt.Dimension( 220, 20 ) );
            ortTextField.setEnabled( false );
            ortTextField.setDisabledTextColor( java.awt.Color.black );
            ortTextField.setBackground( new java.awt.Color( 231, 235, 235 ) );
            ortTextField.setToolTipText( "Ort" );
            ortTextField.setMinimumSize( new java.awt.Dimension( 220, 20 ) );
        }
        return ortTextField;
    }

    public GenericTableModel getTableModel() {
        return tableModel;
    }

    public void setTableModel( GenericTableModel tableModel ) {
        this.tableModel = tableModel;
    }

    /**
     * This method initializes jTextField
     * 
     * @return javax.swing.JTextField
     */
    public JTextField getKdfirmTextField() {
        if( kdfirmTextField == null ) {
            kdfirmTextField = new JTextField();
            kdfirmTextField.setBackground( new Color( 231, 235, 235 ) );
            kdfirmTextField.setMaximumSize( new Dimension( 120, 20 ) );
            kdfirmTextField.setMinimumSize( new Dimension( 120, 20 ) );
            kdfirmTextField.setPreferredSize( new Dimension( 120, 20 ) );
            kdfirmTextField.setDisabledTextColor( Color.black );
            kdfirmTextField.setToolTipText( "Kundenfirma" );
            kdfirmTextField.setEnabled( false );
        }
        return kdfirmTextField;
    }

    /**
     * This method initializes jTextField1
     * 
     * @return javax.swing.JTextField
     */
    public JTextField getDisplayKdnrTextField() {
        if( displayKdnrTextField == null ) {
            displayKdnrTextField = new JTextField();
            displayKdnrTextField.setBackground( new Color( 231, 235, 235 ) );
            displayKdnrTextField.setMaximumSize( new Dimension( 120, 20 ) );
            displayKdnrTextField.setMinimumSize( new Dimension( 120, 20 ) );
            displayKdnrTextField.setPreferredSize( new Dimension( 120, 20 ) );
            displayKdnrTextField.setDisabledTextColor( Color.black );
            displayKdnrTextField.setToolTipText( "Kundennummer" );
            displayKdnrTextField.setEnabled( false );
        }
        return displayKdnrTextField;
    }

    // L I S T E N E R S
    private class ClickedOnSearchButton implements java.awt.event.ActionListener {
        @Override
        public void actionPerformed( java.awt.event.ActionEvent e ) {

            Long kdnr = null;
            Long retschl = null;

            if( StringUtils.isNotEmpty( getKdnrTextField().getText() ) ) {
                kdnr = NumberUtils.createLong( getKdnrTextField().getText() );
            }
            if( StringUtils.isNotEmpty( getRetschlTextField().getText() ) ) {
                retschl = NumberUtils.createLong( getRetschlTextField().getText() );
            }

            if( kdnr != null && retschl != null ) {
                JOptionPane.showMessageDialog( controller.getParentController().getMainWindow(), "Bitte nur ein Suchkriterium vorgeben", "Suchen", JOptionPane.INFORMATION_MESSAGE );
            } else if( kdnr != null ) {
                // kundenfirmaId, kdnr
                controller.sucheRechnungsPositionen( null, kdnr );
            } else if( retschl != null ) {
                // nach retschl
                controller.sucheRechnungsPositionen( retschl );
            } else {
                JOptionPane.showMessageDialog( controller.getParentController().getMainWindow(), "Keine Kundennummer eingegeben!", "Suchen", JOptionPane.INFORMATION_MESSAGE );
            }
        }
    }

    private class PressedEnterKeyOnKdnrField extends java.awt.event.KeyAdapter {
        @Override
        public void keyPressed( KeyEvent ke ) {
            if( ke.getKeyCode() == KeyEvent.VK_ENTER ) {

                Long kdnr = null;

                if( StringUtils.isNotEmpty( getKdnrTextField().getText() ) ) {
                    kdnr = NumberUtils.createLong( getKdnrTextField().getText() );
                    // kdfirmid, kdnr
                    controller.sucheRechnungsPositionen( null, kdnr );
                } else {
                    JOptionPane.showMessageDialog( controller.getParentController().getMainWindow(), "Keine Kundennummer eingegeben!", "Suchen", JOptionPane.INFORMATION_MESSAGE );
                }
            }
        }
    }

    private class PressedEnterKeyOnRetschlField extends java.awt.event.KeyAdapter {
        @Override
        public void keyPressed( KeyEvent ke ) {
            if( ke.getKeyCode() == KeyEvent.VK_ENTER ) {

                Long retschl = null;

                if( StringUtils.isNotEmpty( getRetschlTextField().getText() ) ) {
                    retschl = NumberUtils.createLong( getRetschlTextField().getText() );
                    // retoureschlüssel
                    controller.sucheRechnungsPositionen( retschl );
                } else {
                    JOptionPane.showMessageDialog( controller.getParentController().getMainWindow(), "Kein Retoureschlüssel eingegeben!", "Suchen", JOptionPane.INFORMATION_MESSAGE );
                }
            }
        }
    }

    private class DoubleClickedOnRechPostable extends java.awt.event.MouseAdapter {
        @Override
        public void mouseClicked( java.awt.event.MouseEvent e ) {

            if( e.getClickCount() == 2 ) {

                KunderechnungspositionBean cellValue = ( ( GroupableKunderechnungsposition )getRechposTable().getValueAt( getRechposTable().getSelectedRow(), 0 ) ).getPos();

                controller.showCRSArtikelSearchDialog( cellValue.getArtikelnummerWitt(), cellValue.getArtikelgroesse() );
            }
        }
    }

    private class OnMatchKundeButton implements java.awt.event.ActionListener {
        @Override
        public void actionPerformed( java.awt.event.ActionEvent e ) {

            new KundenMatchDialogController( controller ).showDialog();

        }
    }

    private class OnPrintLabelClicked extends java.awt.event.MouseAdapter {

        @Override
        public void mouseClicked( java.awt.event.MouseEvent e ) {

            if( e.getClickCount() == 1 ) {
                controller.printRechnungsPositionen();
            }
        }
    }

    private class OnDiadem2RunClicked extends java.awt.event.MouseAdapter {

        @Override
        public void mouseClicked( java.awt.event.MouseEvent e ) {

            if( e.getClickCount() == 1 ) {

                Long kdnr = null;

                if( ( StringUtils.isNotEmpty( getDisplayKdnrTextField().getText() ) && ( StringUtils.isNotEmpty( getKdfirmTextField().getText().trim() ) ) ) ) {
                    kdnr = NumberUtils.createLong( getDisplayKdnrTextField().getText() );
                    // kdfirmid, kdnr
                    controller.runDiadem2( kdnr );
                } else {
                    JOptionPane.showMessageDialog( controller.getParentController().getMainWindow(), "Keine Kundennummer eingegeben\nbzw. erst Suche ausführen!", "Suchen", JOptionPane.INFORMATION_MESSAGE );
                }

            }
        }
    }

    private class MouseEnteredOnLabel extends java.awt.event.MouseAdapter {

        @Override
        public void mouseEntered( java.awt.event.MouseEvent e ) {
            ( ( JLabel )e.getSource() ).setBorder( javax.swing.BorderFactory.createLineBorder( java.awt.Color.GRAY, 1 ) );
        }
    }

    private class MouseExitedOnLabel extends java.awt.event.MouseAdapter {

        @Override
        public void mouseExited( java.awt.event.MouseEvent e ) {
            ( ( JLabel )e.getSource() ).setBorder( null );
        }
    }

} // @jve:decl-index=0:visual-constraint="10,10"

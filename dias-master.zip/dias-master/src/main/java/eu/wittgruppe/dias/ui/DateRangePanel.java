/*
 * Created on 12.12.2005
 */
package eu.wittgruppe.dias.ui;

import eu.wittgruppe.dias.controller.DateRangePanelController;
import witt.josef.uiswing.ui.CustomTextField;
import witt.josef.uiswing.ui.FocusOrder;
import witt.josef.uiswing.ui.LimitedDocument;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

public class DateRangePanel extends JPanel implements ActionListener {

    private JLabel messageLabel = null;
    private JLabel startLabel = null;
    private CustomTextField startDatumTextField = null;
    private JLabel bisLabel = null;
    private CustomTextField endeDatumTextField = null;
    private JButton auswertungButton = null;
    private JButton cancelButton = null;
    private DateRangePanelController controller;

    private static final String AUSWERTUNG = "AUSWERTUNG";
    private static final String CANCEL = "CANCEL";
    private JButton selectStartDateButton = null;
    private JButton selectEndDateButton = null;
	private JComboBox userComboBox = null;
	private JRadioButton allUserRadioButton = null;
	private JRadioButton oneUserRadioButton = null;
	/**
     * This method initializes startDatumTextField	
     * 	
     * @return javax.swing.JTextField	
     */
    public JTextField getStartDatumTextField() {
        if( startDatumTextField == null ) {
            startDatumTextField = new CustomTextField(  );
            startDatumTextField.setDocument(new LimitedDocument( "##.##.####", true ));
            
            startDatumTextField.setBounds(new java.awt.Rectangle(84,45,77,21));
        }
        return startDatumTextField;
    }

    /**
     * This method initializes endeDatumTextField	
     * 	
     * @return javax.swing.JTextField	
     */
    public JTextField getEndeDatumTextField() {
        if( endeDatumTextField == null ) {
            endeDatumTextField = new CustomTextField( );
            endeDatumTextField.setDocument(new LimitedDocument( "##.##.####", true ));
            endeDatumTextField.setBounds(new java.awt.Rectangle(234,45,82,21));
        }
        return endeDatumTextField;
    }

    /**
     * This method initializes auswertungButton	
     * 	
     * @return javax.swing.JButton	
     */
    public JButton getAuswertungButton() {
        if( auswertungButton == null ) {
            auswertungButton = new JButton();
            auswertungButton.setText("Starten (F3)");
            auswertungButton.setLocation(new java.awt.Point(64,138));
            auswertungButton.setSize(new java.awt.Dimension(115,26));
            auswertungButton.setPreferredSize(new java.awt.Dimension(115,26));
            auswertungButton.setMinimumSize(new java.awt.Dimension(115,26));
            auswertungButton.setToolTipText("Leistungsziehung starten");
            auswertungButton.setMaximumSize(new java.awt.Dimension(115,26));
            
            OnStartButtonClick listener = new OnStartButtonClick();
            
            auswertungButton.addActionListener( listener);
            auswertungButton.registerKeyboardAction( listener, 
					 "F3", KeyStroke.getKeyStroke( KeyEvent.VK_F3, 0 ), 
					 JComponent.WHEN_IN_FOCUSED_WINDOW );
            auswertungButton.setMnemonic( 's' );            
        }
        return auswertungButton;
    }

    /**
     * This method initializes cancelButton	
     * 	
     * @return javax.swing.JButton	
     */
    private JButton getCancelButton() {
        if( cancelButton == null ) {
            cancelButton = new JButton();
            cancelButton.setText("Abbrechen");
            cancelButton.setLocation(new java.awt.Point(189,137));
            cancelButton.setSize(new java.awt.Dimension(115,26));
            cancelButton.setPreferredSize(new java.awt.Dimension(115,26));
            cancelButton.setMinimumSize(new java.awt.Dimension(115,26));
            cancelButton.setMaximumSize(new java.awt.Dimension(115,26));
            cancelButton.addActionListener( new java.awt.event.ActionListener() {
                @Override
                public void actionPerformed( java.awt.event.ActionEvent e ) {
                    controller.cancel();
                }
            } );
            cancelButton.setMnemonic( 'A' );
            cancelButton.registerKeyboardAction( this, CANCEL, KeyStroke.getKeyStroke( KeyEvent.VK_ESCAPE, 0 ),
                                                                JComponent.WHEN_IN_FOCUSED_WINDOW );
        }
        return cancelButton;
    }

    /**
     * This is the default constructor
     */
    public DateRangePanel() {
        super();
        initialize();
    }
    
    public DateRangePanel( DateRangePanelController controller ) {
        super();
        this.controller = controller;
        initialize();
//        UIUtils.centerOverComponent( parent, this );
    }

    /**
     * This method initializes this
     * 
     * @return void
     */
    private void initialize() {
        this.setSize(403, 210);
        
        setLayout(null);
        FocusOrder order = new FocusOrder( this, KeyStroke.getKeyStroke( KeyEvent.VK_ENTER, 0 ) );
        order.registerDefault( getStartDatumTextField() );
        order.registerDefault( getEndeDatumTextField() );
        order.registerDefault( getAuswertungButton() );
        order.registerMandatory( getStartDatumTextField() );
        order.registerMandatory( getEndeDatumTextField() );
        order.registerMandatory( getAuswertungButton() );
        bisLabel = new JLabel();
        bisLabel.setBounds(new java.awt.Rectangle(204,45,26,21));
        bisLabel.setText("Bis");
        bisLabel.setDisplayedMnemonic( 'B' );
        bisLabel.setLabelFor( getEndeDatumTextField() );
        startLabel = new JLabel();
        startLabel.setBounds(new java.awt.Rectangle(8,45,71,21));
        startLabel.setText("Vom");
        startLabel.setDisplayedMnemonic( 'V' );
        startLabel.setLabelFor( getStartDatumTextField() );
        messageLabel = new JLabel();
        messageLabel.setBounds(new java.awt.Rectangle(8,9,256,26));
        messageLabel.setText("Bitte einen Auswertungszeitraum festlegen :");
        add(messageLabel, null);
        add(startLabel, null);
        add(getStartDatumTextField(), null);
        add(bisLabel, null);
        add(getEndeDatumTextField(), null);
        add(getAuswertungButton(), null);
        add(getCancelButton(), null);
        add(getSelectStartDateButton(), null);
        add(getSelectEndDateButton(), null);
        this.add(getUserComboBox(), null);
        
        ButtonGroup group = new ButtonGroup();
        group.add(getAllUserRadioButton());
        group.add(getOneUserRadioButton());
        this.add(getAllUserRadioButton(), null);
        this.add(getOneUserRadioButton(), null);
        
       // controller.fillUserComboBox(getUserComboBox());
        
        SwingUtilities.invokeLater( new Runnable() {
            @Override
            public void run() {
                getStartDatumTextField().requestFocus();
            }
        } );
    }

    @Override
    public void actionPerformed( ActionEvent e ) {
        if( e.getActionCommand().equals( AUSWERTUNG ) ) {
            controller.auswerten();
        } else {
//            dispose();
        }
    }

    /**
     * This method initializes selectStartDateButton	
     * 	
     * @return javax.swing.JButton	
     */
    private JButton getSelectStartDateButton() {
        if( selectStartDateButton == null ) {
            selectStartDateButton = new JButton();
            selectStartDateButton.setBounds(new java.awt.Rectangle(165,46,16,21));
            selectStartDateButton.setToolTipText("vom Datum auswählen");
            selectStartDateButton.setText("...");
            selectStartDateButton.addActionListener( new java.awt.event.ActionListener() {
                @Override
                public void actionPerformed( java.awt.event.ActionEvent e ) {
                    controller.chooseStartDate();
                } 
            } );
        }
        return selectStartDateButton;
    }

    /**
     * This method initializes selectEndDateButton	
     * 	
     * @return javax.swing.JButton	
     */
    private JButton getSelectEndDateButton() {
        if( selectEndDateButton == null ) {
            selectEndDateButton = new JButton();
            selectEndDateButton.setBounds(new java.awt.Rectangle(321,46,16,21));
            selectEndDateButton.setToolTipText("bis Datum auswählen");
            selectEndDateButton.setText("...");
            selectEndDateButton.addActionListener( new java.awt.event.ActionListener() {
                @Override
                public void actionPerformed( java.awt.event.ActionEvent e ) {
                    controller.chooseEndDate();
                }
            } );
        }
        return selectEndDateButton;
    }

	/**
	 * This method initializes userComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	public JComboBox getUserComboBox() {
		if (userComboBox == null) {
			userComboBox = new JComboBox();
			userComboBox.setPreferredSize(new java.awt.Dimension(150,25));
			userComboBox.setSize(new java.awt.Dimension(150,25));
			userComboBox.setMinimumSize(new java.awt.Dimension(150,25));
			userComboBox.setMaximumSize(new java.awt.Dimension(150,25));
			userComboBox.setEnabled(false);
			userComboBox.setLocation(new java.awt.Point(142,81));
		}
		return userComboBox;
	}

	/**
	 * This method initializes allUserRadioButton	
	 * 	
	 * @return javax.swing.JRadioButton	
	 */
	public JRadioButton getAllUserRadioButton() {
		if (allUserRadioButton == null) {
			allUserRadioButton = new JRadioButton();
			allUserRadioButton.setBounds(new java.awt.Rectangle(17,104,116,21));
			allUserRadioButton.setSelected(true);
			allUserRadioButton.setText("alle Benutzer");
			allUserRadioButton.addActionListener(new java.awt.event.ActionListener() {
				@Override
                public void actionPerformed(java.awt.event.ActionEvent e) {
					getUserComboBox().setEnabled(false);
				}
			});
		}
		return allUserRadioButton;
	}

	/**
	 * This method initializes oneUserRadioButton	
	 * 	
	 * @return javax.swing.JRadioButton	
	 */
	public JRadioButton getOneUserRadioButton() {
		if (oneUserRadioButton == null) {
			oneUserRadioButton = new JRadioButton();
			oneUserRadioButton.setBounds(new java.awt.Rectangle(17,81,116,21));
			oneUserRadioButton.setText("ein Benutzer");
			oneUserRadioButton.addActionListener(new java.awt.event.ActionListener() {
				@Override
                public void actionPerformed(java.awt.event.ActionEvent e) {
					getUserComboBox().setEnabled(true);
				}
			});
		}
		return oneUserRadioButton;
	}
	// Listener für Click am Start Button
	private class OnStartButtonClick implements java.awt.event.ActionListener {
        @Override
        public void actionPerformed( java.awt.event.ActionEvent e ) {
            controller.auswerten();
        }
    } 
    

}  //  @jve:decl-index=0:visual-constraint="7,28"

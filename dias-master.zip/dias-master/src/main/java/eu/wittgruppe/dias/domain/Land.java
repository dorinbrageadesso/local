package eu.wittgruppe.dias.domain;

import jakarta.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;

@Entity(name = "Land")
@Table(name = "land")
public class Land implements Serializable {



	@Column(name = "landnr")
	private Long landNummer;

	@Column(name = "vorwahl")
	private String vorwahl;

	@Column(name = "isocountrycode")
	private String isoCountryCode;

	@Id
	@Column(name = "ID")
	@org.hibernate.annotations.GenericGenerator(name = "getId", strategy = "witt.josef.orm.hibernate.IdGenerator")
	@GeneratedValue(generator = "getId")
	private String id;

	@Column(name = "transferkz")
	private BigDecimal transferKennzeichen;


	@Column(name = "praefnr_2")
	private BigDecimal praefixNr2;

	@Column(name = "waehrungkurzbez")
	private String waehrungsKurzbezeichnung;

	@Column(name = "egkz")
	private String eGKennzeichen;

	@Column(name = "usernr")
	private BigDecimal userNummer;

	@Column(name = "natkz")
	private String nationalitaetsKennzeichen;

	@Column(name = "inlandkz")
	private String inlandsKennzeichen;

	@Column(name = "landbez")
	private String landBezeichnung;

	@Column(name = "benutzerid")
	private String benutzerId;

	@Column(name = "aenddat")
	private Date datumLetzteAenderung;

	@Column(name = "landkurzbez")
	private String landKurzbezeichnung;

	@Column(name = "fernostkz")
	private String fernostKennzeichen;

	@Column(name = "praefnr_1")
	private BigDecimal praefixNr1;

	@OneToMany(mappedBy = "land", fetch = FetchType.LAZY)
	private Collection<Kundenfirma> kundenfirmen = new ArrayList<Kundenfirma>();

	public Collection<Kundenfirma> getKundenfirmen() {
		return kundenfirmen;
	}

	public void addKundenfirma(Kundenfirma kundenfirma) {
		getKundenfirmen().add(kundenfirma);
		kundenfirma.setLand(this);
	}

	public void removeKundenfirma(Kundenfirma kundenfirma) {
		getKundenfirmen().remove(kundenfirma);
		kundenfirma.setLand(null);
	}

	
	private static final long serialVersionUID = 1L;

	public Land() {
		super();
	}

	public Long getLandNummer() {
		return landNummer;
	}

	public void setLandNummer(Long landNummer) {
		this.landNummer = landNummer;
	}

	public String getVorwahl() {
		return vorwahl;
	}

	public void setVorwahl(String vorwahl) {
		this.vorwahl = vorwahl;
	}

	public String getIsoCountryCode() {
		return isoCountryCode;
	}

	public void setIsoCountryCode(String isoCountryCode) {
		this.isoCountryCode = isoCountryCode;
	}

	public String getId() {
		return id;
	}

	public BigDecimal getTransferKennzeichen() {
		return transferKennzeichen;
	}

	public void setTransferKennzeichen(BigDecimal transferKennzeichen) {
		this.transferKennzeichen = transferKennzeichen;
	}

	public BigDecimal getPraefixNr2() {
		return praefixNr2;
	}

	public void setPraefixNr2(BigDecimal praefixNr2) {
		this.praefixNr2 = praefixNr2;
	}

	public String getWaehrungsKurzbezeichnung() {
		return waehrungsKurzbezeichnung;
	}

	public void setWaehrungsKurzbezeichnung(String waehrungsKurzbezeichnung) {
		this.waehrungsKurzbezeichnung = waehrungsKurzbezeichnung;
	}

	public String getEGKennzeichen() {
		return eGKennzeichen;
	}

	public void setEGKennzeichen(String kennzeichen) {
		eGKennzeichen = kennzeichen;
	}

	public BigDecimal getUserNummer() {
		return userNummer;
	}

	public void setUserNummer(BigDecimal userNummer) {
		this.userNummer = userNummer;
	}

	public String getNationalitaetsKennzeichen() {
		return nationalitaetsKennzeichen;
	}

	public void setNationalitaetsKennzeichen(String nationalitaetsKennzeichen) {
		this.nationalitaetsKennzeichen = nationalitaetsKennzeichen;
	}

	public String getInlandsKennzeichen() {
		return inlandsKennzeichen;
	}

	public void setInlandsKennzeichen(String inlandsKennzeichen) {
		this.inlandsKennzeichen = inlandsKennzeichen;
	}

	public String getLandBezeichnung() {
		return landBezeichnung;
	}

	public void setLandBezeichnung(String landBezeichnung) {
		this.landBezeichnung = landBezeichnung;
	}

	public String getBenutzerId() {
		return benutzerId;
	}

	public void setBenutzerId(String benutzerId) {
		this.benutzerId = benutzerId;
	}

	public Date getDatumLetzteAenderung() {
		return datumLetzteAenderung;
	}

	public void setDatumLetzteAenderung(Date datumLetzteAenderung) {
		this.datumLetzteAenderung = datumLetzteAenderung;
	}

	public String getLandKurzbezeichnung() {
		return landKurzbezeichnung;
	}

	public void setLandKurzbezeichnung(String landKurzbezeichnung) {
		this.landKurzbezeichnung = landKurzbezeichnung;
	}

	public String getFernostKennzeichen() {
		return fernostKennzeichen;
	}

	public void setFernostKennzeichen(String fernostKennzeichen) {
		this.fernostKennzeichen = fernostKennzeichen;
	}

	public BigDecimal getPraefixNr1() {
		return praefixNr1;
	}

	public void setPraefixNr1(BigDecimal praefixNr1) {
		this.praefixNr1 = praefixNr1;
	}



	public void setKundenfirmen(Collection<Kundenfirma> kundenfirmen) {
		this.kundenfirmen = kundenfirmen;
	}



	
	public String toString() {
	    return landKurzbezeichnung;
	}
}

/*
 * J O S E F Java Object Solutions Enterprise Framework Copyright 2002 - 2004
 * Josef Witt GmbH
 */

package eu.wittgruppe.dias.util;

import javax.swing.*;

/**
 * Beschreibung: Enthält alle von der Applikation verwendeten Bilder<BR>
 * Copyright: Copyright (c) 2002<BR>
 * Organisation: Josef WITT GmbH<BR>
 * <BR>
 * 
 * @author Thomas Hoesl (THOHOE)
 */
public class Images {
    // ~ Static fields/initializers
    // ---------------------------------------------

    // Packagepath aus Properties ermitteln
    private static String PACKAGE = "/gfx/";

    // Alle Bilder laden und cachen
    //public static ImageIcon SPLASHSCREEN = loadImage( "debuar.jpg" );
    public static ImageIcon EXPAND_ALL = loadImage( "dias_expandall.gif" );
    public static ImageIcon COLLAPSE_ALL = loadImage( "dias_collapseall.gif" );    
    public static ImageIcon FARBE_LEVEL1 = loadImage( "dias_farbe3.gif" );    
    public static ImageIcon FARBE_LEVEL2 = loadImage( "dias_farbe2.gif" );    
    public static ImageIcon FARBE_LEVEL3 = loadImage( "dias_farbe1.gif" );
    public static ImageIcon ARTIKEL_SEARCH = loadImage( "dias_search_a.gif" );
    public static ImageIcon RECHNUNGEN_SEARCH = loadImage( "dias_search_r.gif" );
    public static ImageIcon WAIT = loadImage( "dias_wait.gif" );
    public static ImageIcon SELECT_SEITE = loadImage( "dias_select_seite.gif" );
    public static ImageIcon CRS_SEARCH = loadImage( "dias_crs_search.gif" );
    public static ImageIcon CLEAR = loadImage( "dias_clear.gif" );
    public static ImageIcon CLEAR_CO = loadImage( "dias_clear_co.gif" );
    public static ImageIcon PRINT = loadImage( "dias_print.gif" );
    public static ImageIcon PRINT_CO = loadImage( "dias_print_co.gif" );
    public static ImageIcon KUNDE_MATCH = loadImage( "dias_kunde_match.gif" );
    public static ImageIcon SPLASH = loadImage( "dias_splash.gif" );
    public static ImageIcon SPLASH_KLEIN = loadImage( "dias_splash_klein.gif" );
    public static ImageIcon STATISTIK = loadImage( "dias_statistik.gif" );
    public static ImageIcon FARBE_FILTER = loadImage( "dias_search.gif" );
    public static ImageIcon DIAS_HELP = loadImage( "dias_help.gif" );
    public static ImageIcon RUN_DEBUAR = loadImage( "dias_run_debuar.gif" );
    public static ImageIcon RUN_RETAB = loadImage("dias_run_retab.png");

    // von josef 5
    public static ImageIcon EXIT = loadImage("exit.png");
    public static ImageIcon INFO = loadImage("info.png");

    
    // Cache für eine eigene Instanz
    private static Images myself = null;

    // ~ Constructors
    // -----------------------------------------------------------

    // Constructor nur für Selbstverwendung
    private Images() {}

    // ~ Methods
    // ----------------------------------------------------------------

    /**
     * Lädt ein Bild aus dem Property-Package-Path.
     * 
     * @return Das geladene Bild oder ein leeres ImageIcon wenn keines gefunden
     *         werden konnte.
     */
    private static ImageIcon loadImage( String name ) {
        ImageIcon icon = new ImageIcon();

        // Instanz von 'selbst' cachen
        if( myself == null ) {
            myself = new Images();
        }

        try {
            icon = new ImageIcon( myself.getClass().getResource( PACKAGE + name ) );
        } catch( Exception ex ) {
            System.out.println( "Bild '" + PACKAGE + name + "' nicht gefunden!" );
        }

        return icon;
    }
}

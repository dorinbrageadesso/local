package eu.wittgruppe.dias.domain;

import jakarta.persistence.*;
import java.io.Serializable;

import static jakarta.persistence.FetchType.LAZY;

@Entity(name = "Vertriebsgebiet")
@Table(name = "vertrgebiet")
public class Vertriebsgebiet implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "CRSKZ")
	private String crossSellingKennzeichen = null;

	@Column(name = "EGKZ")
	private String eGKennzeichen = null;

	@Column(name = "HOSTKZ")
	private String hostKennzeichen = null;

	@Id
	@Column(name = "ID")
	private String id = null;

	@ManyToOne(fetch = LAZY)
	@JoinColumn(name = "KUNDENFIRMAID")
	private Kundenfirma kundenfirma = null;

	@Column(name = "PREISVT")
	private String preisVertriebsgebiet = null;

	@Column(name = "SORTKZ")
	private long sortierKennzeichen = 0;

	@Column(name = "VERDKZ")
	private String verichtungsKennzeichen = null;

	@Column(name = "VERTRGEBIET")
	private String vertriebsgebiet = null;

	@Column(name = "VERTRGEBIETBEZ")
	private String vertriebsgebietsBezeichnung = null;

	@Column(name = "VERTRGEBIETKURZBEZ")
	private String vertriebsgebietKurzBezeichnung = null;

	@Column(name = "VERTRGEBIETKZ")
	private String vertriebsgebietKennzeichen = null;

	@Column(name = "ZOLLDATENKZ")
	private String zolldatenKennzeichen = null;
	

	
	public String getCrossSellingKennzeichen() {
		return crossSellingKennzeichen;
	}

	public void setCrossSellingKennzeichen(String crossSellingKennzeichen) {
		this.crossSellingKennzeichen = crossSellingKennzeichen;
	}

	public String getEGKennzeichen() {
		return eGKennzeichen;
	}

	public void setEGKennzeichen(String kennzeichen) {
		eGKennzeichen = kennzeichen;
	}

	public String getHostKennzeichen() {
		return hostKennzeichen;
	}

	public void setHostKennzeichen(String hostKennzeichen) {
		this.hostKennzeichen = hostKennzeichen;
	}

	public String getId() {
		return id;
	}

	public Kundenfirma getKundenfirma() {
		return kundenfirma;
	}

	public void setKundenfirma(Kundenfirma kundenfirma) {
		this.kundenfirma = kundenfirma;
	}

	public String getPreisVertriebsgebiet() {
		return preisVertriebsgebiet;
	}

	public void setPreisVertriebsgebiet(String preisVertriebsgebiet) {
		this.preisVertriebsgebiet = preisVertriebsgebiet;
	}

	public long getSortierKennzeichen() {
		return sortierKennzeichen;
	}

	public void setSortierKennzeichen(long sortierKennzeichen) {
		this.sortierKennzeichen = sortierKennzeichen;
	}

	public String getVerichtungsKennzeichen() {
		return verichtungsKennzeichen;
	}

	public void setVerichtungsKennzeichen(String verichtungsKennzeichen) {
		this.verichtungsKennzeichen = verichtungsKennzeichen;
	}

	public String getVertriebsgebiet() {
		return vertriebsgebiet;
	}

	public void setVertriebsgebiet(String vertriebsgebiet) {
		this.vertriebsgebiet = vertriebsgebiet;
	}

	public String getVertriebsgebietsBezeichnung() {
		return vertriebsgebietsBezeichnung;
	}

	public void setVertriebsgebietsBezeichnung(
			String vertriebsgebietsBezeichnung) {
		this.vertriebsgebietsBezeichnung = vertriebsgebietsBezeichnung;
	}

	public String getVertriebsgebietKurzBezeichnung() {
		return vertriebsgebietKurzBezeichnung;
	}

	public void setVertriebsgebietKurzBezeichnung(
			String vertriebsgebietKurzBezeichnung) {
		this.vertriebsgebietKurzBezeichnung = vertriebsgebietKurzBezeichnung;
	}

	public String getVertriebsgebietKennzeichen() {
		return vertriebsgebietKennzeichen;
	}

	public void setVertriebsgebietKennzeichen(String vertriebsgebietKennzeichen) {
		this.vertriebsgebietKennzeichen = vertriebsgebietKennzeichen;
	}

	public String getZolldatenKennzeichen() {
		return zolldatenKennzeichen;
	}

	public void setZolldatenKennzeichen(String zolldatenKennzeichen) {
		this.zolldatenKennzeichen = zolldatenKennzeichen;
	}

}

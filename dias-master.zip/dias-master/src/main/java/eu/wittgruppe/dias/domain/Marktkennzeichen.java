package eu.wittgruppe.dias.domain;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity(name = "Marktkennzeichen")
@Table(name = "marktkz")
public class Marktkennzeichen implements Serializable {

    private static final long serialVersionUID = 1L;

    /*
     * Marktkennzeichen (Primary Key)
     */
    @Column(name = "MARKTKZ")
    private Long marktKennzeichen = null;

    /*
     * Bezeichnung
     */
    @Column(name = "MARKTKZBEZ")
    private String marktKennzeichenBezeichnung = null;

    /*
     * Umschl�sselung des WITT- in das OV-MarktKz
     */
    @Column(name = "MARKTKZOV")
    private Long marktKennzeichenOttoVersand = null;

    /*
     * Id (Unique Key)
     */
    @Id
    @Column(name = "ID")
    @org.hibernate.annotations.GenericGenerator(name = "getId", strategy = "witt.josef.orm.hibernate.IdGenerator")
    @GeneratedValue(generator = "getId")
    private String id = null;

    /*
     * Merkmalklassen Diamant
     */
    @OneToOne
	@JoinColumn(name = "MERKMALKLNR")
    private MerkmalklasseDiamant merkmalklasseDiamant = null;

    /*
     * Referenzierung der Tabelle MARKTKZGESCHLECHT
     */
    @Column(name = "MARKTKZGESCHLECHTID")
    private String marktKennzeichenGeschlechtId = null;

    /*
     * Referenzierung der Tabelle MARKTKZALTER
     */
    @Column(name = "MARKTKZALTERID")
    private String marktKennzeichenAlterId = null;

   
    public Marktkennzeichen() {}

    public Long getMarktKennzeichen() {
        return marktKennzeichen;
    }

    public void setMarktKennzeichen( Long marktKennzeichen ) {
        this.marktKennzeichen = marktKennzeichen;
    }

    public String getMarktKennzeichenBezeichnung() {
        return marktKennzeichenBezeichnung;
    }

    public void setMarktKennzeichenBezeichnung( String marktKennzeichenBezeichnung ) {
        this.marktKennzeichenBezeichnung = marktKennzeichenBezeichnung;
    }

    public Long getMarktKennzeichenOttoVersand() {
        return marktKennzeichenOttoVersand;
    }

    public void setMarktKennzeichenOttoVersand( Long marktKennzeichenOttoVersand ) {
        this.marktKennzeichenOttoVersand = marktKennzeichenOttoVersand;
    }

    public String getId() {
        return id;
    }

    public void setId( String id ) {
        this.id = id;
    }

    public String getMarktKennzeichenGeschlechtId() {
        return marktKennzeichenGeschlechtId;
    }

    public void setMarktKennzeichenGeschlechtId( String marktKennzeichenGeschlechtId ) {
        this.marktKennzeichenGeschlechtId = marktKennzeichenGeschlechtId;
    }

    public String getMarktKennzeichenAlterId() {
        return marktKennzeichenAlterId;
    }

    public void setMarktKennzeichenAlterId( String marktKennzeichenAlterId ) {
        this.marktKennzeichenAlterId = marktKennzeichenAlterId;
    }

    public String getMarktKennzeichenMitBezeichnung() {

        String marktkennzeichenMitBezeichnung = "";

        if( marktKennzeichen != null && marktKennzeichenBezeichnung != null ) {
            marktkennzeichenMitBezeichnung = marktKennzeichen + " - " + marktKennzeichenBezeichnung;
        } else if( marktKennzeichen != null && marktKennzeichenBezeichnung == null ) {
            marktkennzeichenMitBezeichnung = marktKennzeichen + " - " + "(Keine Bezeichnung)";
        } else if( marktKennzeichen == null && marktKennzeichenBezeichnung != null ) {
            marktkennzeichenMitBezeichnung = marktKennzeichenBezeichnung;
        }

        return marktkennzeichenMitBezeichnung;
    }

    public MerkmalklasseDiamant getMerkmalklasseDiamant() {
		return merkmalklasseDiamant;
	}
    
    public void setMerkmalklasseDiamant(
			MerkmalklasseDiamant merkmalklasseDiamant) {
		this.merkmalklasseDiamant = merkmalklasseDiamant;
	}
    
}

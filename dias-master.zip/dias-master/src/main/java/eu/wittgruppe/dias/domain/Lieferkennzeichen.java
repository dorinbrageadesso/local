package eu.wittgruppe.dias.domain;

import org.apache.commons.lang.builder.ToStringBuilder;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;

@Entity(name = "Lieferkennzeichen")
@Table(name = "likz")
public class Lieferkennzeichen implements Serializable {

	private static final long serialVersionUID = 1L;

	/*
	 * Lieferkennzeichen z. B. ausverkauft
	 */
	@Id
	@Column(name = "LIKZ")
	private Long liKennzeichen = null;

	/*
	 * Bezeichnung des Lieferkennzeichens
	 */
	@Column(name = "LIKZBEZ")
	private String liKennzeichenBezeichnung = null;

	/*
	 * Kurzbezeichnung des Lieferkennzeichens z. B. AU fuer ausverkauft
	 */
	@Column(name = "LIKZKURZBEZ")
	private String liKennzeichenKurzBezeichnung = null;

	public Lieferkennzeichen() {
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public Long getLiKennzeichen() {
		return liKennzeichen;
	}

	public void setLiKennzeichen(Long liKennzeichen) {
		this.liKennzeichen = liKennzeichen;
	}

	public String getLiKennzeichenBezeichnung() {
		return liKennzeichenBezeichnung;
	}

	public void setLiKennzeichenBezeichnung(String liKennzeichenBezeichnung) {
		this.liKennzeichenBezeichnung = liKennzeichenBezeichnung;
	}

	public String getLiKennzeichenKurzBezeichnung() {
		return liKennzeichenKurzBezeichnung;
	}

	public void setLiKennzeichenKurzBezeichnung(
			String liKennzeichenKurzBezeichnung) {
		this.liKennzeichenKurzBezeichnung = liKennzeichenKurzBezeichnung;
	}
}

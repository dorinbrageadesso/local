package eu.wittgruppe.dias;


import eu.wittgruppe.benutzerverwaltung.rest.client.BenutzerverwaltungRestClient;
import eu.wittgruppe.core.customersearch.client.CustomersearchRestClient;
import eu.wittgruppe.core.medien.client.MedienRestClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
public class DiasConfiguration {
   @Value("${core.medien.service}")
   private String medienService;
   @Value("${core.medien.auth.username}")
   private String medienUsername;
   @Value("${core.medien.auth.password}")
   private String medienPassword;

   @Value("${core.benutzer.service}")
   private String benutzerService;
   @Value("${core.benutzer.auth.username}")
   private String benutzerUserName;
   @Value("${core.benutzer.auth.password}")
   private String benutzerPassword;

   @Bean
   public MedienRestClient medienRestClient() {
      return new MedienRestClient(medienService, medienUsername, medienPassword);
   }

   @Bean
   public CustomersearchRestClient customersearchRestClient(
           @Value("${core.customersearch.service}") String baseUrl, //
           @Value("${core.customersearch.auth.username:}") String username, //
           @Value("${core.customersearch.auth.password:}") String password) {
      return new CustomersearchRestClient(baseUrl, username, password);
   }

   @Bean
   public BenutzerverwaltungRestClient benutzerverwaltungRestClient(){
      return new BenutzerverwaltungRestClient(benutzerService, benutzerUserName, benutzerPassword );
   }

}

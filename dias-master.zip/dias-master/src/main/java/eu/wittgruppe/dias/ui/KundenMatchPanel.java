package eu.wittgruppe.dias.ui;

import eu.wittgruppe.dias.controller.KundenMatchPanelController;
import eu.wittgruppe.dias.ui.renderer.KundenMatchTableRenderer;
import eu.wittgruppe.dias.util.GenericTableModel;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import witt.josef.uiswing.ui.LimitedDocument;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;

public class KundenMatchPanel extends JPanel {
	
	private KundenMatchPanelController controller = null;
	
	private String tableColumns[] = { "KdNr", "Kundenfirma", "Vorname", "Nachname", "Strasse", "HausNr", 
			  "HausNrZusatz", "PLZ", "Ort" };
	private GenericTableModel tableModel;
	
	private JPanel jPanel = null;
	private JPanel northPanel = null;
	private JPanel centerPanel = null;
	private JTextField vornameTextField = null;
	private JTextField nachnameTextField = null;
	private JTextField strasseTextField = null;
	private JTextField hsnrTextField = null;
	private JTextField plzTextField = null;
	private JTextField ortTextField = null;
	private JScrollPane kundeScrollPane = null;
	private JTable kundeTable = null;
	private JButton searchButton = null;
	private JLabel fillerLabel = null;
	private JLabel vornameLabel = null;
	private JLabel nachnameLabel = null;
	private JLabel strasseLabel = null;
	private JLabel hsnrLabel = null;
	private JLabel plzLabel = null;
	private JLabel ortLabel = null;


	
	public KundenMatchPanel(KundenMatchPanelController controller) {		
		this.controller = controller;
		initialize();
		
	}	
	
	
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setLayout(new BorderLayout());
		this.setSize(800, 600);
		//this.setTitle("Kundensuche");	
		this.setPreferredSize(new java.awt.Dimension(800, 600));
		this.add(getJPanel(), java.awt.BorderLayout.CENTER);
		//this.setModal(false);
		this.tableModel = new GenericTableModel( tableColumns, 0 );
		getKundeTable().setModel(tableModel);
		getKundeTable().setRowHeight( 20 );
		getKundeTable().setDefaultRenderer( Object.class, new KundenMatchTableRenderer() );
	
		
	}

	/**
	 * This method initializes jPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel() {
		if (jPanel == null) {
			jPanel = new JPanel();
			jPanel.setLayout(new BorderLayout());
			jPanel.add(getNorthPanel(), java.awt.BorderLayout.NORTH);
			jPanel.add(getCenterPanel(), java.awt.BorderLayout.CENTER);
			//jPanel.add(getSouthPanel(), java.awt.BorderLayout.SOUTH);
		}
		return jPanel;
	}

	/**
	 * This method initializes northPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getNorthPanel() {
		if (northPanel == null) {
			GridBagConstraints gridBagConstraints19 = new GridBagConstraints();
			gridBagConstraints19.gridx = 1;
			gridBagConstraints19.insets = new java.awt.Insets(10,2,0,0);
			gridBagConstraints19.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints19.gridy = 4;
			ortLabel = new JLabel();
			ortLabel.setText("Ort:");
			GridBagConstraints gridBagConstraints18 = new GridBagConstraints();
			gridBagConstraints18.gridx = 0;
			gridBagConstraints18.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints18.insets = new java.awt.Insets(10,10,0,0);
			gridBagConstraints18.gridy = 4;
			plzLabel = new JLabel();
			plzLabel.setText("PLZ:");
			GridBagConstraints gridBagConstraints17 = new GridBagConstraints();
			gridBagConstraints17.gridx = 3;
			gridBagConstraints17.insets = new java.awt.Insets(2,2,0,0);
			gridBagConstraints17.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints17.gridy = 2;
			hsnrLabel = new JLabel();
			hsnrLabel.setText("HausNr.:");
			GridBagConstraints gridBagConstraints15 = new GridBagConstraints();
			gridBagConstraints15.gridx = 0;
			gridBagConstraints15.insets = new java.awt.Insets(2,10,0,0);
			gridBagConstraints15.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints15.gridy = 2;
			strasseLabel = new JLabel();
			strasseLabel.setText("Strasse:");
			GridBagConstraints gridBagConstraints14 = new GridBagConstraints();
			gridBagConstraints14.gridx = 2;
			gridBagConstraints14.insets = new java.awt.Insets(10,2,0,0);
			gridBagConstraints14.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints14.gridy = 0;
			nachnameLabel = new JLabel();
			nachnameLabel.setText("Nachname:");
			GridBagConstraints gridBagConstraints13 = new GridBagConstraints();
			gridBagConstraints13.gridx = 0;
			gridBagConstraints13.insets = new java.awt.Insets(10,10,0,0);
			gridBagConstraints13.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints13.gridy = 0;
			vornameLabel = new JLabel();
			vornameLabel.setText("Vorname:");
			
			GridBagConstraints gridBagConstraints11 = new GridBagConstraints();
			gridBagConstraints11.gridx = 5;
			gridBagConstraints11.fill = java.awt.GridBagConstraints.HORIZONTAL;
			gridBagConstraints11.weightx = 1.0;
			gridBagConstraints11.gridy = 0;
			fillerLabel = new JLabel();
			fillerLabel.setMaximumSize(new Dimension(1111111, 16));
			fillerLabel.setPreferredSize(new Dimension(1, 16));
			fillerLabel.setText("");
			fillerLabel.setMinimumSize(new Dimension(1, 16));
			GridBagConstraints gridBagConstraints8 = new GridBagConstraints();
			gridBagConstraints8.gridx = 4;
			gridBagConstraints8.insets = new java.awt.Insets(0,5,15,0);
			gridBagConstraints8.anchor = java.awt.GridBagConstraints.NORTH;
			gridBagConstraints8.gridy = 5;
			GridBagConstraints gridBagConstraints6 = new GridBagConstraints();
			gridBagConstraints6.fill = java.awt.GridBagConstraints.NONE;
			gridBagConstraints6.gridy = 5;
			gridBagConstraints6.weightx = 0.0;
			gridBagConstraints6.gridwidth = 3;
			gridBagConstraints6.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints6.insets = new java.awt.Insets(0,2,10,0);
			gridBagConstraints6.gridx = 1;
			GridBagConstraints gridBagConstraints4 = new GridBagConstraints();
			gridBagConstraints4.fill = java.awt.GridBagConstraints.NONE;
			gridBagConstraints4.gridy = 5;
			gridBagConstraints4.weightx = 0.0;
			gridBagConstraints4.insets = new java.awt.Insets(0,10,10,0);
			gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints4.gridx = 0;
			GridBagConstraints gridBagConstraints3 = new GridBagConstraints();
			gridBagConstraints3.fill = java.awt.GridBagConstraints.NONE;
			gridBagConstraints3.gridy = 3;
			gridBagConstraints3.weightx = 0.0;
			gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints3.insets = new java.awt.Insets(1,2,0,0);
			gridBagConstraints3.gridx = 3;
			GridBagConstraints gridBagConstraints2 = new GridBagConstraints();
			gridBagConstraints2.fill = java.awt.GridBagConstraints.NONE;
			gridBagConstraints2.gridy = 3;
			gridBagConstraints2.weightx = 0.0;
			gridBagConstraints2.gridwidth = 3;
			gridBagConstraints2.insets = new java.awt.Insets(1,10,0,0);
			gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints2.gridx = 0;
			GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
			gridBagConstraints1.fill = java.awt.GridBagConstraints.NONE;
			gridBagConstraints1.gridx = 2;
			gridBagConstraints1.gridy = 1;
			gridBagConstraints1.gridwidth = 3;
			gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints1.insets = new java.awt.Insets(1,2,0,0);
			gridBagConstraints1.weightx = 0.0;
			GridBagConstraints gridBagConstraints = new GridBagConstraints();
			gridBagConstraints.fill = java.awt.GridBagConstraints.NONE;
			gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints.gridx = 0;
			gridBagConstraints.gridy = 1;
			gridBagConstraints.gridwidth = 2;
			gridBagConstraints.insets = new java.awt.Insets(1,10,0,0);
			gridBagConstraints.weightx = 0.0;
			northPanel = new JPanel();
			northPanel.setLayout(new GridBagLayout());
			northPanel.add(getVornameTextField(), gridBagConstraints);
			northPanel.add(getNachnameTextField(), gridBagConstraints1);
			northPanel.add(getStrasseTextField(), gridBagConstraints2);
			northPanel.add(getHsnrTextField(), gridBagConstraints3);
			northPanel.add(getPlzTextField(), gridBagConstraints4);
			northPanel.add(getOrtTextField(), gridBagConstraints6);
			northPanel.add(getJButton(), gridBagConstraints8);
			northPanel.add(vornameLabel, gridBagConstraints13);
			northPanel.add(nachnameLabel, gridBagConstraints14);
			northPanel.add(strasseLabel, gridBagConstraints15);
			northPanel.add(hsnrLabel, gridBagConstraints17);
			northPanel.add(plzLabel, gridBagConstraints18);
			northPanel.add(ortLabel, gridBagConstraints19);
			northPanel.add(fillerLabel, gridBagConstraints11);
		}
		return northPanel;
	}

	/**
	 * This method initializes centerPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getCenterPanel() {
		if (centerPanel == null) {
			GridBagConstraints gridBagConstraints5 = new GridBagConstraints();
			gridBagConstraints5.fill = java.awt.GridBagConstraints.BOTH;
			gridBagConstraints5.weighty = 1.0;
			gridBagConstraints5.insets = new java.awt.Insets(10,5,10,5);
			gridBagConstraints5.weightx = 1.0;
			centerPanel = new JPanel();
			centerPanel.setLayout(new GridBagLayout());
			centerPanel.add(getKundeScrollPane(), gridBagConstraints5);
		}
		return centerPanel;
	}

	/**
	 * This method initializes vornameTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	public JTextField getVornameTextField() {
		if (vornameTextField == null) {
			vornameTextField = new JTextField();
			LimitedDocument doc = new LimitedDocument(20, LimitedDocument.ALPHA_NUMERIC);
			vornameTextField.setDocument(doc);
			vornameTextField.setPreferredSize(new java.awt.Dimension(120,20));
			vornameTextField.setMaximumSize(new java.awt.Dimension(120,20));
			vornameTextField.setMinimumSize(new java.awt.Dimension(120,20));
		}
		return vornameTextField;
	}

	/**
	 * This method initializes nachnameTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getNachnameTextField() {
		if (nachnameTextField == null) {
			nachnameTextField = new JTextField();
			LimitedDocument doc = new LimitedDocument(30, LimitedDocument.ALPHA_NUMERIC);
			nachnameTextField.setDocument(doc);
			nachnameTextField.setMaximumSize(new java.awt.Dimension(155,20));
			nachnameTextField.setPreferredSize(new java.awt.Dimension(155,20));
			nachnameTextField.setMinimumSize(new java.awt.Dimension(155,20));
		}
		return nachnameTextField;
	}

	/**
	 * This method initializes strasseTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getStrasseTextField() {
		if (strasseTextField == null) {
			strasseTextField = new JTextField();
			LimitedDocument doc = new LimitedDocument(30, LimitedDocument.ALPHA_NUMERIC);
			strasseTextField.setDocument(doc);
			strasseTextField.setPreferredSize(new java.awt.Dimension(180,20));
			strasseTextField.setMaximumSize(new java.awt.Dimension(180,20));
			strasseTextField.setMinimumSize(new java.awt.Dimension(180,20));
		}
		return strasseTextField;
	}

	/**
	 * This method initializes hsnrTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getHsnrTextField() {
		if (hsnrTextField == null) {
			hsnrTextField = new JTextField();
			LimitedDocument doc = new LimitedDocument(4, LimitedDocument.NUMBER);
			hsnrTextField.setDocument(doc);
			hsnrTextField.setMinimumSize(new java.awt.Dimension(89,20));
			hsnrTextField.setMaximumSize(new java.awt.Dimension(89,20));
			hsnrTextField.setPreferredSize(new java.awt.Dimension(89,20));
		}
		return hsnrTextField;
	}

	/**
	 * This method initializes plzTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getPlzTextField() {
		if (plzTextField == null) {
			plzTextField = new JTextField();
			LimitedDocument doc = new LimitedDocument(7, LimitedDocument.ALPHA_NUMERIC);
			plzTextField.setDocument(doc);
			plzTextField.setPreferredSize(new java.awt.Dimension(50,20));
			plzTextField.setMaximumSize(new java.awt.Dimension(50,20));
			plzTextField.setMinimumSize(new java.awt.Dimension(50,20));
		}
		return plzTextField;
	}

	/**
	 * This method initializes ortTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getOrtTextField() {
		if (ortTextField == null) {
			ortTextField = new JTextField();
			LimitedDocument doc = new LimitedDocument(30, LimitedDocument.ALPHA_NUMERIC);
			ortTextField.setDocument(doc);
			ortTextField.setPreferredSize(new java.awt.Dimension(220,20));
			ortTextField.setMaximumSize(new java.awt.Dimension(220,20));
			ortTextField.setMinimumSize(new java.awt.Dimension(220,20));
		}
		return ortTextField;
	}

	/**
	 * This method initializes kundeScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getKundeScrollPane() {
		if (kundeScrollPane == null) {
			kundeScrollPane = new JScrollPane();
			kundeScrollPane.setViewportView(getKundeTable());
		}
		return kundeScrollPane;
	}

	/**
	 * This method initializes kundeTable	
	 * 	
	 * @return javax.swing.JTable	
	 */
	public JTable getKundeTable() {
		if (kundeTable == null) {
			kundeTable = new JTable();			
		}
		return kundeTable;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (searchButton == null) {
			searchButton = new JButton();
			searchButton.setMaximumSize(new Dimension(115, 26));
			searchButton.setPreferredSize(new Dimension(115, 26));
			searchButton.setText("Suchen (F3)");
			searchButton.setToolTipText("Kunden suchen");
			searchButton.setMinimumSize(new Dimension(115, 26));
			
			OnSearchButtonClick listener = new OnSearchButtonClick();
			 searchButton.addActionListener(listener);
			
			searchButton.registerKeyboardAction( listener, 
					 "F3", KeyStroke.getKeyStroke( KeyEvent.VK_F3, 0 ), 
					 JComponent.WHEN_IN_FOCUSED_WINDOW );
			searchButton.registerKeyboardAction( listener, 
					 "ENTER", KeyStroke.getKeyStroke( KeyEvent.VK_ENTER, 0 ), 
					 JComponent.WHEN_IN_FOCUSED_WINDOW );		 
					
		}
		return searchButton;
	}
	
	private class OnSearchButtonClick implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {			
			
			String vorName = getVornameTextField().getText().trim();			
			String nachName = getNachnameTextField().getText().trim();			
			String strasse = getStrasseTextField().getText().trim();			
			String hausNr = getHsnrTextField().getText().trim();			
			String plz = getPlzTextField().getText().trim();			
			String ort = getOrtTextField().getText().trim();
			
			
			boolean validSuchMuster = false;
			
//			 Name + Straße + Hausnummer(optional) + (Postleitzahl oder Ort)
			if ( StringUtils.isNotEmpty(nachName) && StringUtils.isNotEmpty(strasse) &&
				(StringUtils.isNotEmpty(plz) || StringUtils.isNotEmpty(ort))  ) {					
				validSuchMuster = true;
			}
			// Straße + Hausnummer(optional) + (Postleitzahl oder Ort)
			else if ( StringUtils.isNotEmpty(strasse) && 
					 (StringUtils.isNotEmpty(plz) || StringUtils.isNotEmpty(ort))  ) {
				validSuchMuster = true;
			}
			// Name + (Postleitzahl oder Ort)
			else if ( StringUtils.isNotEmpty(nachName) && 
					 (StringUtils.isNotEmpty(plz) || StringUtils.isNotEmpty(ort)) ) {
				validSuchMuster = true;
			}
			
//			 Es müssen mindestens 2 Suchkriterien ausgewählt sein
			if (validSuchMuster ) {
				controller.searchKunden(vorName, nachName, strasse,
										new Long(NumberUtils.toLong(hausNr)),
										plz, ort);	
			}
			else {
				JOptionPane.showMessageDialog(null,
						  "Kein gültiges Suchmuster. Bitte Suchmuster ändern!\n\n" +
						  " - Name + (Postleitzahl oder Ort) \n" +
						  " - Straße + Hausnummer(optional) + (Postleitzahl oder Ort)\n" +
						  " - Name + Straße + Hausnummer(optional) + (Postleitzahl oder Ort)",
						  "Suchen",
						  JOptionPane.WARNING_MESSAGE);	
			}
			
			
		}
	}
	
	public GenericTableModel getTableModel() {
		return tableModel;
	}
	
	
	
}  //  @jve:decl-index=0:visual-constraint="10,10"

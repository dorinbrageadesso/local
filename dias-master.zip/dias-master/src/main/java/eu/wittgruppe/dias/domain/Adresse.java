package eu.wittgruppe.dias.domain;

import org.apache.commons.lang.builder.ToStringBuilder;

import jakarta.persistence.*;
import java.io.Serializable;
import java.sql.Date;

import static jakarta.persistence.FetchType.LAZY;

@Entity(name = "Adresse")
@Table(name = "adresse")
public class Adresse implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "AENDBEDMAN")
	private String aendererManuell = null;

	@Column(name = "AENDDATMAN")
	private Date aenderungsdatumManuell = null;

	@Column(name = "AENDDATSYS")
	private Date aenderungsdatumSystem = null;

	@Column(name = "HSNR")
	private Long hausnummer = null;

	@Column(name = "HSNRZUS1")
	private String hausnummerZusatz1 = null;

	@Column(name = "HSNRZUS2")
	private String hausnummerZusatz2 = null;

	@Id
	private String id = null;

	@ManyToOne(fetch = LAZY)
	@JoinColumn(name = "LANDID")
	private Land land;

	@Column(name = "LETZTAENDDAT")
	private Date letztesAenderungsdatum = null;

	@Column(name = "ORT")
	private String ort = null;

	@Column(name = "PLZ")
	private String postleitzahl = null;

	@Column(name = "STATUS")
	private Long status = null;

	@Column(name = "STR")
	private String strasse = null;

	public Adresse() {
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public String getAendererManuell() {
		return aendererManuell;
	}

	public void setAendererManuell(String aendererManuell) {
		this.aendererManuell = aendererManuell;
	}

	public Date getAenderungsdatumManuell() {
		return aenderungsdatumManuell;
	}

	public void setAenderungsdatumManuell(Date aenderungsdatumManuell) {
		this.aenderungsdatumManuell = aenderungsdatumManuell;
	}

	public Date getAenderungsdatumSystem() {
		return aenderungsdatumSystem;
	}

	public void setAenderungsdatumSystem(Date aenderungsdatumSystem) {
		this.aenderungsdatumSystem = aenderungsdatumSystem;
	}

	public Long getHausnummer() {
		return hausnummer;
	}

	public void setHausnummer(Long hausnummer) {
		this.hausnummer = hausnummer;
	}

	public String getHausnummerZusatz1() {
		return hausnummerZusatz1;
	}

	public void setHausnummerZusatz1(String hausnummerZusatz1) {
		this.hausnummerZusatz1 = hausnummerZusatz1;
	}

	public String getHausnummerZusatz2() {
		return hausnummerZusatz2;
	}

	public void setHausnummerZusatz2(String hausnummerZusatz2) {
		this.hausnummerZusatz2 = hausnummerZusatz2;
	}

	public String getId() {
		return id;
	}

	public Land getLand() {
		return land;
	}

	public void setLand(Land land) {
		this.land = land;
	}

	public Date getLetztesAenderungsdatum() {
		return letztesAenderungsdatum;
	}

	public void setLetztesAenderungsdatum(Date letztesAenderungsdatum) {
		this.letztesAenderungsdatum = letztesAenderungsdatum;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getPostleitzahl() {
		return postleitzahl;
	}

	public void setPostleitzahl(String postleitzahl) {
		this.postleitzahl = postleitzahl;
	}

	public Long getStatus() {
		return status;
	}

	public void setStatus(Long status) {
		this.status = status;
	}

	public String getStrasse() {
		return strasse;
	}

	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}
}

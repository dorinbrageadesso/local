package eu.wittgruppe.dias.util.printer;


import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import purejavacomm.SerialPort;
import witt.josef.peripheral.SerialStream;
import witt.josef.printer.valentin.Etikett;
import witt.josef.printer.valentin.PrinterConstants;

import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;

/**
 * Valentin Etikettendrucker
 * 
 * @author Mather
 * @author Thosel
 * @version 1.0 - Initial
 * @version 1.1 - Die Etikettl&auml;nge und das Schlitzma&szlig; wird aus dem Renderer gelesen
 *  
 */
@Slf4j
public class ValentinPrinter2 {
    
    public static final int PRINTER_NOT_READY = -1;
    public static final int PRINTER_OK = 64;
    public static final int PRINTER_BUSY = 80;
    public static final int PRINTER_STOP_PRESSED = 88;
    public static final int PRINTER_CUTTER_ERROR = 84;
    public static final int PRINTER_ETIKETT_ERROR = 90;
    public static final int PRINTER_ETIKETT_OUT = 82;
    public static final int PRINTER_TRANSFER_ERROR = 89;
    
    private final int POS_STATUS_BYTE = 2;  
    
    private SerialPort serialPort = null;
    
    public ValentinPrinter2(SerialPort serialPort) {
        this.serialPort = serialPort;
    }       
    
    public int getPrinterStatus() throws IOException {
        
        int status;                 
        log.debug("Status Printer angefordert...");
        SerialStream stream = new SerialStream(serialPort);
        // StatusRequest bauen [ETB]S[SOH]
        StringBuffer statusRequest = new StringBuffer();
        statusRequest.append(PrinterConstants.SOH);
        statusRequest.append(PrinterConstants.STA);
        statusRequest.append(PrinterConstants.ETB);
        
        stream.write(statusRequest);        
        
        StringBuffer readBuffer = stream.read();
        log.debug("Status '" + readBuffer.toString() + "'");
        
        if (StringUtils.isEmpty(readBuffer.toString())) {
            status = PRINTER_NOT_READY;
        }
        // -1 wegen Array von 0
        else {
            status = readBuffer.charAt(POS_STATUS_BYTE-1);
        }                   
        
        stream.close();     
        
        return status;
        
    }   

    public String getPrinterStatusMessage() throws IOException {
        
        String printerStatus = null;                
                    
        int statusByte = getPrinterStatus();
        
        switch (statusByte) {
        case PRINTER_OK:
            printerStatus = "Drucker ok";
            break;
        case PRINTER_BUSY:
            printerStatus = "Drucker beschäftigt";
            break;
        case PRINTER_STOP_PRESSED:
            printerStatus = "Drucker Stopptaste gedrückt";
            break;
        case PRINTER_CUTTER_ERROR:
            printerStatus = "Drucker Messerfehler";
            break;  
        case PRINTER_ETIKETT_ERROR:
            printerStatus = "Drucker Etiketten Fehler";
            break;
        case PRINTER_ETIKETT_OUT:
            printerStatus = "Drucker Etiketten aus";            
            break;  
        case PRINTER_TRANSFER_ERROR:
            printerStatus = "Drucker Transferband Fehler";
            break;
        case PRINTER_NOT_READY:
            printerStatus = "Drucker ist nicht bereit";
            break;
        default:
            printerStatus = "Unbekannter Status : " + (char)statusByte;
            break;
        }   
        
        return printerStatus;
        
    }
    
    public void print(Etikett etikett, ValentinEtikettRenderer renderer)
    throws IOException {
        
        // Etikettdaten werden maskiert
        Collection<String> colFields = renderer.addMask(etikett);
        // Collection zu einem Stringbuffer zusammenfuegen
        StringBuffer fieldBuffer = createStringBufferFromFields(colFields);
        
        SerialStream stream = null;
        try {
            // Stream erzeugen und Etikett drucken
            stream = new SerialStream(serialPort);
            // Initialisierung des Drucks
            stream.write(getPrintInitialMask(renderer));
            // Etikettdaten uebertragen
            stream.write(fieldBuffer);
            // Druck starten -> GO
            stream.write(getPrintPostMask(colFields.size()));
            stream.flushOutputStream();
        } catch (IOException e) {
            log.error("Fehler Etikett drucken", e);
            throw e;
        }
        finally {
            stream.close();
        }       
    }

    private StringBuffer createStringBufferFromFields(Collection<String> colFields) {
        StringBuffer fieldBuffer = new StringBuffer();
        for (Iterator<String> iter = colFields.iterator(); iter.hasNext();) {
            fieldBuffer.append(iter.next());            
        }
        return fieldBuffer;
    }
    
    private StringBuffer getPrintInitialMask(ValentinEtikettRenderer renderer) {        
        
         String laenge = StringUtils.leftPad( new Long(renderer.getEtikettLaengeInMillimeter()).toString(),7,'0');
         String schlitz = StringUtils.leftPad( new Long(renderer.getSchlitzabstandInMillimeter()).toString(),5,'0');
        
         StringBuffer initalBuffer = new StringBuffer();    
         //mm/sek.           Druckstaerke    Messeroffset 1     0-Pkt-Versch.   X-Wertversch. einst. Abrisskante einstellen
         //Haftetiketten     Etikettenlaenge     Schlitzlaenge      Messerbetr.art  Stck b. Messerbetr.  Spendebetr.art. 0
         //Spenderpegel LS   Etikett-LS-Typ  Transferbandueberwachung
         initalBuffer.append(PrinterConstants.SOH + "FCAA--r200-----" + PrinterConstants.ETB);
         initalBuffer.append(PrinterConstants.SOH + "FCAB--r180-----" + PrinterConstants.ETB);
         initalBuffer.append(PrinterConstants.SOH + "FCCC--r+215----" + PrinterConstants.ETB);
         initalBuffer.append(PrinterConstants.SOH + "FCCD--r+000----" + PrinterConstants.ETB);
         initalBuffer.append(PrinterConstants.SOH + "FCCE--r+030----" + PrinterConstants.ETB);
         initalBuffer.append(PrinterConstants.SOH + "FCCG--r+000----" + PrinterConstants.ETB);
         initalBuffer.append(PrinterConstants.SOH + "FCDA--r0-------" + PrinterConstants.ETB);
         initalBuffer.append(PrinterConstants.SOH + "FCDD--r3-------" + PrinterConstants.ETB);
         initalBuffer.append(PrinterConstants.SOH + "FBBD--r0001----" + PrinterConstants.ETB);
         initalBuffer.append(PrinterConstants.SOH + "FCDC--r0-------" + PrinterConstants.ETB);       
         initalBuffer.append(PrinterConstants.SOH + "FCCF--r+25-----" + PrinterConstants.ETB);
         initalBuffer.append(PrinterConstants.SOH + "FCDE--r0-------" + PrinterConstants.ETB);
         initalBuffer.append(PrinterConstants.SOH + "FCDB--r10------" + PrinterConstants.ETB);

        return initalBuffer;
        
    }   
    
    private StringBuffer getPrintPostMask(int anzFields) {
        
          StringBuffer postBuffer = new StringBuffer();     
        
          postBuffer.append(PrinterConstants.SOH + "FBAA--r" + Integer.toString(anzFields) + PrinterConstants.ETB);       
          postBuffer.append(PrinterConstants.SOH + "FBBA--r00001---" + PrinterConstants.ETB); 
          postBuffer.append(PrinterConstants.SOH + "FBC---r--------" + PrinterConstants.ETB);
        
          return postBuffer;
    }
    
}

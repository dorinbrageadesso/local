/*
 * J O S E F Java Object Solutions Enterprise Framework Copyright 2002 - 2004
 * Josef Witt GmbH
 */

package eu.wittgruppe.dias.util;

import java.lang.reflect.Method;
import java.util.*;

/**
 * Stellt Utility-Methoden mit Reflection zur Verfügung.
 * 
 * @author Hoesl Thomas
 * @version $Revision$
 */
public class ObjectUtils {

    /**
     * Kann benutzt werden, wenn die Existenz eines Objektes gegen eine Liste
     * mit anderem Objekttypen geprüft werden soll.
     * 
     * @param object
     *            Object dessen Anwesenheit in collection überprüft werden soll.
     * 
     * @param objectAttribut
     *            Attribut das aus object für den Objektvergleich extrahiert
     *            werden soll.
     * 
     * @param collection
     *            Collection in der gesucht werden soll.
     * 
     * @param collectionItemAttribut
     *            Attribut das aus den Items in collection für den
     *            Objektvergleich extrahiert werden soll.
     * 
     * @return true, wenn das in object definierte Attribut objectAttribut in
     *         einem der extrahierten Attribute collectionItemAttribut in
     *         collection vorkommt. Sonst: false.
     */
    public static boolean isObjectIn(Object object, String objectAttribut, Collection collection,
            String collectionItemAttribut) {
        Object key = ObjectUtils.extractAttribute(object, objectAttribut);

        Map index = ObjectUtils.indexCollection(collection, collectionItemAttribut);

        return index.containsKey(key);
    }

    /**
     * Extrahiert aus einer Menge von Objekten ein Attribut. Ist eines dieser
     * extrahierten Attribute eine Collection, so werden alle Objekte dieser
     * Collection in die Ergebnismenge aufgenommen - die Collection selbst
     * taucht nicht in der Ergebnismenge auf!
     * 
     * @param col
     *            Menge von Objekten aus denen das benannte Attribut extrahiert
     *            werden soll.
     * 
     * @param attribute
     *            Der Name des Attribut, dass aus jedem Object der übergebenen
     *            Collection extrahiert werden soll.
     * 
     * @return Neue Collection mit den extrahierten Attributen.
     */
    public static Collection extractAttribute(Collection col, String attribute) {
        return extractAttribute(col, attribute, true);
    }

    /**
     * Extrahiert aus einer Menge von Objekten ein Attribut. Ist
     * extractCollection == true und eines dieser extrahierten Attribute eine
     * Collection, so werden alle Objekte dieser Collection in die Ergebnismenge
     * aufgenommen - die Collection selbst taucht nicht in der Ergebnismenge auf
     * (flach). Ist extractCollection == false wird die Collection selbst in die
     * Ergebnismenge aufgenommen.
     * 
     * @param col
     *            Menge von Objekten aus denen das benannte Attribut extrahiert
     *            werden soll.
     * 
     * @param attribute
     *            Der Name des Attribut, dass aus jedem Object der übergebenen
     *            Collection extrahiert werden soll.
     * 
     * @param extractCollection
     *            Ist extractCollection == true und eines dieser extrahierten
     *            Attribute eine Collection, so werden alle Objekte dieser
     *            Collection in die Ergebnismenge aufgenommen - die Collection
     *            selbst taucht nicht in der Ergebnismenge auf (flach). Ist
     *            extractCollection == false wird die Collection selbst in die
     *            Ergebnismenge aufgenommen.
     * 
     * @return Neue Collection mit den extrahierten Attributen.
     */
    public static Collection extractAttribute(Collection col, String attribute, boolean extractCollection) {
        if ((col == null) || (col.size() == 0)) {
            return col;
        }

        ArrayList newList = new ArrayList(col.size());
        Iterator iter = col.iterator();

        while (iter.hasNext()) {
            Object x = extractAttribute(iter.next(), attribute);
            if (extractCollection && x instanceof Collection) {
                newList.addAll((Collection) x);
            } else {
                newList.add(x);
            }
        }

        return newList;
    }

    /**
     * Extrahiert aus object das Attribut mit Namen attribute. Das Attribut darf
     * das Prefix "get" nicht enthalten, da dieser dem Wert in attribut
     * vorangesetzt wird. Beispiel: Attribut "Name" extrahiert den Wert aus den
     * Getter "getName()".
     * 
     * @param object
     *            Das Objekt aus dem das Attribut extrahiert werden soll.
     * 
     * @param attribute
     *            Der Name des Attributes (ohne Prefix "get").
     * 
     * @return Das extrahierte Attribut bzw. null wenn das Attribut nicht
     *         gefunden werden konnte.
     */
    public static Object extractAttribute(Object object, String attribute) {
        // Attribut untersuchen
        String attrPart1 = null;
        String attrPart2 = null;

        int indexOf = attribute.indexOf('.');

        if ((indexOf > -1) && (attribute.length() > indexOf)) {
            attrPart1 = attribute.substring(0, indexOf);
            attrPart2 = attribute.substring(indexOf + 1);
        } else {
            attrPart1 = attribute;
        }

        try {
            Class clazz = object.getClass();

            Method method = null;
            try {
                method = clazz.getMethod("get" + attrPart1, new Class[] {});
            } catch (NoSuchMethodException ex) {
                method = clazz.getMethod(attrPart1, new Class[] {});
            }
            Object ret = method.invoke(object, new Object[] {});

            if (attrPart2 != null) {
                if (ret instanceof Collection) {
                    return extractAttribute((Collection) ret, attrPart2);
                } else {
                    return extractAttribute(ret, attrPart2);
                }
            } else {
                return ret;
            }
        } catch (Exception ex) {
            return null;
        }
    }

    /**
     * Indiziert alle Objekte in col nach einem Attribut aus jedem einzelnen
     * Objekt. Das zur Indizierung verwendete Attribut wird mit der Methode
     * extractAttribute(Object,String) ermittelt. <B>ACHTUNG: Es ist NICHT
     * sichergestellt, dass die Ergebnismenge die gleiche Sortierreihenfolge
     * besitzt wie col.</B>
     * 
     * @param col
     *            Menge von Objekten die indiziert werden soll.
     * 
     * @param keyAttribute
     *            Attribut aus den Objekten das als Index verwendet werden soll.
     * 
     * @return Alle Objekte aus col unique indiziert.
     * 
     * @throws NullPointerException
     *             wenn kein Attribut extrahiert werden konnte.
     */
    public static Map indexCollection(Collection col, String keyAttribute) {
        return ObjectUtils.indexCollection(col, keyAttribute, new Hashtable(col.size()));
    }

    /**
     * Indiziert alle Objekte in col nach einem Attribut aus jedem einzelnen
     * Objekt. Das zur Indizierung verwendete Attribut wird mit der Methode
     * extractAttribute(Object,String) ermittelt.
     * 
     * @param col
     *            Menge von Objekten die indiziert werden soll.
     * 
     * @param keyAttribute
     *            Attribut aus den Objekten das als Index verwendet werden soll.
     * 
     * @param destInstance
     *            Instanz der Map-Implementierung die die indizierte
     *            Ergebnismenge aufnehmen soll.
     * 
     * @return Alle Objekte aus col unique indiziert.
     * 
     * @throws NullPointerException
     *             wenn kein Attribut extrahiert werden konnte.
     */
    public static Map indexCollection(Collection col, String keyAttribute, Map destInstance) {
        if (destInstance == null) {
            throw new IllegalArgumentException("Die Ziel-Map destInstance darf nicht null sein!");
        }

        Iterator iter = col.iterator();
        while (iter.hasNext()) {
            try {
                Object item = iter.next();
                Object attribute = ObjectUtils.extractAttribute(item, keyAttribute);
                if (attribute != null) {
                    destInstance.put(attribute, item);
                }
            } catch (NullPointerException nullException) {
                // Null-Values die in die Hashtable eingetragen
                // werden sollen abfangen.
            }
        }

        return destInstance;
    }

    /**
     * Erzeugt die Vereinigungsmenge aus einem Array von Collections.
     * 
     * @param cols
     *            Alle Collections, deren Vereinigungsmenge gebildet werden
     *            soll.
     * 
     * @return Die Vereinigungsmenge oder eine leere Collection.
     */
    public static Collection intersect(Collection[] cols) {
        Collection ret = null;

        for (int i = 0; i < cols.length; i++) {
            if (cols[i] != null) {
                if (ret == null) {
                    ret = cols[i];
                } else {
                    ret.retainAll(cols[i]);
                }
            }
        }

        return ((ret == null) ? new ArrayList(0) : ret);
    }

    /**
     * Liefert alle Objekte aus map deren Key in keys vorkommt.
     * 
     * @param map
     *            Map aus der die Objekte gesucht werden sollen.
     * 
     * @param keys
     *            Keys, nach denen in Map gesucht werden soll.
     * 
     * @return Alle Objekte aus map deren Key in keys vorkommt.
     */
    public static Collection get(Map map, Collection keys) {
        return get(map, keys.toArray());
    }

    /**
     * Liefert alle Objekte aus map deren Key in keys vorkommt.
     * 
     * @param map
     *            Map aus der die Objekte gesucht werden sollen.
     * 
     * @param keys
     *            Keys, nach denen in Map gesucht werden soll.
     * 
     * @return Alle Objekte aus map deren Key in keys vorkommt.
     */
    public static Collection get(Map map, Object[] keys) {
        if (keys == null || map == null) {
            return new ArrayList(0);
        } else {
            ArrayList ret = new ArrayList(keys.length);
            for (int i = 0; i < keys.length; i++) {
                if (keys[i] != null) {
                    ret.add(map.get(keys[i]));
                }
            }
            return ret;
        }
    }

    /**
     * Filter aus der übergebenen Collection alle Objekte vom Typ clazz.
     * 
     * @param c
     *            Collection die gefiltert werden soll.
     * @param clazz
     *            Klasse nach der gefiltert werden soll.
     * @param include
     *            true = Alle Objekte vom Typ clazz werden zurückgegeben.
     * @return die gefilterte Ergebnismenge.
     */
    public static Collection filter(Collection c, Class clazz, boolean include) {
        if (c == null || clazz == null) {
            return new ArrayList(0);
        } else {
            Collection neu = new ArrayList(c.size());
            for (Iterator iter = c.iterator(); iter.hasNext();) {
                Object x = iter.next();
                if (x != null) {
                    if (!(x.getClass().isAssignableFrom(clazz) ^ include)) {
                        neu.add(x);
                    }
                }
            }

            return neu;
        }
    }
}

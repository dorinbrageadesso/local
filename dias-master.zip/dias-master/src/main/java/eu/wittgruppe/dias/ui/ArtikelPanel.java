package eu.wittgruppe.dias.ui;

import eu.wittgruppe.dias.bean.ErsatzartikelBean;
import eu.wittgruppe.dias.controller.ArtikelSearchController;
import eu.wittgruppe.dias.domain.VDiasArtikel;
import eu.wittgruppe.dias.util.Images;
import foxtrot.Job;
import foxtrot.Worker;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class ArtikelPanel extends JPanel {

	private static final long serialVersionUID = -4350961293056431992L;

	private JTextField ersatzartikelFarbeTextField = null;
	
	private JLabel ersatzartikelFarbeLabel = null;
	
	private JTextField ersatzartikelBezeichnungTextField = null;
	
	private JLabel ersatzartikelBezeichnungLabel = null;
	
	private JComboBox ersatzartikelComboBox = null;
	
	private JLabel ersatzartikelLabel = null;
	
	private ArtikelSearchController artikelSearchController = null;
	
	private VDiasArtikel artikel = null;
	
	private Boolean druckerVorhanden = null;

	private JPanel centerPanel = null;

	private JLabel bildLabel = null;

	private JLabel artnrLabel = null;

	private JTextField artnrTextField = null;

	private JLabel katartLabel = null;

	private JTextField katartTextField = null;

	private JLabel artgrLabel = null;

	private JComboBox artgrComboBox = null;

	private JLabel saisonLabel = null;

	private JTextField saisonTextField = null;

	private JLabel farbeLabel = null;

	private JTextField farbeTextField = null;
	
	private JLabel bezLabel = null;

	private JLabel openSeiteLabel = null;

	private JComboBox lieferantenComboBox = null;

	private JLabel printLabel = null;
	
	private ArrayList<ErsatzartikelBean> ersatzartikel = null;
	
	private JLabel retabLabel = null;

	public ArtikelPanel(ArtikelSearchController artikelSearchController,
			VDiasArtikel artikel, Boolean druckerVorhanden, ArrayList<ErsatzartikelBean> ersatzartikel) {
		super();
		this.artikelSearchController = artikelSearchController;
		this.artikel = artikel;
		this.druckerVorhanden = druckerVorhanden;
		this.ersatzartikel = ersatzartikel;
		initialize();
	}

	private void initialize() {
		this.setLayout(new BorderLayout());
		this.setSize(290, 200);
		this.setBackground(new java.awt.Color(204, 204, 255));
		this.setMinimumSize(new java.awt.Dimension(290, 225));
		this.setPreferredSize(new java.awt.Dimension(290, 225));
		this.setMaximumSize(new java.awt.Dimension(290, 225));
		this.add(getCenterPanel(), java.awt.BorderLayout.CENTER);

		// Artikelinformationen im Panel setzen
		getBezLabel().setText(artikel.getArtikelbezeichnung());
		getArtnrTextField().setText(artikel.getArtikelnummerWitt().toString());
		getKatartTextField().setText(artikel.getOriginalKatalogart());
		getSaisonTextField().setText(artikel.getSaison().toString());
		getFarbeTextField().setText(artikel.getFarbe());
		
		//Ersatzartikel in der ComboBox einfügen
		for (ErsatzartikelBean ersArtikel : ersatzartikel)
			getErsatzartikelComboBox().addItem(ersArtikel.getArtikelnummer());
	}

	/**
	 * This method initializes centerPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getCenterPanel() {
		if (centerPanel == null) {
			GridBagConstraints gridBagConstraints24 = new GridBagConstraints();
			gridBagConstraints24.gridx = 4;
			gridBagConstraints24.insets = new java.awt.Insets(0,0,0,5);
			gridBagConstraints24.gridy = 0;
			
			// ist ein Drucker angeschlossen
			if (druckerVorhanden.booleanValue()) {

				printLabel = new JLabel(Images.PRINT);
				printLabel.addMouseListener(new OnPrintLabelClicked());
				printLabel.addMouseListener(new MouseEnteredOnLabel());
				printLabel.addMouseListener(new MouseExitedOnLabel());	
			}
			else {
				printLabel = new JLabel(Images.PRINT_CO);
			}
						
			printLabel.setMinimumSize(new java.awt.Dimension(21,21));
			printLabel.setPreferredSize(new java.awt.Dimension(21,21));
			printLabel.setToolTipText("Lagerplatzetikett (LPE) drucken");
			printLabel.setMaximumSize(new java.awt.Dimension(21,21));
			
			retabLabel = new JLabel(Images.RUN_RETAB);
			retabLabel.addMouseListener(new MouseEnteredOnLabel());
			retabLabel.addMouseListener(new MouseExitedOnLabel());	
			retabLabel.addMouseListener(new MouseAdapter() {
							
				@Override
				public void mouseClicked(MouseEvent e) {
					
					artikelSearchController.runRetab(artnrTextField.getText(), artgrComboBox.getSelectedItem().toString());
				}
			});
			
			GridBagConstraints gridBagConstraints23 = new GridBagConstraints();
			gridBagConstraints23.fill = java.awt.GridBagConstraints.HORIZONTAL;
			gridBagConstraints23.gridy = 10;
			gridBagConstraints23.weightx = 1.0;
			gridBagConstraints23.gridwidth = 5;
			gridBagConstraints23.insets = new java.awt.Insets(0,2,2,2);
			gridBagConstraints23.gridx = 0;
			GridBagConstraints gridBagConstraints22 = new GridBagConstraints();
			gridBagConstraints22.gridx = 2;
			gridBagConstraints22.anchor = GridBagConstraints.WEST;
			gridBagConstraints22.insets = new java.awt.Insets(0,0,0,5);
			gridBagConstraints22.gridy = 0;		
			
			openSeiteLabel = new JLabel(Images.SELECT_SEITE);
			openSeiteLabel.setMinimumSize(new java.awt.Dimension(21,21));
			openSeiteLabel.setPreferredSize(new java.awt.Dimension(21,21));			
			openSeiteLabel.setMaximumSize(new java.awt.Dimension(21,21));
			openSeiteLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
			openSeiteLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
			
			openSeiteLabel.setBackground(new java.awt.Color(204,204,225));
			openSeiteLabel.setToolTipText("Katalogseite öffnen");		
			openSeiteLabel.addMouseListener(new OnKataloseiteLabelClicked());
			openSeiteLabel.addMouseListener(new MouseEnteredOnLabel());
			openSeiteLabel.addMouseListener(new MouseExitedOnLabel());
			GridBagConstraints gridBagConstraints15 = new GridBagConstraints();
			gridBagConstraints15.gridx = 0;
			gridBagConstraints15.gridy = 0;
			bezLabel = new JLabel();
			bezLabel.setText("");
			GridBagConstraints gridBagConstraints21 = new GridBagConstraints();
			gridBagConstraints21.fill = java.awt.GridBagConstraints.NONE;
			gridBagConstraints21.gridy = 2;
			gridBagConstraints21.weightx = 1.0;
			gridBagConstraints21.insets = new java.awt.Insets(2, 2, 0, 0);
			gridBagConstraints21.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints21.gridx = 2;
			GridBagConstraints gridBagConstraints11 = new GridBagConstraints();
			gridBagConstraints11.gridx = 0;
			gridBagConstraints11.gridwidth = 3;
			gridBagConstraints11.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints11.insets = new java.awt.Insets(2, 2, 2, 2);
			gridBagConstraints11.weightx = 1.0;
			gridBagConstraints11.ipadx = 0;
			gridBagConstraints11.fill = java.awt.GridBagConstraints.HORIZONTAL;
			gridBagConstraints11.gridy = 7;
			GridBagConstraints gridBagConstraints2 = new GridBagConstraints();
			gridBagConstraints2.gridx = 0;
			gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints2.insets = new java.awt.Insets(0, 2, 2, 2);
			gridBagConstraints2.gridwidth = 3;
			gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
			gridBagConstraints2.gridy = 0;
			bezLabel.setMinimumSize(new java.awt.Dimension(206, 20));
			bezLabel.setPreferredSize(new java.awt.Dimension(206, 20));
			bezLabel
					.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 13));
			bezLabel.setMaximumSize(new java.awt.Dimension(206, 20));
			GridBagConstraints gridBagConstraints61 = new GridBagConstraints();
			gridBagConstraints61.gridx = 0;
			gridBagConstraints61.gridheight = 7;
			gridBagConstraints61.fill = java.awt.GridBagConstraints.BOTH;
			gridBagConstraints61.insets = new java.awt.Insets(2,2,2,0);
			gridBagConstraints61.gridy = 1;
			bildLabel = new JLabel();
			bildLabel.setText("");
			bildLabel.setMinimumSize(new java.awt.Dimension(120, 140));
			bildLabel.setMaximumSize(new java.awt.Dimension(120, 140));
			bildLabel.setBorder(javax.swing.BorderFactory.createLineBorder(
					java.awt.Color.lightGray, 1));
			bildLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
			bildLabel
					.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
			bildLabel.setPreferredSize(new java.awt.Dimension(120, 140));
			GridBagConstraints gridBagConstraints10 = new GridBagConstraints();
			gridBagConstraints10.ipadx = -5;
			gridBagConstraints10.fill = java.awt.GridBagConstraints.HORIZONTAL;
			gridBagConstraints10.gridy = 5;
			gridBagConstraints10.weightx = 1.0;
			gridBagConstraints10.gridwidth = 3;
			gridBagConstraints10.insets = new java.awt.Insets(2, 2, 0, 2);
			gridBagConstraints10.gridx = 2;
			GridBagConstraints gridBagConstraints9 = new GridBagConstraints();
			gridBagConstraints9.gridx = 1;
			gridBagConstraints9.anchor = java.awt.GridBagConstraints.EAST;
			gridBagConstraints9.insets = new java.awt.Insets(2, 2, 0, 0);
			gridBagConstraints9.gridy = 5;
			farbeLabel = new JLabel();
			farbeLabel.setText("Farbe:");
			farbeLabel.setFont(new java.awt.Font("Dialog", java.awt.Font.PLAIN,
					12));
			GridBagConstraints gridBagConstraints8 = new GridBagConstraints();
			gridBagConstraints8.fill = java.awt.GridBagConstraints.NONE;
			gridBagConstraints8.gridy = 4;
			gridBagConstraints8.weightx = 1.0;
			gridBagConstraints8.gridheight = 1;
			gridBagConstraints8.gridwidth = 3;
			gridBagConstraints8.insets = new java.awt.Insets(2, 2, 0, 2);
			gridBagConstraints8.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints8.gridx = 2;
			GridBagConstraints gridBagConstraints7 = new GridBagConstraints();
			gridBagConstraints7.gridx = 1;
			gridBagConstraints7.anchor = java.awt.GridBagConstraints.EAST;
			gridBagConstraints7.insets = new java.awt.Insets(2, 2, 0, 0);
			gridBagConstraints7.gridy = 4;
			saisonLabel = new JLabel();
			saisonLabel.setText("Saison:");
			saisonLabel.setFont(new java.awt.Font("Dialog",
					java.awt.Font.PLAIN, 12));
			GridBagConstraints gridBagConstraints6 = new GridBagConstraints();
			gridBagConstraints6.fill = java.awt.GridBagConstraints.NONE;
			gridBagConstraints6.gridy = 3;
			gridBagConstraints6.weightx = 1.0;
			gridBagConstraints6.insets = new java.awt.Insets(2, 2, 0, 2);
			gridBagConstraints6.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints6.gridx = 2;
			GridBagConstraints gridBagConstraints5 = new GridBagConstraints();
			gridBagConstraints5.gridx = 1;
			gridBagConstraints5.anchor = java.awt.GridBagConstraints.EAST;
			gridBagConstraints5.insets = new java.awt.Insets(2, 2, 0, 2);
			gridBagConstraints5.gridy = 3;
			katartLabel = new JLabel();
			katartLabel.setText("Katart:");
			katartLabel.setFont(new java.awt.Font("Dialog",
					java.awt.Font.PLAIN, 12));
			GridBagConstraints gridBagConstraints4 = new GridBagConstraints();
			gridBagConstraints4.gridx = 1;
			gridBagConstraints4.anchor = java.awt.GridBagConstraints.EAST;
			gridBagConstraints4.insets = new java.awt.Insets(2, 2, 0, 2);
			gridBagConstraints4.gridy = 1;
			GridBagConstraints gridBagConstraints = new GridBagConstraints();
			gridBagConstraints.gridx = 1;
			gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
			gridBagConstraints.insets = new java.awt.Insets(2, 2, 0, 2);
			gridBagConstraints.gridy = 2;
			artgrLabel = new JLabel();
			artgrLabel.setText("ArtGr:");
			artgrLabel.setFont(new java.awt.Font("Dialog", java.awt.Font.PLAIN,
					12));
			GridBagConstraints gridBagConstraints3 = new GridBagConstraints();
			gridBagConstraints3.fill = java.awt.GridBagConstraints.HORIZONTAL;
			gridBagConstraints3.gridx = 2;
			gridBagConstraints3.gridy = 1;
			gridBagConstraints3.insets = new java.awt.Insets(2, 2, 0, 2);
			gridBagConstraints3.gridwidth = 3;
			gridBagConstraints3.weightx = 1.0;
			artnrLabel = new JLabel();
			artnrLabel.setText("ArtikelNr:");
			artnrLabel.setFont(new java.awt.Font("Dialog", java.awt.Font.PLAIN,
					12));
			centerPanel = new JPanel();
			final GridBagLayout gridBagLayout = new GridBagLayout();
			gridBagLayout.columnWidths = new int[] {0,0,0,0,0};
			gridBagLayout.rowHeights = new int[] {0,0,0,0,0,0,0,0,0,0,0};
			centerPanel.setLayout(gridBagLayout);
			centerPanel.setMaximumSize(new java.awt.Dimension(290, 220));
			centerPanel.setPreferredSize(new java.awt.Dimension(290, 220));
			centerPanel.setMinimumSize(new java.awt.Dimension(290, 220));
			centerPanel.setBackground(new java.awt.Color(204, 204, 225));
			centerPanel.setCursor(new java.awt.Cursor(
					java.awt.Cursor.DEFAULT_CURSOR));
			centerPanel.add(artnrLabel, gridBagConstraints4);
			centerPanel.add(getArtnrTextField(), gridBagConstraints3);
			centerPanel.add(artgrLabel, gridBagConstraints);
			centerPanel.add(katartLabel, gridBagConstraints5);
			centerPanel.add(getKatartTextField(), gridBagConstraints6);
			centerPanel.add(saisonLabel, gridBagConstraints7);
			centerPanel.add(getSaisonTextField(), gridBagConstraints8);
			centerPanel.add(farbeLabel, gridBagConstraints9);
			centerPanel.add(getFarbeTextField(), gridBagConstraints10);
			centerPanel.add(bildLabel, gridBagConstraints61);
			centerPanel.add(bezLabel, gridBagConstraints2);
			centerPanel.add(getArtgrComboBox(), gridBagConstraints21);
			centerPanel.add(openSeiteLabel, gridBagConstraints22);

			ersatzartikelLabel = new JLabel();
			ersatzartikelLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
			ersatzartikelLabel.setText("ErsArt:");
			final GridBagConstraints gridBagConstraints_1 = new GridBagConstraints();
			gridBagConstraints_1.insets = new Insets(2, 0, 0, 0);
			gridBagConstraints_1.anchor = GridBagConstraints.EAST;
			gridBagConstraints_1.gridy = 6;
			gridBagConstraints_1.gridx = 1;
			centerPanel.add(ersatzartikelLabel, gridBagConstraints_1);

			ersatzartikelComboBox = new JComboBox();
			ersatzartikelComboBox.addItemListener(new ItemListener() {
				public void itemStateChanged(final ItemEvent e) {
					
					for (ErsatzartikelBean ersArtikel : ersatzartikel)
						if (ersArtikel.getArtikelnummer().equals(getErsatzartikelComboBox().getSelectedItem())){
							
							getErsatzartikelBezeichnungTextField().setText(ersArtikel.getBezeichnung());
							getErsatzartikelFarbeTextField().setText(ersArtikel.getFarbe());
						}
							
				}
			});
			final GridBagConstraints gridBagConstraints_2 = new GridBagConstraints();
			gridBagConstraints_2.gridwidth = 3;
			gridBagConstraints_2.weightx = 1;
			gridBagConstraints_2.insets = new Insets(2, 2, 0, 2);
			gridBagConstraints_2.fill = GridBagConstraints.HORIZONTAL;
			gridBagConstraints_2.ipadx = -5;
			gridBagConstraints_2.gridy = 6;
			gridBagConstraints_2.gridx = 2;
			centerPanel.add(ersatzartikelComboBox, gridBagConstraints_2);

			ersatzartikelBezeichnungLabel = new JLabel();
			ersatzartikelBezeichnungLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
			ersatzartikelBezeichnungLabel.setText("ErsBez:");
			final GridBagConstraints gridBagConstraints_3 = new GridBagConstraints();
			gridBagConstraints_3.insets = new Insets(2, 0, 0, 0);
			gridBagConstraints_3.anchor = GridBagConstraints.EAST;
			gridBagConstraints_3.gridy = 7;
			gridBagConstraints_3.gridx = 1;
			centerPanel.add(ersatzartikelBezeichnungLabel, gridBagConstraints_3);

			ersatzartikelBezeichnungTextField = new JTextField();
			ersatzartikelBezeichnungTextField.setEditable(false);
			ersatzartikelBezeichnungTextField.setDisabledTextColor(java.awt.Color.black);
			ersatzartikelBezeichnungTextField.setBackground(new Color(231, 235, 235));
			final GridBagConstraints gridBagConstraints_4 = new GridBagConstraints();
			gridBagConstraints_4.insets = new Insets(2, 2, 0, 2);
			gridBagConstraints_4.ipadx = 115;
			gridBagConstraints_4.gridwidth = 3;
			gridBagConstraints_4.gridy = 7;
			gridBagConstraints_4.gridx = 2;
			centerPanel.add(ersatzartikelBezeichnungTextField, gridBagConstraints_4);

			ersatzartikelFarbeLabel = new JLabel();
			ersatzartikelFarbeLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
			ersatzartikelFarbeLabel.setText("ErsFarbe:");
			final GridBagConstraints gridBagConstraints_5 = new GridBagConstraints();
			gridBagConstraints_5.insets = new Insets(2, 2, 4, 0);
			gridBagConstraints_5.anchor = GridBagConstraints.EAST;
			gridBagConstraints_5.gridy = 8;
			gridBagConstraints_5.gridx = 1;
			centerPanel.add(ersatzartikelFarbeLabel, gridBagConstraints_5);

			ersatzartikelFarbeTextField = new JTextField();
			ersatzartikelFarbeTextField.setEditable(false);
			ersatzartikelFarbeTextField.setDisabledTextColor(java.awt.Color.black);
			ersatzartikelFarbeTextField.setBackground(new Color(231, 235, 235));
			final GridBagConstraints gridBagConstraints_6 = new GridBagConstraints();
			gridBagConstraints_6.ipadx = 115;
			gridBagConstraints_6.insets = new Insets(2, 2, 4, 2);
			gridBagConstraints_6.gridwidth = 3;
			gridBagConstraints_6.gridy = 8;
			gridBagConstraints_6.gridx = 2;
			centerPanel.add(ersatzartikelFarbeTextField, gridBagConstraints_6);
			centerPanel.add(getLieferantenComboBox(), gridBagConstraints23);
			final GridBagConstraints gridBagConstraints_7 = new GridBagConstraints();
			gridBagConstraints_7.gridy = 0;
			gridBagConstraints_7.gridx = 3;
			centerPanel.add(retabLabel, gridBagConstraints_7);
			centerPanel.add(printLabel, gridBagConstraints24);
		}
		return centerPanel;
	}

	public JTextField getArtnrTextField() {
		if (artnrTextField == null) {
			artnrTextField = new JTextField();
			artnrTextField.setEnabled(false);
			artnrTextField.setBackground(new java.awt.Color(231, 235, 235));
			artnrTextField.setDisabledTextColor(java.awt.Color.black);
		}
		return artnrTextField;
	}

	public JTextField getKatartTextField() {
		if (katartTextField == null) {
			katartTextField = new JTextField();
			katartTextField.setMinimumSize(new java.awt.Dimension(35, 20));
			katartTextField.setPreferredSize(new java.awt.Dimension(35, 20));
			katartTextField.setEnabled(false);
			katartTextField.setDisabledTextColor(java.awt.Color.black);
			katartTextField.setBackground(new java.awt.Color(231, 235, 235));
			katartTextField.setMaximumSize(new java.awt.Dimension(35, 20));
		}
		return katartTextField;
	}

	public JComboBox getArtgrComboBox() {
		if (artgrComboBox == null) {
			artgrComboBox = new JComboBox();
			artgrComboBox.setMinimumSize(new java.awt.Dimension(60, 20));
			artgrComboBox.setPreferredSize(new java.awt.Dimension(60, 20));
			artgrComboBox.setMaximumSize(new java.awt.Dimension(60, 20));
			artgrComboBox.addItemListener(new ItemListener(){

				
				public void itemStateChanged(ItemEvent e)  {
					
					SwingUtilities.invokeLater(new Runnable(){

						public void run() {
							
							//Wenn es mehr als eine Größe gibt, müssen die Ersatzartikel neu geladen werden...
							if (artgrComboBox.getItemCount() > 1){
								
								WaitView waitView = new WaitView(artikelSearchController.getParentController().getMainWindow());
								UIUtils.centerOverComponent(artikelSearchController.getParentController().getMainWindow(), waitView);

								waitView.setVisible(true);
								
								ersatzartikel = (ArrayList<ErsatzartikelBean>) Worker.post(new Job() {

									public Object run() {
										
										return artikelSearchController.getErsatzartikel(artikel.getArtikelnummerWitt().toString(), 
												artgrComboBox.getSelectedItem().toString(), artikel.getSaison().toString());
									}
								});
								
								//Vorhandene Werte löschen...
								ersatzartikelComboBox.removeAllItems();
								ersatzartikelBezeichnungTextField.setText("");
								ersatzartikelFarbeTextField.setText("");
								
								//Ersatzartikel in der ComboBox einfügen...
								for (ErsatzartikelBean ersArtikel : ersatzartikel)
									getErsatzartikelComboBox().addItem(ersArtikel.getArtikelnummer());
								
								waitView.setVisible(false);
							}
						}
					});
				}				
			});
		}
		return artgrComboBox;
	}

	public JTextField getSaisonTextField() {
		if (saisonTextField == null) {
			saisonTextField = new JTextField();
			saisonTextField.setMaximumSize(new java.awt.Dimension(35, 20));
			saisonTextField.setPreferredSize(new java.awt.Dimension(35, 20));
			saisonTextField.setEnabled(false);
			saisonTextField.setDisabledTextColor(java.awt.Color.black);
			saisonTextField.setBackground(new java.awt.Color(231, 235, 235));
			saisonTextField.setMinimumSize(new java.awt.Dimension(35, 20));
		}
		return saisonTextField;
	}

	public JTextField getFarbeTextField() {
		if (farbeTextField == null) {
			farbeTextField = new JTextField();
			farbeTextField.setEnabled(false);
			farbeTextField.setBackground(new java.awt.Color(231, 235, 235));
			farbeTextField.setDisabledTextColor(java.awt.Color.black);
		}
		return farbeTextField;
	}

	public JLabel getBildLabel() {
		return bildLabel;
	}

	public void setBildLabel(JLabel bildLabel) {
		this.bildLabel = bildLabel;
	}	

	public JLabel getBezLabel() {
		return bezLabel;
	}

	public void setBezLabel(JLabel bezLabel) {
		this.bezLabel = bezLabel;
	}

	public JComboBox getLieferantenComboBox() {
		if (lieferantenComboBox == null) {
			lieferantenComboBox = new JComboBox();
			lieferantenComboBox.setMinimumSize(new java.awt.Dimension(31,20));
			lieferantenComboBox.setMaximumSize(new java.awt.Dimension(31,20));
			lieferantenComboBox.setPreferredSize(new java.awt.Dimension(31,20));
		}
		return lieferantenComboBox;
	};
	   

	
	private class OnKataloseiteLabelClicked extends java.awt.event.MouseAdapter {
		
		public void mouseClicked(java.awt.event.MouseEvent e) {
			
			if (e.getClickCount() == 1) {				
				artikelSearchController.openKatalogSeite(artikel.getSaison(),
						 								 artikel.getModellvariantennummer(),
						 								 artikel.getArtikelnummerWitt());				
			}		
		}		
		
	};
	
	private class OnPrintLabelClicked extends java.awt.event.MouseAdapter {
		
		public void mouseClicked(java.awt.event.MouseEvent e) {
			
			if (e.getClickCount() == 1) {	
				// ausgewählte Größe setzen
				artikel.setModellvariantengroesse((String)ArtikelPanel
										.this.getArtgrComboBox().getSelectedItem());
				// und ab zum drucken
				artikelSearchController.print(artikel);				
			}		
		}		
		
	};
	
	private class MouseEnteredOnLabel extends java.awt.event.MouseAdapter {		
		
		public void mouseEntered(java.awt.event.MouseEvent e) {
			((JLabel)e.getSource()).setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.GRAY,1));
		}
	};
	
	private class MouseExitedOnLabel extends java.awt.event.MouseAdapter {
		
		public void mouseExited(java.awt.event.MouseEvent e) {    
			((JLabel)e.getSource()).setBorder(null);
		}
	}

		
	public JTextField getErsatzartikelFarbeTextField() {
		return ersatzartikelFarbeTextField;
	}

	public JTextField getErsatzartikelBezeichnungTextField() {
		return ersatzartikelBezeichnungTextField;
	}

	public JComboBox getErsatzartikelComboBox() {
		return ersatzartikelComboBox;
	}

}

package eu.wittgruppe.dias.util;


public class TreeNodeBean {
	
	private String nodeText = null;
	private Object value = null;
	
	public TreeNodeBean(String nodeText, Object value) {
		this.nodeText = nodeText;
		this.value = value;
	}	

	
	public String toString() {
		super.toString();
		return nodeText;		
	}

	public Object getValueObject() {
		return value;
	}

	public void getValueObject(Object value) {
		this.value = value;
	}


	public String getNodeText() {
		return nodeText;
	}

	public void setNodeText(String nodeText) {
		this.nodeText = nodeText;
	}
}

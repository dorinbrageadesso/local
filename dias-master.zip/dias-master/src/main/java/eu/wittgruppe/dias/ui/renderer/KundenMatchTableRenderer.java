package eu.wittgruppe.dias.ui.renderer;

import eu.wittgruppe.dias.bean.KundeSearchBean;

import javax.swing.*;
import java.awt.*;

public class KundenMatchTableRenderer extends DiasTableCellRenderer {

	public KundenMatchTableRenderer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Component getTableCellRendererComponent( 
	        JTable table, Object value, boolean isSelected, boolean hasFocus,
	        int row, int column ) {        
	        
	        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, 
	                                            row, column);
	        
	        KundeSearchBean kunde = (KundeSearchBean)value;
	        
	        switch (column) {
	        // kdnr
			case 0:				
				this.setText(kunde.getKdnr());				
				break;
            // Kdfirmbez
			case 1:
				this.setText(kunde.getKdfirmBez());				
				break;			       
	        // Vorname
			case 2:
				this.setText(kunde.getVorName());				
				break;				
//				Nachname
			case 3:					
				this.setText(kunde.getNachName());
				break;					
//				Strasse
			case 4:
				this.setText(kunde.getStrasse());
				break;
//				Hausnummer
			case 5:
				this.setText(kunde.getHausNr());
				break;				
//				Hausnummernzusatz
			case 6:
				this.setText(kunde.getHausNrZusatz());
				break;				
//				Plz
			case 7:
				this.setText(kunde.getPlz());
				break;
//				Ort
			case 8:
				this.setText(kunde.getOrt());				
				break;	
			} 
	        
	        return this;
	        
	}

}

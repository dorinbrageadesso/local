package eu.wittgruppe.dias.controller;

import eu.wittgruppe.dias.bean.LieferantBean;
import eu.wittgruppe.dias.ui.LieferantenChooser;
import org.apache.commons.lang.StringUtils;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class LieferantenChooserController {
	
	private LieferantenChooser chooser = null;
	private ArtikelSearchController parentController = null;
	
	public LieferantenChooserController(ArtikelSearchController parentController) {
		this.parentController = parentController;		
		initialize();
    }
	
	public void showDialog() {
		
		chooser.setVisible(true);
	}
	
	private void initialize() {
		chooser = new LieferantenChooser(parentController.getParentController().getMainWindow(), this);				
		chooser.setLieferanten(parentController.getParentController().getLieferanten());
	}
	
	public void filterLieferantenByZentralLiefnr(Collection lieferanten, String zentralLiefnr){
		
		Collection filteredLieferanten = new ArrayList();
		
		for (Iterator iter = lieferanten.iterator(); iter.hasNext();) {
			LieferantBean lieferant = (LieferantBean) iter.next();
			
			if (StringUtils.left(lieferant.getZlkz().toString(), zentralLiefnr.length()).equals(zentralLiefnr)) {
				filteredLieferanten.add(lieferant);
			}				
		}
		
		chooser.setLieferanten(filteredLieferanten);
	}
	
	public void filterLieferantenByBuchungskreis(Collection lieferanten, String buchungskreis){
	
		Collection filteredLieferanten = new ArrayList();
		
		for (Iterator iter = lieferanten.iterator(); iter.hasNext();) {
			LieferantBean lieferant = (LieferantBean) iter.next();
			
			if (StringUtils.left(lieferant.getBuchungskreis().toString(), buchungskreis.length()).equals(buchungskreis)) {
				filteredLieferanten.add(lieferant);
			}				
		}
		
		chooser.setLieferanten(filteredLieferanten);
	}
	
	public void filterLieferantenByLiefnr(Collection lieferanten, String liefnr) {
		
		Collection filteredLieferanten = new ArrayList();
		
		
		for (Iterator iter = lieferanten.iterator(); iter.hasNext();) {
			LieferantBean lieferant = (LieferantBean) iter.next();
			
			if (StringUtils.left(lieferant.getNummer().toString(), liefnr.length()).equals(liefnr)) {
				filteredLieferanten.add(lieferant);
			}				
		}
		
		chooser.setLieferanten(filteredLieferanten);
		
	}
	
	public void filterLieferantenByLiefName(Collection lieferanten, String liefName) {
		
		Collection filteredLieferanten = new ArrayList();
		
		
		for (Iterator iter = lieferanten.iterator(); iter.hasNext();) {
			LieferantBean lieferant = (LieferantBean) iter.next();
			
			if (StringUtils.contains(lieferant.getName().toUpperCase(), liefName.toUpperCase())) {
				filteredLieferanten.add(lieferant);
			}			
		}
		
		chooser.setLieferanten(filteredLieferanten);		
	}
	
	/**
	 * @return gibt den Selektierten Lieferanten zurück und schließt den Dialog
	 */
	public Long getSelectedLiefnr() {
		
		Long liefnr = null;
		
		if (chooser.getLieferantenTable().getSelectedRow() < 0 ) {
			
			JOptionPane.showMessageDialog(chooser, "Kein Lieferant ausgewählt. Bitte einen auswählen!",
					"Lieferantenauswahl", JOptionPane.WARNING_MESSAGE);			
		}
		else {
			
			LieferantBean cellValue = ( LieferantBean )chooser.getLieferantenTable()
					.getValueAt( chooser.getLieferantenTable().getSelectedRow(), 0 );
			
			liefnr = cellValue.getNummer();			
			chooser.dispose();			
		}		
		
		return liefnr; 
	}

	public ArtikelSearchController getParentController() {
		return parentController;
	}

	public void setParentController(ArtikelSearchController parentController) {
		this.parentController = parentController;
	}

	public LieferantenChooser getChooser() {
		return chooser;
	}

	public void setChooser(LieferantenChooser chooser) {
		this.chooser = chooser;
	}
	
}

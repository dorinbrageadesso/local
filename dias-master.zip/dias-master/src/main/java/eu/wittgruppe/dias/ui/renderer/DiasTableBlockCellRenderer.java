/*
 *                                 J O S E F
 *               Java Object Solutions Enterprise Framework
 *                  Copyright 2002 - 2004 Josef Witt GmbH
 */

package eu.wittgruppe.dias.ui.renderer;

import eu.wittgruppe.dias.bean.GroupableKunderechnungsposition;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;

public class DiasTableBlockCellRenderer extends DefaultTableCellRenderer {

	private Color background1 = Color.WHITE;

	private Color backgroundSelection = new Color(255, 255, 145);

	private Color background2 = new Color(200, 200, 200);

	private Color foreground1 = Color.BLACK;

	private Color foregroundSelection = Color.BLACK;

	private Color foreground2 = Color.BLACK;

	private Font font = null;


	public DiasTableBlockCellRenderer() {
	}

	public Component getTableCellRendererComponent(JTable table, Object value,
			boolean isSelected, boolean hasFocus, int row, int column) {
		super.getTableCellRendererComponent(table, value, isSelected, hasFocus,
				row, column);

		if (this.font == null) {
			font = new Font(this.getFont().getName(), Font.PLAIN, 13);
			this.setFont(font);
			table.setFont(font);
		}

		GroupableKunderechnungsposition rechPos = (GroupableKunderechnungsposition) value;

		this.setBackground( rechPos.getGroup() % 2 == 0 ? background1: background2);
		
		if (isSelected) {
			this.setBackground(backgroundSelection);
			this.setForeground(foregroundSelection);
		}
		
		return this;
	}

}

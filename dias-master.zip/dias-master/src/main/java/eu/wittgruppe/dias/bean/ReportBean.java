package eu.wittgruppe.dias.bean;

public class ReportBean {
	
	private String rechnungsdatum = null;
	private String retoureschluessel = null;
	private String positionsnummer = null;
	private String artikelnummerWitt = null;
	private String promotionnummer = null;
	private String artikelgroesse = null;
	private String artikelbezeichnung = null;
	private String farbe = null;
	private String bestellmenge = null;
	private String bestellbetrag = null;
	private String gutschriftmenge = null;
	private String gutschriftkennzeichen = null;
	private String lieferkennzeichen = null;
	private String zahlungskennzeichen = null;
	private String ratenkennzeichen = null;
	private String naliwoche = null;
	private int gruppe = 0;
	
	public ReportBean() {
		
	}
	
	public int getGruppe() {
		return gruppe;
	}
	public void setGruppe(int gruppe) {
		this.gruppe = gruppe;
	}
	public String getArtikelbezeichnung() {
		return artikelbezeichnung;
	}
	public void setArtikelbezeichnung(String artbez) {
		this.artikelbezeichnung = artbez;
	}
	public String getArtikelgroesse() {
		return artikelgroesse;
	}
	public void setArtikelgroesse(String artgr) {
		this.artikelgroesse = artgr;
	}
	public String getArtikelnummerWitt() {
		return artikelnummerWitt;
	}
	public void setArtikelnummerWitt(String artnr) {
		this.artikelnummerWitt = artnr;
	}
	public String getBestellbetrag() {
		return bestellbetrag;
	}
	public void setBestellbetrag(String bestBetrag) {
		this.bestellbetrag = bestBetrag;
	}
	public String getBestellmenge() {
		return bestellmenge;
	}
	public void setBestellmenge(String bestmg) {
		this.bestellmenge = bestmg;
	}
	public String getFarbe() {
		return farbe;
	}
	public void setFarbe(String farbe) {
		this.farbe = farbe;
	}
	public String getGutschriftkennzeichen() {
		return gutschriftkennzeichen;
	}
	public void setGutschriftkennzeichen(String gutschrKz) {
		this.gutschriftkennzeichen = gutschrKz;
	}
	public String getGutschriftmenge() {
		return gutschriftmenge;
	}
	public void setGutschriftmenge(String gutschrMg) {
		this.gutschriftmenge = gutschrMg;
	}
	public String getLieferkennzeichen() {
		return lieferkennzeichen;
	}
	public void setLieferkennzeichen(String likz) {
		this.lieferkennzeichen = likz;
	}
	public String getNaliwoche() {
		return naliwoche;
	}
	public void setNaliwoche(String naliWo) {
		this.naliwoche = naliWo;
	}
	public String getPositionsnummer() {
		return positionsnummer;
	}
	public void setPositionsnummer(String posnr) {
		this.positionsnummer = posnr;
	}
	public String getPromotionnummer() {
		return promotionnummer;
	}
	public void setPromotionnummer(String promnr) {
		this.promotionnummer = promnr;
	}
	public String getRatenkennzeichen() {
		return ratenkennzeichen;
	}
	public void setRatenkennzeichen(String raten) {
		this.ratenkennzeichen = raten;
	}
	public String getRechnungsdatum() {
		return rechnungsdatum;
	}
	public void setRechnungsdatum(String rechDat) {
		this.rechnungsdatum = rechDat;
	}
	public String getRetoureschluessel() {
		return retoureschluessel;
	}
	public void setRetoureschluessel(String retschl) {
		this.retoureschluessel = retschl;
	}
	public String getZahlungskennzeichen() {
		return zahlungskennzeichen;
	}
	public void setZahlungskennzeichen(String zahlArt) {
		this.zahlungskennzeichen = zahlArt;
	}
	

}

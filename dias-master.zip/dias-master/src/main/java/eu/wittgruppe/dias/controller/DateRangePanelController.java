/*
 * Created on 12.12.2005
 */
package eu.wittgruppe.dias.controller;

import eu.wittgruppe.dias.bean.StatistikBean;
import eu.wittgruppe.dias.service.DiasService;
import eu.wittgruppe.dias.ui.DateRangePanel;
import eu.wittgruppe.dias.ui.MainWindow;
import eu.wittgruppe.dias.ui.SimpleErrorDialog;
import eu.wittgruppe.dias.ui.WaitView;
import eu.wittgruppe.dias.util.Images;
import foxtrot.Job;
import foxtrot.Worker;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.swing.JRViewer;
import witt.josef.benutzerverwaltung.Account;
import witt.josef.benutzerverwaltung.Benutzerverwaltung;
import witt.josef.infrastructure.ApplicationContext;
import witt.josef.infrastructure.ApplicationDescriptor;
import witt.josef.uiswing.ui.ComboBoxBean;
import witt.josef.uiswing.ui.DateChooser;
import witt.josef.uiswing.ui.UIUtils;

import javax.swing.*;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Controller f&uuml;r den Dialog zur Auswahl des Zeitraums f&uuml;r den Bericht
 * 
 * @author Ulrkle
 */
@Slf4j
public class DateRangePanelController {

    private Benutzerverwaltung benutzerverwaltung = null;
    
    private static final String DATE_MASK = "dd.MM.yyyy";

    private DateRangePanel panel = null;
    private MainWindow mainWindow = null;
    private MainWindowController parentController = null;

    private JInternalFrame dateRangeFrame = null;

    public DateRangePanelController( MainWindowController parentController, Benutzerverwaltung benutzerverwaltung ) {
        panel = new DateRangePanel( this );
        this.benutzerverwaltung = benutzerverwaltung;
        this.parentController = parentController;
        this.mainWindow = parentController.getMainWindow();
        parentController.getMainWindow().setStatusTextLeft( "" );
        fillUserComboBox( panel.getUserComboBox() );
    }

    public DiasService getDiasService() {
        return parentController.getDiasService();
    }

    public MainWindowController getParentController() {
        return parentController;
    }

    // public void showDialog() {
    // internalFrame = mainWindow.addMDIWindow( panel, "Erfassungsmengenstatistik", false, true, false, false );
    // }

    public void auswerten() {
        // erst mal checken ob die eingegeben Dati gültig sind
        String start = panel.getStartDatumTextField().getText();
        String ende = panel.getEndeDatumTextField().getText();

        SimpleDateFormat formatter = new SimpleDateFormat( DATE_MASK );
        formatter.setLenient( false );
        Date startDate = null;
        try {
            startDate = formatter.parse( start );
        } catch( Exception e ) {
            mainWindow.showErrorMessage( "Von Datum ist ungültig", "Eingabefehler" );
            SwingUtilities.invokeLater( new Runnable() {
                @Override
                public void run() {
                    panel.getStartDatumTextField().selectAll();
                    panel.getStartDatumTextField().requestFocus();
                }
            } );
            return;
        }

        // wenn nur ein Vondatum eingegeben wurde wird das Endedatum nicht geprüft
        // da sich dann die Auswertung nur auf den einen Tag des VonDatums
        // erstreckt
        Date endDate = null;
        if( !ende.trim().equals( "" ) ) {
            try {
                endDate = formatter.parse( ende );
            } catch( Exception e ) {
                mainWindow.showErrorMessage( "Bis Datum ist ungültig", "Eingabefehler" );
                SwingUtilities.invokeLater( new Runnable() {
                    @Override
                    public void run() {
                        panel.getEndeDatumTextField().selectAll();
                        panel.getEndeDatumTextField().requestFocus();
                    }
                } );
                return;
            }

            // jetzt noch checken, daß von Datum vor dem bis Datum liegt
            if( startDate.after( endDate ) ) {
                mainWindow.showErrorMessage( "Von Datum liegt nach dem Bis Datum!", "Fehler" );
                SwingUtilities.invokeLater( new Runnable() {
                    @Override
                    public void run() {
                        panel.getStartDatumTextField().selectAll();
                        panel.getStartDatumTextField().requestFocus();
                    }
                } );
                return;
            }
        } else {
            // wenn nur ein Startdatum eingegeben worden ist bezieht sich die Auswertung
            // nur auf den einen Tag
            endDate = ( Date )startDate.clone();
            ende = formatter.format( endDate );
        }

        if( !isInMonthRange( startDate, endDate ) ) {
            mainWindow.showErrorMessage( "Zeitraum größer als 3 Monate!", "Fehler" );
            return;
        }
        // wenn Account selektiert ist diesen holen
        Account account = null;
        if( panel.getOneUserRadioButton().isSelected() ) {
            account = ( Account )( (ComboBoxBean)panel.getUserComboBox().getSelectedItem() ).getValue();
            showReport( startDate, endDate, account );
        } else {
            showReport( startDate, endDate );
        }

    }

    private boolean isInMonthRange( Date startDate, Date endDate ) {

        boolean ret = false;

        Date beginHelpDate = ( Date )startDate.clone();
        Calendar beginHelpCal = new GregorianCalendar();
        beginHelpCal.setTime( beginHelpDate );
        beginHelpCal.add( Calendar.MONTH, 3 );
        // 1 Tag noch dazuzählen wegen größer und nicht größer gleich
        beginHelpCal.add( Calendar.DAY_OF_MONTH, 1 );

        Calendar endHelpCal = new GregorianCalendar();
        endHelpCal.setTime( endDate );

        if( beginHelpCal.after( endHelpCal ) ) {
            ret = true;
        }

        return ret;
    }

    // Bericht über die einzelnen Statistikgruppen auf Mitarbeitebasis ausgeben
    private void showReport( Date startDate, Date endDate ) {
        try {

            Calendar startCal = new GregorianCalendar();
            startCal.setTime( startDate );

            Calendar endCal = new GregorianCalendar();
            endCal.setTime( endDate );

            Collection<StatistikBean> col = getDiasService().sucheDiasStatistikDaten( startCal, endCal );

            if( col.size() > 0 ) {
                JRDataSource datasourcce = new JRBeanCollectionDataSource( col );
                Map<String, String> reportData = new HashMap<String, String>();
                SimpleDateFormat formatter = new SimpleDateFormat( "dd.MM.yyyy" );

                reportData.put( "datumVom", formatter.format( startDate ) );
                reportData.put( "datumBis", formatter.format( endDate ) );

                showReportFrame( datasourcce, "/reports/dias_report_all_user.jasper", reportData, "Leistungsziehung" );

            } else {
                JOptionPane.showMessageDialog( this.getInternalFrame(), "Keine Daten zu den eingegebenen Suchkriterien gefunden!" );
            }
        } catch( Exception e ) {
            log.error( "", e );
            new SimpleErrorDialog( mainWindow, "Fehler", true, "Kann Statistik nicht ermitteln", e ).setVisible( true );
        }

    }

    // Bericht über die einzelnen Statistikgruppen auf Mitarbeitebasis ausgeben
    private void showReport( Date startDate, Date endDate, Account account ) {
        try {

            Calendar startCal = new GregorianCalendar();
            startCal.setTime( startDate );

            Calendar endCal = new GregorianCalendar();
            endCal.setTime( endDate );

            Collection<StatistikBean> col = getDiasService().sucheDiasStatistikDaten( startCal, endCal, account );

            if( col.size() > 0 ) {
                JRDataSource datasourcce = new JRBeanCollectionDataSource( col );
                Map<String, String> reportData = new HashMap<String, String>();
                SimpleDateFormat formatter = new SimpleDateFormat( "dd.MM.yyyy" );

                reportData.put( "datumVom", formatter.format( startDate ) );
                reportData.put( "datumBis", formatter.format( endDate ) );
                reportData.put( "name", account.getLastName() + " " + account.getFirstName() );
                reportData.put( "gesamtAnzahl", Integer.toString(col.size()) );

                showReportFrame( datasourcce, "/reports/dias_report_one_user.jasper", reportData, "Leistungsziehung" );

            } else {
                JOptionPane.showMessageDialog( this.getInternalFrame(), "Keine Daten zu den eingegebenen Suchkriterien gefunden!" );
            }
        } catch( Exception e ) {
            log.error( "", e );
            new SimpleErrorDialog( mainWindow, "Fehler", true, "Kann Statistik nicht ermitteln", e ).setVisible( true );
        }

    }

    private void showReportFrame( JRDataSource datasource, String reportFileName, Map reportData, String frameTitle ) throws Exception {
        JasperPrint printer = null;
        InputStream in = DateRangePanelController.class.getResourceAsStream( reportFileName );
        printer = JasperFillManager.fillReport( in, reportData, datasource );

        JRViewer viewer = new JRViewer( printer );
        JInternalFrame report = mainWindow.addMDIWindow( viewer, frameTitle );
        try {
            report.setMaximum( true );
        } catch( Exception e ) {
            log.error( "Fehler beim Maximieren des ReportFrame", e );
        }

    }

    public void cancel() {
        // dialog.dispose();
        dateRangeFrame.dispose();
    }

    public void chooseStartDate() {
        Date d = chooseDate( "Von Datum wählen" );
        String datum = formatDate( d );

        if( datum != null ) {
            panel.getStartDatumTextField().setText( datum );
            panel.getEndeDatumTextField().requestFocus();
        } else {
            panel.getStartDatumTextField().requestFocus();
        }
    }

    public void chooseEndDate() {
        Date d = chooseDate( "Ende Datum wählen" );
        String datum = formatDate( d );

        if( datum != null ) {
            panel.getEndeDatumTextField().setText( datum );
            panel.getAuswertungButton().requestFocus();
        } else {
            panel.getEndeDatumTextField().requestFocus();
        }
    }

    private String formatDate( Date d ) {
        if( d == null ) {
            return null;
        }
        SimpleDateFormat formatter = new SimpleDateFormat( DATE_MASK );
        String datum = formatter.format( d );
        return datum;
    }

    public Date chooseDate( String title ) {
        DateChooser chooser = new DateChooser( mainWindow );
        UIUtils.centerOverComponent( dateRangeFrame, chooser );
        chooser.setTitle( title );
        return chooser.select();
    }

    public MainWindow getMainWindow() {
        return mainWindow;
    }

    public void setMainWindow( MainWindow mainWindow ) {
        this.mainWindow = mainWindow;
    }

    public DateRangePanel getPanel() {
        return panel;
    }

    public void setPanel( DateRangePanel panel ) {
        this.panel = panel;
    }

    public JInternalFrame getInternalFrame() {
        return dateRangeFrame;
    }

    public void showDialog() {

        dateRangeFrame = parentController.getMainWindow().addMDIWindow( getPanel(), "Leistungsziehung ", true, true, true, true, null, 0, 0 );
        dateRangeFrame.setFrameIcon( Images.STATISTIK );
        SwingUtilities.invokeLater( new Runnable() {
            @Override
            public void run() {
                SimpleDateFormat formatter = new SimpleDateFormat( DATE_MASK );
                getPanel().getStartDatumTextField().setText( formatter.format( new Date() ) );
                dateRangeFrame.setSize(390, 220);
                dateRangeFrame.toFront();
            }
        } );
    }

    public void fillUserComboBox( JComboBox userComboBox ) {

        WaitView waitView = new WaitView( parentController.getMainWindow() );
        UIUtils.centerOverComponent( parentController.getMainWindow(), waitView );

        waitView.setVisible( true );

        @SuppressWarnings("unchecked")
        final Collection<Account> erfasserCol = ( Collection<Account> )Worker.post( new Job() {

            @Override
            public Object run() {

                ApplicationContext ctx = getParentController().getDefaultApplication().getApplicationContext();
                ApplicationDescriptor ad = ctx.getApplicationDescriptor();
                String rollenName = "user-leistungsziehung";
                return benutzerverwaltung.getAssignedAccounts( ad.getProduktName(), ad.getKomponenteName(), ad.getVersionMajor(), ad.getVersionMinor(), rollenName );
            }
        } );

        if( erfasserCol != null ) {
            for( Iterator<Account> iter = erfasserCol.iterator(); iter.hasNext(); ) {
                Account account = iter.next();
                ComboBoxBean cbxBean = new ComboBoxBean( account.getLastName() + ", " + account.getFirstName(), account );
                panel.getUserComboBox().addItem( cbxBean );
            }
        } else {
            JOptionPane.showMessageDialog( this.getInternalFrame(), "Keine Erfasser für NDS_Group user-leistung gefunden" );
        }
        waitView.setVisible( false );
    }
}
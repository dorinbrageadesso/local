package eu.wittgruppe.dias.domain;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity(name = "Benutzer")
@Table(name = "BENUTZER")
public class Benutzer implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID")
    @org.hibernate.annotations.GenericGenerator(name = "getId", strategy = "witt.josef.orm.hibernate.IdGenerator")
	@GeneratedValue(generator = "getId")
	private String id = null;

	/*
	 * Accountname des Benutzers entspricht dem SAMAccountName im ActiveDirectory
	 */
	@Column(name = "ACCOUNTNAME")
	private String accountName = null;
	
	/*
     * Abteilung
     */
    @Column(name = "ABT")
    private String abteilung = null;

	/*
	 * Kennzeichen ob Datensatz aktiv ist
	 */
	@Column(name = "AKTIVKZ")
	private String aktivKennzeichen = null;

	/*
	 * Anrede
	 */
	@Column(name = "ANR")
	private String anrede = null;

	/*
	 * Anredekennzeichen
	 */
	@Column(name = "ANRKZ")
	private String anredeKennzeichen = null;

	/*
	 * Bedienernummer
	 */
	@Column(name = "BEDNR")
	private String bedienernummer = null;

	/*
	 * Bereich
	 */
	@Column(name = "BER")
	private String bereich = null;

	/*
     * Distinguished Name aus dem ActiveDirectory
     */
    @Column(name = "DN")
    private String distinguishedName = null;
	
	/*
	 * EMailadresse
	 */
	@Column(name = "EMAIL")
	private String emailAdresse = null;

	/*
	 * Faxnummer
	 */
	@Column(name = "FAXNR")
	private String faxnummer = null;

	/*
	 * Nachname
	 */
	@Column(name = "NNAME")
	private String nachname = null;

	/*
	 * Ort
	 */
	@Column(name = "ORT")
	private String ort = null;

	/*
	 * Organisationseinheit
	 */
	@Column(name = "OU")
	private String organisationseinheit = null;

	/*
	 * Postleitzahl
	 */
	@Column(name = "PLZ")
	private String postleitzahl = null;

	/*
	 * SBVNummernbereich
	 */
	@Column(name = "SBVNRBER")
	private String sbvnNummernBereich = null;

	/*
	 * Strasse
	 */
	@Column(name = "STR")
	private String strasse = null;

	/*
	 * Telefonnummer
	 */
	@Column(name = "TELNR")
	private String telefonnummer = null;

	/*
	 * Verkaeufernummer
	 */
	@Column(name = "VERKNR")
	private Long verkaeufernummer = null;

	/*
	 * Vorname
	 */
	@Column(name = "VNAME")
	private String vorname = null;

	public Benutzer() {
	}

	public String getAbteilung() {
		return abteilung;
	}

	public void setAbteilung(String abteilung) {
		this.abteilung = abteilung;
	}

	public String getAktivKennzeichen() {
		return aktivKennzeichen;
	}

	public void setAktivKennzeichen(String aktivKennzeichen) {
		this.aktivKennzeichen = aktivKennzeichen;
	}

	public String getAnrede() {
		return anrede;
	}

	public void setAnrede(String anrede) {
		this.anrede = anrede;
	}

	public String getAnredeKennzeichen() {
		return anredeKennzeichen;
	}

	public void setAnredeKennzeichen(String anredeKennzeichen) {
		this.anredeKennzeichen = anredeKennzeichen;
	}

	public String getBedienernummer() {
		return bedienernummer;
	}

	public void setBedienernummer(String bedienernummer) {
		this.bedienernummer = bedienernummer;
	}

	public String getBereich() {
		return bereich;
	}

	public void setBereich(String bereich) {
		this.bereich = bereich;
	}

	public String getEmailAdresse() {
		return emailAdresse;
	}

	public void setEmailAdresse(String emailAdresse) {
		this.emailAdresse = emailAdresse;
	}

	public String getFaxnummer() {
		return faxnummer;
	}

	public void setFaxnummer(String faxnummer) {
		this.faxnummer = faxnummer;
	}

	public String getId() {
		return id;
	}

	public String getNachname() {
		return nachname;
	}

	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getOrganisationseinheit() {
		return organisationseinheit;
	}

	public void setOrganisationseinheit(String organisationseinheit) {
		this.organisationseinheit = organisationseinheit;
	}

	public String getPostleitzahl() {
		return postleitzahl;
	}

	public void setPostleitzahl(String postleitzahl) {
		this.postleitzahl = postleitzahl;
	}

	public String getSbvnNummernBereich() {
		return sbvnNummernBereich;
	}

	public void setSbvnNummernBereich(String sbvnNummernBereich) {
		this.sbvnNummernBereich = sbvnNummernBereich;
	}

	public String getStrasse() {
		return strasse;
	}

	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}

	public String getTelefonnummer() {
		return telefonnummer;
	}

	public void setTelefonnummer(String telefonnummer) {
		this.telefonnummer = telefonnummer;
	}

	public Long getVerkaeufernummer() {
		return verkaeufernummer;
	}

	public void setVerkaeufernummer(Long verkaeufernummer) {
		this.verkaeufernummer = verkaeufernummer;
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}


	public String getVorUndNachame() {
		return this.getVorname() + " " + this.getNachname();
	}

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName( String accountName ) {
        this.accountName = accountName;
    }

    public String getDistinguishedName() {
        return distinguishedName;
    }

    public void setDistinguishedName( String distinguishedName ) {
        this.distinguishedName = distinguishedName;
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((abteilung == null) ? 0 : abteilung.hashCode());
		result = prime * result + ((accountName == null) ? 0 : accountName.hashCode());
		result = prime * result + ((aktivKennzeichen == null) ? 0 : aktivKennzeichen.hashCode());
		result = prime * result + ((anrede == null) ? 0 : anrede.hashCode());
		result = prime * result + ((anredeKennzeichen == null) ? 0 : anredeKennzeichen.hashCode());
		result = prime * result + ((bedienernummer == null) ? 0 : bedienernummer.hashCode());
		result = prime * result + ((bereich == null) ? 0 : bereich.hashCode());
		result = prime * result + ((distinguishedName == null) ? 0 : distinguishedName.hashCode());
		result = prime * result + ((emailAdresse == null) ? 0 : emailAdresse.hashCode());
		result = prime * result + ((faxnummer == null) ? 0 : faxnummer.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((nachname == null) ? 0 : nachname.hashCode());
		result = prime * result + ((organisationseinheit == null) ? 0 : organisationseinheit.hashCode());
		result = prime * result + ((ort == null) ? 0 : ort.hashCode());
		result = prime * result + ((postleitzahl == null) ? 0 : postleitzahl.hashCode());
		result = prime * result + ((strasse == null) ? 0 : strasse.hashCode());
		result = prime * result + ((telefonnummer == null) ? 0 : telefonnummer.hashCode());
		result = prime * result + ((verkaeufernummer == null) ? 0 : verkaeufernummer.hashCode());
		result = prime * result + ((vorname == null) ? 0 : vorname.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Benutzer other = (Benutzer) obj;
		if (abteilung == null) {
			if (other.abteilung != null)
				return false;
		} else if (!abteilung.equals(other.abteilung))
			return false;
		if (accountName == null) {
			if (other.accountName != null)
				return false;
		} else if (!accountName.equals(other.accountName))
			return false;
		if (aktivKennzeichen == null) {
			if (other.aktivKennzeichen != null)
				return false;
		} else if (!aktivKennzeichen.equals(other.aktivKennzeichen))
			return false;
		if (anrede == null) {
			if (other.anrede != null)
				return false;
		} else if (!anrede.equals(other.anrede))
			return false;
		if (anredeKennzeichen == null) {
			if (other.anredeKennzeichen != null)
				return false;
		} else if (!anredeKennzeichen.equals(other.anredeKennzeichen))
			return false;
		if (bedienernummer == null) {
			if (other.bedienernummer != null)
				return false;
		} else if (!bedienernummer.equals(other.bedienernummer))
			return false;
		if (bereich == null) {
			if (other.bereich != null)
				return false;
		} else if (!bereich.equals(other.bereich))
			return false;
		if (distinguishedName == null) {
			if (other.distinguishedName != null)
				return false;
		} else if (!distinguishedName.equals(other.distinguishedName))
			return false;
		if (emailAdresse == null) {
			if (other.emailAdresse != null)
				return false;
		} else if (!emailAdresse.equals(other.emailAdresse))
			return false;
		if (faxnummer == null) {
			if (other.faxnummer != null)
				return false;
		} else if (!faxnummer.equals(other.faxnummer))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (nachname == null) {
			if (other.nachname != null)
				return false;
		} else if (!nachname.equals(other.nachname))
			return false;
		if (organisationseinheit == null) {
			if (other.organisationseinheit != null)
				return false;
		} else if (!organisationseinheit.equals(other.organisationseinheit))
			return false;
		if (ort == null) {
			if (other.ort != null)
				return false;
		} else if (!ort.equals(other.ort))
			return false;
		if (postleitzahl == null) {
			if (other.postleitzahl != null)
				return false;
		} else if (!postleitzahl.equals(other.postleitzahl))
			return false;
		if (strasse == null) {
			if (other.strasse != null)
				return false;
		} else if (!strasse.equals(other.strasse))
			return false;
		if (telefonnummer == null) {
			if (other.telefonnummer != null)
				return false;
		} else if (!telefonnummer.equals(other.telefonnummer))
			return false;
		if (verkaeufernummer == null) {
			if (other.verkaeufernummer != null)
				return false;
		} else if (!verkaeufernummer.equals(other.verkaeufernummer))
			return false;
		if (vorname == null) {
			if (other.vorname != null)
				return false;
		} else if (!vorname.equals(other.vorname))
			return false;
		return true;
	}

    
}

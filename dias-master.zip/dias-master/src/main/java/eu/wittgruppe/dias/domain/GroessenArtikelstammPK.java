package eu.wittgruppe.dias.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class GroessenArtikelstammPK implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "ARTNR6")
	private Long artikelnummer6 = null;

	/*
	 * Groesse des Artikels
	 */
	@Column(name = "ARTGR")
	private String artikelGroesse = null;

	public GroessenArtikelstammPK() {
	}

	public String getArtikelGroesse() {
		return artikelGroesse;
	}

	public void setArtikelGroesse(String artikelGroesse) {
		this.artikelGroesse = artikelGroesse;
	}

	public GroessenArtikelstammPK(String artikelGroesse, Long artikelnummer6) {
		this.artikelGroesse = artikelGroesse;
		this.artikelnummer6 = artikelnummer6;
	}

	public Long getArtikelnummer6() {
		return artikelnummer6;
	}

	public void setArtikelnummer6(Long artikelnummer6) {
		this.artikelnummer6 = artikelnummer6;
	}

}

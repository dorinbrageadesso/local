/**
 * 
 */
package eu.wittgruppe.dias.bean;


import eu.wittgruppe.dias.domain.Kundenfirma;
import eu.wittgruppe.dias.domain.Vertriebsgebiet;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Collection;

/**
 * @author wolste
 *
 */
public class KundenrechnungskopfBean implements Serializable {
 
static final long serialVersionUID = -1L;

	private String AltNeukundekennzeichen;
	private Long Artikelanzahl;
	private Long Bedienernummer;
	private Long Benutzernummer;
	private String CPDKennzeichen;
	private Double Eilsendungbetrag;
	private String Fakturierprioritaet;
	private Double Gewicht;
	private Long GOLDTransferkennzeichen;
	private Double Gutschriftverrechnungsbetrag;
	private Long Hermeskennzeichen;
	private String Id;
	private String Idcode;
	private Kundenfirma Kundenfirma;
	private Long Kundennummer;
	private Long KundennummerCrossselling;
	private Collection KundenrechnungspositionCollection;
	private Calendar LetztesAenderungsdatum;
	private String Lieferanschriftkennzeichen;
	private String LieferanschriftName;
	private String LieferanschriftOrt;
	private String LieferanschriftPostleitzahl;
	private String LieferanschriftStrasse;
	private Calendar LVDatum;
	private String LVZeitkennzeichen;
	private Double Nebenkostenbetrag;
	private String OriginalAuftragsnummer;
	private String OriginalKundennummer;
	private Long Paketanzahl;
	private Long Paketkennzeichen;
	private Long Paketshopbelieferungskennzeichen;
	private Long Postzielcode;
	private Double Rabattbetrag;
	private Double Ratenaufschlagbetrag;
	private Double RatenaufschlagInProzent;
	private Long Rechnungsart;
	private Long RechnungsartikelFakturiert;
	private Double Rechnungsbetrag;
	private Calendar Rechnungsdatum;
	private Long Rechnungsnummer;
	private Long Retoureschluessel;
	private Long RetoureschluesselCrossselling;
	private Long Richtungsymbol;
	private String Sendungskomplettierungskennzeichen;
	private String Sendungsschluessel;
	private Long Sendungstermin;
	private Long Unterkontonummer;
	private Double Valutaaufschlagbetrag;
	private Double ValutaaufschlagInProzent;
	private eu.wittgruppe.dias.domain.Vertriebsgebiet Vertriebsgebiet;
	private Double ZahlscheingebuehrNachnahme;
	private String Zahlungskennzeichen;

public KundenrechnungskopfBean() {
}


public String getAltNeukundekennzeichen() {
	return this.AltNeukundekennzeichen;
}

public Long getArtikelanzahl() {
	return this.Artikelanzahl;
}

public Long getBedienernummer() {
	return this.Bedienernummer;
}

public Long getBenutzernummer() {
	return this.Benutzernummer;
}

public String getCPDKennzeichen() {
	return this.CPDKennzeichen;
}

public Double getEilsendungbetrag() {
	return this.Eilsendungbetrag;
}

public String getFakturierprioritaet() {
	return this.Fakturierprioritaet;
}

public Long getGOLDTransferkennzeichen() {
	return this.GOLDTransferkennzeichen;
}

public Double getGewicht() {
	return this.Gewicht;
}

public Double getGutschriftverrechnungsbetrag() {
	return this.Gutschriftverrechnungsbetrag;
}

public Long getHermeskennzeichen() {
	return this.Hermeskennzeichen;
}

public String getId() {
	return this.Id;
}

public String getIdcode() {
	return this.Idcode;
}

public Kundenfirma getKundenfirma() {
	return this.Kundenfirma;
}

public Long getKundennummer() {
	return this.Kundennummer;
}

public Long getKundennummerCrossselling() {
	return this.KundennummerCrossselling;
}

public Collection getKundenrechnungspositionCollection() {
	return this.KundenrechnungspositionCollection;
}

public Calendar getLVDatum() {
	return this.LVDatum;
}

public String getLVZeitkennzeichen() {
	return this.LVZeitkennzeichen;
}

public Calendar getLetztesAenderungsdatum() {
	return this.LetztesAenderungsdatum;
}

public String getLieferanschriftName() {
	return this.LieferanschriftName;
}

public String getLieferanschriftOrt() {
	return this.LieferanschriftOrt;
}

public String getLieferanschriftPostleitzahl() {
	return this.LieferanschriftPostleitzahl;
}

public String getLieferanschriftStrasse() {
	return this.LieferanschriftStrasse;
}

public String getLieferanschriftkennzeichen() {
	return this.Lieferanschriftkennzeichen;
}

public Double getNebenkostenbetrag() {
	return this.Nebenkostenbetrag;
}

public String getOriginalAuftragsnummer() {
	return this.OriginalAuftragsnummer;
}

public String getOriginalKundennummer() {
	return this.OriginalKundennummer;
}

public Long getPaketanzahl() {
	return this.Paketanzahl;
}

public Long getPaketkennzeichen() {
	return this.Paketkennzeichen;
}

public Long getPaketshopbelieferungskennzeichen() {
	return this.Paketshopbelieferungskennzeichen;
}

public Long getPostzielcode() {
	return this.Postzielcode;
}

public Double getRabattbetrag() {
	return this.Rabattbetrag;
}

public Double getRatenaufschlagInProzent() {
	return this.RatenaufschlagInProzent;
}

public Double getRatenaufschlagbetrag() {
	return this.Ratenaufschlagbetrag;
}

public Long getRechnungsart() {
	return this.Rechnungsart;
}

public Long getRechnungsartikelFakturiert() {
	return this.RechnungsartikelFakturiert;
}

public Double getRechnungsbetrag() {
	return this.Rechnungsbetrag;
}

public Calendar getRechnungsdatum() {
	return this.Rechnungsdatum;
}

public Long getRechnungsnummer() {
	return this.Rechnungsnummer;
}

public Long getRetoureschluessel() {
	return this.Retoureschluessel;
}

public Long getRetoureschluesselCrossselling() {
	return this.RetoureschluesselCrossselling;
}

public Long getRichtungsymbol() {
	return this.Richtungsymbol;
}

public String getSendungskomplettierungskennzeichen() {
	return this.Sendungskomplettierungskennzeichen;
}

public String getSendungsschluessel() {
	return this.Sendungsschluessel;
}

public Long getSendungstermin() {
	return this.Sendungstermin;
}

public Long getUnterkontonummer() {
	return this.Unterkontonummer;
}

public Double getValutaaufschlagInProzent() {
	return this.ValutaaufschlagInProzent;
}

public Double getValutaaufschlagbetrag() {
	return this.Valutaaufschlagbetrag;
}

public Vertriebsgebiet getVertriebsgebiet() {
	return this.Vertriebsgebiet;
}

public Double getZahlscheingebuehrNachnahme() {
	return this.ZahlscheingebuehrNachnahme;
}

public String getZahlungskennzeichen() {
	return this.Zahlungskennzeichen;
}

public void setAltNeukundekennzeichen(String AltNeukundekennzeichen) {
	this.AltNeukundekennzeichen = AltNeukundekennzeichen;
}

public void setArtikelanzahl(Long Artikelanzahl) {
	this.Artikelanzahl = Artikelanzahl;
}

public void setBedienernummer(Long Bedienernummer) {
	this.Bedienernummer = Bedienernummer;
}

public void setBenutzernummer(Long Benutzernummer) {
	this.Benutzernummer = Benutzernummer;
}

public void setCPDKennzeichen(String CPDKennzeichen) {
	this.CPDKennzeichen = CPDKennzeichen;
}

public void setEilsendungbetrag(Double Eilsendungbetrag) {
	this.Eilsendungbetrag = Eilsendungbetrag;
}

public void setFakturierprioritaet(String Fakturierprioritaet) {
	this.Fakturierprioritaet = Fakturierprioritaet;
}

public void setGOLDTransferkennzeichen(Long GOLDTransferkennzeichen) {
	this.GOLDTransferkennzeichen = GOLDTransferkennzeichen;
}

public void setGewicht(Double Gewicht) {
	this.Gewicht = Gewicht;
}

public void setGutschriftverrechnungsbetrag(Double Gutschriftverrechnungsbetrag) {
	this.Gutschriftverrechnungsbetrag = Gutschriftverrechnungsbetrag;
}

public void setHermeskennzeichen(Long Hermeskennzeichen) {
	this.Hermeskennzeichen = Hermeskennzeichen;
}

public void setId(String Id) {
	this.Id = Id;
}

public void setIdcode(String Idcode) {
	this.Idcode = Idcode;
}

public void setKundenfirma(Kundenfirma Kundenfirma) {
	this.Kundenfirma = Kundenfirma;
}

public void setKundennummer(Long Kundennummer) {
	this.Kundennummer = Kundennummer;
}

public void setKundennummerCrossselling(Long KundennummerCrossselling) {
	this.KundennummerCrossselling = KundennummerCrossselling;
}

public void setKundenrechnungspositionCollection(Collection KundenrechnungspositionCollection) {
	this.KundenrechnungspositionCollection = KundenrechnungspositionCollection;
}

public void setLVDatum(Calendar LVDatum) {
	this.LVDatum = LVDatum;
}

public void setLVZeitkennzeichen(String LVZeitkennzeichen) {
	this.LVZeitkennzeichen = LVZeitkennzeichen;
}

public void setLetztesAenderungsdatum(Calendar LetztesAenderungsdatum) {
	this.LetztesAenderungsdatum = LetztesAenderungsdatum;
}

public void setLieferanschriftName(String LieferanschriftName) {
	this.LieferanschriftName = LieferanschriftName;
}

public void setLieferanschriftOrt(String LieferanschriftOrt) {
	this.LieferanschriftOrt = LieferanschriftOrt;
}

public void setLieferanschriftPostleitzahl(String LieferanschriftPostleitzahl) {
	this.LieferanschriftPostleitzahl = LieferanschriftPostleitzahl;
}

public void setLieferanschriftStrasse(String LieferanschriftStrasse) {
	this.LieferanschriftStrasse = LieferanschriftStrasse;
}

public void setLieferanschriftkennzeichen(String Lieferanschriftkennzeichen) {
	this.Lieferanschriftkennzeichen = Lieferanschriftkennzeichen;
}

public void setNebenkostenbetrag(Double Nebenkostenbetrag) {
	this.Nebenkostenbetrag = Nebenkostenbetrag;
}

public void setOriginalAuftragsnummer(String OriginalAuftragsnummer) {
	this.OriginalAuftragsnummer = OriginalAuftragsnummer;
}

public void setOriginalKundennummer(String OriginalKundennummer) {
	this.OriginalKundennummer = OriginalKundennummer;
}

public void setPaketanzahl(Long Paketanzahl) {
	this.Paketanzahl = Paketanzahl;
}

public void setPaketkennzeichen(Long Paketkennzeichen) {
	this.Paketkennzeichen = Paketkennzeichen;
}

public void setPaketshopbelieferungskennzeichen(Long Paketshopbelieferungskennzeichen) {
	this.Paketshopbelieferungskennzeichen = Paketshopbelieferungskennzeichen;
}

public void setPostzielcode(Long Postzielcode) {
	this.Postzielcode = Postzielcode;
}

public void setRabattbetrag(Double Rabattbetrag) {
	this.Rabattbetrag = Rabattbetrag;
}

public void setRatenaufschlagInProzent(Double RatenaufschlagInProzent) {
	this.RatenaufschlagInProzent = RatenaufschlagInProzent;
}

public void setRatenaufschlagbetrag(Double Ratenaufschlagbetrag) {
	this.Ratenaufschlagbetrag = Ratenaufschlagbetrag;
}

public void setRechnungsart(Long Rechnungsart) {
	this.Rechnungsart = Rechnungsart;
}

public void setRechnungsartikelFakturiert(Long RechnungsartikelFakturiert) {
	this.RechnungsartikelFakturiert = RechnungsartikelFakturiert;
}

public void setRechnungsbetrag(Double Rechnungsbetrag) {
	this.Rechnungsbetrag = Rechnungsbetrag;
}

public void setRechnungsdatum(Calendar Rechnungsdatum) {
	this.Rechnungsdatum = Rechnungsdatum;
}

public void setRechnungsnummer(Long Rechnungsnummer) {
	this.Rechnungsnummer = Rechnungsnummer;
}

public void setRetoureschluessel(Long Retoureschluessel) {
	this.Retoureschluessel = Retoureschluessel;
}

public void setRetoureschluesselCrossselling(Long RetoureschluesselCrossselling) {
	this.RetoureschluesselCrossselling = RetoureschluesselCrossselling;
}

public void setRichtungsymbol(Long Richtungsymbol) {
	this.Richtungsymbol = Richtungsymbol;
}

public void setSendungskomplettierungskennzeichen(String Sendungskomplettierungskennzeichen) {
	this.Sendungskomplettierungskennzeichen = Sendungskomplettierungskennzeichen;
}

public void setSendungsschluessel(String Sendungsschluessel) {
	this.Sendungsschluessel = Sendungsschluessel;
}

public void setSendungstermin(Long Sendungstermin) {
	this.Sendungstermin = Sendungstermin;
}

public void setUnterkontonummer(Long Unterkontonummer) {
	this.Unterkontonummer = Unterkontonummer;
}

public void setValutaaufschlagInProzent(Double ValutaaufschlagInProzent) {
	this.ValutaaufschlagInProzent = ValutaaufschlagInProzent;
}

public void setValutaaufschlagbetrag(Double Valutaaufschlagbetrag) {
	this.Valutaaufschlagbetrag = Valutaaufschlagbetrag;
}

public void setVertriebsgebiet(Vertriebsgebiet Vertriebsgebiet) {
	this.Vertriebsgebiet = Vertriebsgebiet;
}

public void setZahlscheingebuehrNachnahme(Double ZahlscheingebuehrNachnahme) {
	this.ZahlscheingebuehrNachnahme = ZahlscheingebuehrNachnahme;
}

public void setZahlungskennzeichen(String Zahlungskennzeichen) {
	this.Zahlungskennzeichen = Zahlungskennzeichen;
}

}

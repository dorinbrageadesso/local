package eu.wittgruppe.dias.util;

import java.math.BigDecimal;

public final class NumberUtils {
    public static Long toLong(Object numberObject) {
        long returnValue;
        if (numberObject instanceof BigDecimal numberBigDecimal) {
            returnValue = numberBigDecimal.longValue();
        } else if (numberObject instanceof Integer numberInteger) {
            returnValue = numberInteger.longValue();
        } else if (numberObject instanceof Long numberLong) {
            returnValue = numberLong;
        } else {
            throw new RuntimeException("Number-Object could not be cast to Long, as Object Class is neither " +
                    "Long, nor Integer or BigDecimal");
        }
        return returnValue;
    }
}

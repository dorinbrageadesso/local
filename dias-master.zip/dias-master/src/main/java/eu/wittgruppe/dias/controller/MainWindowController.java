package eu.wittgruppe.dias.controller;

import eu.wittgruppe.benutzerverwaltung.rest.client.BenutzerverwaltungRestClient;
import eu.wittgruppe.core.customersearch.client.CustomersearchRestClient;
import eu.wittgruppe.core.medien.client.MedienRestClient;
import eu.wittgruppe.dias.service.DiasService;
import eu.wittgruppe.dias.ui.MainWindow;
import eu.wittgruppe.dias.util.Images;
import eu.wittgruppe.dias.util.OnlineHilfe;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import witt.josef.benutzerverwaltung.Benutzerverwaltung;
import witt.josef.infrastructure.DefaultApplication;
import witt.josef.uiswing.ui.*;
import witt.josef.uiswing.ui.SplashScreen;

import javax.swing.*;
import java.awt.*;
import java.net.URL;
import java.util.Collection;
import java.util.List;

@Controller
@Slf4j
@Data
public class MainWindowController {

    //Prüft, ob der Benutzer nur Rechnungen aus den Schweizer VT's sehen darf
    //wird einmalig im Initalize gesetzt
    boolean onlyCH = false;

    @Autowired
    private DiasService diasService = null;

    @Autowired
    private MainWindow mainWindow = null;

    @Autowired
    private final DefaultApplication defaultApplication = null;

    @Autowired
    private Benutzerverwaltung benutzerverwaltung = null;
    
    @Autowired
    private CustomersearchRestClient customersearchRestClient = null;
    
    @Autowired
    private MedienRestClient medienRestClient = null;

    @Autowired
    private BenutzerverwaltungRestClient benutzerverwaltungRestClient;

    private ApplicationDetails applicationDetails;
    
    public CustomersearchRestClient getCustomersearchRestClient() {
        return customersearchRestClient;
    }
    
    public MedienRestClient getMedienRestClient() {
        return medienRestClient;
    }
    
    private Collection lieferanten = null;
    private Boolean druckerVorhanden = null;

    public void show(SplashScreen splash) {
        this.applicationDetails = splash.getApplicationDetails();
        initialize(splash);
    }

    public DefaultApplication getDefaultApplication() {
        return defaultApplication;
    }

    public void setMainWindow( MainWindow mainWindow ) {
        this.mainWindow = mainWindow;
    }

    public MainWindowController() {}

    public void setDiasService( DiasService diasService ) {
        this.diasService = diasService;
    }

    public MainWindow getMainWindow() {
        return mainWindow;
    }

    public DiasService getDiasService() {
        return diasService;
    }

    public String getActiveUserNDS() {
        return defaultApplication.getApplicationContext().getCurrentAccount().getName();
    }

    public Integer getActiveUserBedienernummer() {
        return defaultApplication.getApplicationContext().getCurrentAccount().getBedienernummer();
    }

    private void initialize(SplashScreen splash) {
        this.mainWindow.setSystemLookAndFeel();
        this.mainWindow.initialize();
        this.mainWindow.getContent().setBackground( SystemColor.activeCaption );

        try {

            Thread.sleep( 1000 );

            mainWindow.setApplicationDetails( splash.getApplicationDetails() );

            splash.setProgress( 2 );
            splash.setProgressText( "Lade Lieferanten" );
            // alle Lieferanten holen und Cachen
            lieferanten = diasService.sucheLieferanten();

            splash.setProgress( 3 );
            splash.setProgressText( "Prüfen ob Drucker vorhanden" );
            // Parameterverwaltung holen ob Drucker angeschlossen und merken
            String dvNummer = System.getenv( "DVNR" );
            druckerVorhanden = diasService.druckerAngeschlossen( dvNummer );

        } catch( Exception e ) {

            e.printStackTrace();
            new ErrorDialog( mainWindow, "Fehler Zugriff Appserver", true, e, e.getMessage(), true );
        }

        splash.setProgressText( "Initialisiere Hauptfenster" );
        splash.setProgress( 4 );


        String roleName = "kundenrechnungssuchech";
        try {
            List<String> kundenrechnungssucheCHUser = benutzerverwaltungRestClient.roles().findAllUserOfRole(applicationDetails.getApplicationName(), applicationDetails.getApplicationName(), "2", "0", roleName);
            for (String user : kundenrechnungssucheCHUser) {
                if (user.equals(defaultApplication.getApplicationContext().getCurrentAccount().getName())) {
                    log.info("User darf nur CH Kundenfirmen einsehen...");
                    onlyCH = true;
                    break;
                }
            }
        }catch(Exception e){
            log.error("Rolle {} konnt nicht ermittelt werden! Sicherheitshalber auf nur CH auf True setzen...", roleName,e);
            onlyCH = true;
        }
        this.mainWindow.addMenu();
        this.mainWindow.addToolBar();
        this.mainWindow.addStatusBar();
        this.mainWindow.setSize( 1024, 768 );
        this.mainWindow.setTitle( "DIAS" );

        splash.dispose();
        showMainWindow();
    }

    public void showMainWindow() {

        UIUtils.maximizeFrame( this.mainWindow );
        this.mainWindow.setVisible( true );
        this.mainWindow.setStatusTextRight( defaultApplication.getApplicationContext().getCurrentAccount().getFirstName() + " " + defaultApplication.getApplicationContext().getCurrentAccount().getLastName() );

    }

    public void showArtikelSearchDialog() {
        new ArtikelSearchController( this ).showArtikelSearchDialog();
    }

    public void showCRSArtikelSearchDialog() {
        new ArtikelSearchController( this ).showCrsArtikelSearchDialog();

    }

    public void showCRSArtikelSearchDialog( Long artnr6, String artikelGroesse, long identkz ) {
        new ArtikelSearchController( this ).showArtikelSearchDialog( artnr6, artikelGroesse, identkz );
    }

    public void showKundenRechnungenSearchDialog() {
        new KundenRechnungenPanelController( this, onlyCH ).showDialog();
    }

    public void showKundenMatchDialog() {

        new KundenMatchPanelController( this ).showDialog();

    }

    public void showStatistikChooser() {
        new DateRangePanelController( this,benutzerverwaltung ).showDialog();
    }

    public Collection getLieferanten() {
        return lieferanten;
    }

    public void setLieferanten( Collection lieferanten ) {
        this.lieferanten = lieferanten;
    }

    public Boolean getDruckerVorhanden() {
        return druckerVorhanden;
    }

    public void setDruckerVorhanden( Boolean druckerVorhanden ) {
        this.druckerVorhanden = druckerVorhanden;
    }

    public void linkToHelpFile() {

        URL url = this.getClass().getResource( "/DIAS" + ".mht" );
        if( url != null ) {
            log.debug( url.toString() );
            // erstes Slash abschneiden funktioniert sonst nicht mit IExplorer
            new OnlineHilfe( url.getPath().substring( 1 ) ).show();
        }

    }
}

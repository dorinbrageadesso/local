
/*
*                                 J O S E F
*               Java Object Solutions Enterprise Framework
*                  Copyright 2002 - 2004 Josef Witt GmbH
*/


package eu.wittgruppe.dias.ui.renderer;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;


public class DiasTableCellRenderer extends DefaultTableCellRenderer {
    //~ Instance fields ----------------------------------------------------------------------------

    private Color backgroundGerade = Color.WHITE;
    private Color backgroundSelection = new Color(255,255,145);
    private Color backgroundUngerade = new Color(240,240,255);
    private Color foregroundGerade = Color.BLACK;
    private Color foregroundSelection = Color.BLACK;
    private Color foregroundUngerade = Color.BLACK;
    private Font font = null;

    //~ Constructors -------------------------------------------------------------------------------

    public DiasTableCellRenderer(  ) {
    }

    //~ Methods ------------------------------------------------------------------------------------

    public void setBackgroundGerade( Color c ) {
        this.backgroundGerade = c;
    }

    public void setBackgroundSelection( Color c ) {
        this.backgroundSelection = c;
    }

    public void setBackgroundUngerade( Color c ) {
        this.backgroundUngerade = c;
    }

    public void setForegroundGerade( Color c ) {
        this.foregroundGerade = c;
    }

    public void setForegroundSelection( Color c ) {
        this.foregroundSelection = c;
    }

    public void setForegroundUngerade( Color c ) {
        this.foregroundUngerade = c;
    }

    public Component getTableCellRendererComponent( 
        JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column ) {
        super.getTableCellRendererComponent( table, value, isSelected, hasFocus, row, column );

        if( this.font == null ) {
            font = new Font( this.getFont(  ).getName(  ), Font.PLAIN, 13 );
            this.setFont( font );
            table.setFont( font );
        }

        if( isSelected ) {
            this.setForeground( foregroundSelection );
            this.setBackground( backgroundSelection );
        } else {
            if( ( row % 2 ) == 0 ) {
                this.setForeground( foregroundGerade );
                this.setBackground( backgroundGerade );
            } else {
                this.setForeground( foregroundUngerade );
                this.setBackground( backgroundUngerade );
            }
        }

        return this;
    }
}

package eu.wittgruppe.dias.util;

import javax.swing.event.TableModelEvent;
import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class GenericTableModel extends AbstractTableModel {

  public final static int ROW_NOT_FOUND = -1;
  public final static int COLUMN_NOT_FOUND = -1;

  private ArrayList buffer = new ArrayList();
  private String[] columnNames = null;
  private boolean[] editableFlag = null;
  private int columnCount = 0;


  private Object[] newRow() {
    Object[] oa = new Object[columnCount];
    for(int i=0;i<columnCount;++i)
      oa[i] = null;
    return oa;
  }

  private void initColumns(String[] cNames) {
    columnCount = cNames.length;
    columnNames = cNames;
    editableFlag = new boolean[columnCount];
  }

  private void initRows(int nRows) {
    for(int i=0;i<nRows;++i) {
      addRow();
    }
  }

  public GenericTableModel(String[] cNames) {
    initColumns(cNames);
  }

  public GenericTableModel(String[] cNames,int nRows) {
    this(cNames);
    initRows(nRows);
  }

  /**
   * Erzeugen eines TableModels anhand von Spaltennamen und einer Objektmatrix
   * @param cNames Spaltennamen
   * @param objects Objektmatrix
   */
  public GenericTableModel(String[] cNames,Object[][] objects)
  {
    this(cNames);
    for(int i=0;i<objects.length;++i) {
      buffer.add(objects[i]);
    }
  }

  /**
   * Erzeugen eines TableModels anhand von Spaltennamen und einer Objektmatrix
   * @param tm TableModel
   */
  public GenericTableModel(GenericTableModel tm)
  {
    this.columnCount = tm.columnCount;
    // Spaltennamen übernehmen
    this.columnNames = tm.columnNames;
    // editable-Flags übernehmen
    this.editableFlag = tm.editableFlag;
    // Objektmatrix übernehmen
    this.buffer = tm.buffer;
  }

  /**
   * Eine leere Zeile anfügen
   * Die neue Zeile enthält getColumnCount() Felder
   * @return Position der angefügten Zeile
   */
   public int addRow() {
    buffer.add(newRow());
    int r = getRowCount();
    this.fireTableRowsInserted( r - 1 , r - 1 );
    return r - 1;
   }

  /**
   * Eine leere Zeile anfügen
   * Die neue Zeile enthält getColumnCount Felder
   * @param oa Object Array
   * @return Position der angefügten Zeile
   */
   public int addRow(Object[] oa) {
    buffer.add(oa);
    int r = getRowCount();
    this.fireTableRowsInserted( r - 1 , r - 1 );
    return r - 1;
   }

  /**
   * Eine Zeile löschen<br>
   * @param r Löschposition
   */
   public void deleteRow(int r) {
    buffer.remove(r);
    this.fireTableRowsDeleted( r , r );
   }

   /**
    * Ermittelt den Spaltenindex anhand des Spaltennamens<br>
    * @param name Spaltenname
    * @return Spaltenindex bzw. -1, wenn Spalte nicht gefunden
    */
    public int findColumn(java.lang.String name) {
      for(int i=0;i<columnCount;++i) {
	if(name.equals(columnNames[i]))
	  return i;
      }
      return COLUMN_NOT_FOUND;
    }

  /**
   * gibt die Spaltenanzahl zurueck
   * @return Spaltenanzahl
   */
  public int getColumnCount() {
    return this.columnCount;
  }

  /**
   * ermittelt die Bezeichnung einer Spalte
   * @param col Spaltenindex, beginnend mit 0
   * @return Spaltenbezeichnung
   */
  public String getColumnName(int col) {
    return columnNames[col];
  }

  /**
   * ermittelt die Anzahl der Zeilen
   * @return Zeilenananzahl
   */
  public int getRowCount() {
    return buffer.size();
  }

  /**
   * gibt das Objekt an einer bestimmten Position zurueck
   * @param row Row
   * @param col Column
   * @return Zelleninhalt
   */
  public Object getValueAt(int row, int col) {
    return ((Object[])buffer.get(row))[col];
  }

   public int insertRow(int r) {
    buffer.add(r,newRow());
    this.fireTableRowsInserted( r , r );
    return r;
   }

  /**
   * Eine Zeile einfügen<br>
   * Die neue Zeile enthält getColumnCount() Felder
   * @param r Einfügeposition
   * @param oa Einfügeposition Object Array
   * @return Zeile
   */
   public int insertRow(int r,Object[] oa) {
    buffer.add(r,oa);
    this.fireTableRowsInserted( r , r );
    return r;
   }

  /**
   * ermittelt, ob die betreffende Zelle editiert werden kann
   * @param row Zeilenindex, beginnend mit 0
   * @param col Spaltenindex, beginnend mit 0
   * @return true == Zelle ist editierbar, false == Zelle ist nicht editierbar
   */
  public boolean isCellEditable(int row,int col) {
    return editableFlag[col];
  }

  /**
   * legt fest, ob die Zellen einer Spalte editierbar sind
   * @param col Spaltenindex, beginnend mit 0
   * @param b   true == ist editierbar, false == ist nicht editierbar
   */
  public void setColumnEditable(int col,boolean b) {
    if(col>=0&&col<columnCount)
      editableFlag[col] = b;
  }

  public void setColumnEditable(int col) {
    setColumnEditable(col,true);
  }

  /**
   * setzt eine neue Spaltenbezeichnung
   * @param col Spaltenindex, beginnend mit 0
   * @param s   Spaltenbezeichnung
   */
  public void setColumnName(int col,String s) {
    if(col>=0&&col<columnCount)
      columnNames[col] = s;
    this.fireTableChanged( new TableModelEvent( this , TableModelEvent.HEADER_ROW ) );
  }

  /**
   * versorgt eine bestimmte Position mit einem neuen Wert ( Objekt )
   * @param obj der neue Wert
   * @param row Zeilenposition
   * @param col Spaltenposition
   */
  public void setValueAt(Object obj,int row,int col) {
    if(col>=0&&col<columnCount&&row<getRowCount())
    {
      Object[] tmp = (Object[])buffer.get(row);
      tmp[col] = obj;
      buffer.set(row,tmp);
      this.fireTableCellUpdated( row , col );
    }
  }

}
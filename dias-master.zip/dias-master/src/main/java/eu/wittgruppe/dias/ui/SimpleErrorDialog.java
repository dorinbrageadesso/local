/*
 * Created on 13.12.2005
 */
package eu.wittgruppe.dias.ui;

import org.apache.commons.lang.exception.ExceptionUtils;

import javax.swing.*;
import java.awt.*;


public class SimpleErrorDialog extends JDialog {

    private JPanel jContentPane = null;
    private JPanel southPanel = null;
    private JButton okButton = null;
    private JPanel northPanel = null;
    private JLabel iconLabel = null;
    private JLabel errorMessageLabel = null;
    private Component parent = null;
    
    private String errorMessage = null;
    private String detailedErrorMessage = null;
    private JScrollPane scrollPane = null;
    private JTextArea detailedErrorMessagetextArea = null;
    

    /**
     * This is the default constructor
     */
    public SimpleErrorDialog() {
        super();
        init( null, "", false, "", "" );
    }
    
    public SimpleErrorDialog( Frame parent, String title, boolean centered ) {
        super( parent );
        init( parent, title, centered, "", "" );
    }
    
    public SimpleErrorDialog( Dialog parent, String title, boolean centered ) {
        super( parent );
        init( parent, title, centered, "", "" );
    }
    
    public SimpleErrorDialog( Dialog parent, String title, boolean centered, 
            String errorMessage, String detailErrorMessage ) {
        super( parent );
        init( parent, title, centered, errorMessage, detailErrorMessage );
    }
    
    public SimpleErrorDialog( Dialog parent, String title, boolean centered, 
            String errorMessage, Throwable t ) {
        super( parent );
        init( parent, title, centered, errorMessage, ExceptionUtils.getFullStackTrace( t ) );
    }
    
    public SimpleErrorDialog( Frame parent, String title, boolean centered, 
            String errorMessage, String detailErrorMessage ) {
        super( parent );
        init( parent, title, centered, errorMessage, detailErrorMessage );
    }
    
    public SimpleErrorDialog( Frame parent, String title, boolean centered, 
            String errorMessage, Throwable t ) {
        super( parent );
        init( parent, title, centered, errorMessage, ExceptionUtils.getFullStackTrace( t ) );
    }
    
    private void init( Component parent, String title, boolean centered, String errorMessage, String detailErrorMessage ) {
        initialize();
        this.parent = parent;
        setTitle( title );
        setErrorMessage( errorMessage );
        setDetailedErrorMessage( detailErrorMessage );
        if( centered ) {
            centerOverParent();
        }
    }
    
    public void centerOverParent() {
        UIUtils.centerOverComponent( parent, this );
    }

    /**
     * This method initializes southPanel	
     * 	
     * @return javax.swing.JPanel	
     */
    private JPanel getSouthPanel() {
        if( southPanel == null ) {
            FlowLayout flowLayout = new FlowLayout();
            flowLayout.setAlignment(java.awt.FlowLayout.RIGHT);
            southPanel = new JPanel();
            southPanel.setLayout(flowLayout);
            southPanel.add(getOkButton(), null);
        }
        return southPanel;
    }

    /**
     * This method initializes okButton	
     * 	
     * @return javax.swing.JButton	
     */
    private JButton getOkButton() {
        if( okButton == null ) {
            okButton = new JButton();
            okButton.setText("OK");
            okButton.setMinimumSize(new java.awt.Dimension(70,26));
            okButton.setPreferredSize(new java.awt.Dimension(70,26));
            okButton.setMaximumSize(new java.awt.Dimension(70,26));
            okButton.addActionListener( new java.awt.event.ActionListener() {
                public void actionPerformed( java.awt.event.ActionEvent e ) {
                    dispose();
                }
            } );
        }
        return okButton;
    }

    /**
     * This method initializes northPanel	
     * 	
     * @return javax.swing.JPanel	
     */
    private JPanel getNorthPanel() {
        if( northPanel == null ) {
            FlowLayout flowLayout1 = new FlowLayout();
            flowLayout1.setAlignment(java.awt.FlowLayout.LEFT);
            errorMessageLabel = new JLabel();
            errorMessageLabel.setText("Fehler");
            errorMessageLabel.setMinimumSize(new java.awt.Dimension(200,16));
            errorMessageLabel.setPreferredSize(new java.awt.Dimension(200,16));
            errorMessageLabel.setMaximumSize(new java.awt.Dimension(2000,16));
            iconLabel = new JLabel( UIManager.getIcon( "OptionPane.errorIcon" ) );
            northPanel = new JPanel();
            northPanel.setLayout(flowLayout1);
            northPanel.add(iconLabel, null);
            northPanel.add(errorMessageLabel, null);
        }
        return northPanel;
    }

    /**
     * This method initializes scrollPane	
     * 	
     * @return javax.swing.JScrollPane	
     */
    private JScrollPane getScrollPane() {
        if( scrollPane == null ) {
            scrollPane = new JScrollPane();
            scrollPane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Grund", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, null, null));
            scrollPane.setViewportView(getDetailedErrorMessagetextArea());
        }
        return scrollPane;
    }

    /**
     * This method initializes jTextArea	
     * 	
     * @return javax.swing.JTextArea	
     */
    private JTextArea getDetailedErrorMessagetextArea() {
        if( detailedErrorMessagetextArea == null ) {
            detailedErrorMessagetextArea = new JTextArea();
            //detailedErrorMessagetextArea.setEnabled(true);
            detailedErrorMessagetextArea.setEditable(false);
        }
        return detailedErrorMessagetextArea;
    }

    /**
     * This method initializes this
     * 
     * @return void
     */
    private void initialize() {
        this.setSize(600, 500);
        this.setContentPane( getJContentPane() );
    }

    /**
     * This method initializes jContentPane
     * 
     * @return javax.swing.JPanel
     */
    private JPanel getJContentPane() {
        if( jContentPane == null ) {
            jContentPane = new JPanel();
            jContentPane.setLayout( new BorderLayout() );
            jContentPane.add(getSouthPanel(), java.awt.BorderLayout.SOUTH);
            jContentPane.add(getNorthPanel(), java.awt.BorderLayout.NORTH);
            jContentPane.add(getScrollPane(), java.awt.BorderLayout.CENTER);
        }
        return jContentPane;
    }

    /**
     * @return Returns the detailedErrorMessage.
     */
    public String getDetailedErrorMessage() {
        return detailedErrorMessage;
    }

    /**
     * @param detailedErrorMessage The detailedErrorMessage to set.
     */
    public void setDetailedErrorMessage( String detailedErrorMessage ) {
        this.detailedErrorMessage = detailedErrorMessage;
        getDetailedErrorMessagetextArea().setText( getDetailedErrorMessage() );
        
        
        SwingUtilities.invokeLater( new Runnable() {
            public void run() {
                getScrollPane().getVerticalScrollBar().setValue( 0 );
                getScrollPane().getHorizontalScrollBar().setValue( 0 );
            
            }
        } );
    }
    
    public void setDetailedErrorMessage( Throwable t ) {
        setDetailedErrorMessage( ExceptionUtils.getFullStackTrace( t ) );
    }
    
    /**
     * @return Returns the errorMessage.
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * @param errorMessage The errorMessage to set.
     */
    public void setErrorMessage( String errorMessage ) {
        this.errorMessage = errorMessage;
        errorMessageLabel.setText( getErrorMessage() );
    }
}  //  @jve:decl-index=0:visual-constraint="10,10"

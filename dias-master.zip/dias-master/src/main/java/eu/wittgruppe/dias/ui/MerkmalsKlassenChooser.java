package eu.wittgruppe.dias.ui;

import eu.wittgruppe.dias.controller.MerkmalsKlassenChooserController;
import eu.wittgruppe.dias.util.Images;
import eu.wittgruppe.dias.util.TreeNodeBean;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import java.awt.*;

;

public class MerkmalsKlassenChooser extends JDialog {
	
	MerkmalsKlassenChooserController controller = null;
	
	private JPanel jContentPane = null;
	private JScrollPane jScrollPane = null;
	private JTree merkmalsTree = null;
	private JPanel centerPanel = null;
	private JPanel southPanel = null;
	private JButton okButton = null;
	private JButton canelButton = null;

	private JToolBar toolBar = null;

	private JButton expandButton = null;

	private JButton collapseButton = null;

	 
	public MerkmalsKlassenChooser(MerkmalsKlassenChooserController controller) {
		super();
		this.controller = controller;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(430, 528);
		this.setTitle("Merkmalsklassenauswahl");
		this.setContentPane(getJContentPane());
		this.addWindowListener(new WindowCloseEvent());
		UIUtils.centerOnScreen(this);
		controller.getParentController().getParentController().getMainWindow().setEnabled(false);
		
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getCenterPanel(), java.awt.BorderLayout.CENTER);
			jContentPane.add(getSouthPanel(), java.awt.BorderLayout.SOUTH);
			jContentPane.add(getToolBar(), java.awt.BorderLayout.NORTH);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setViewportView(getMerkmalsTree());
		}
		return jScrollPane;
	}

	/**
	 * This method initializes merkmalsTree	
	 * 	
	 * @return javax.swing.JTree	
	 */
	public JTree getMerkmalsTree() {
		if (merkmalsTree == null) {
			DefaultMutableTreeNode root = controller.createTreeNodes();			
			merkmalsTree = new JTree(root);					
			merkmalsTree.addMouseListener(new DoubleClickOnTree());
		}
		return merkmalsTree;
	}

	/**
	 * This method initializes northPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getCenterPanel() {
		if (centerPanel == null) {
			GridBagConstraints gridBagConstraints = new GridBagConstraints();
			gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
			gridBagConstraints.gridx = 0;
			gridBagConstraints.gridy = 0;
			gridBagConstraints.weightx = 1.0;
			gridBagConstraints.weighty = 1.0;
			gridBagConstraints.insets = new java.awt.Insets(5,5,5,5);
			centerPanel = new JPanel();
			centerPanel.setLayout(new GridBagLayout());
			centerPanel.add(getJScrollPane(), gridBagConstraints);
		}
		return centerPanel;
	}

	/**
	 * This method initializes southPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getSouthPanel() {
		if (southPanel == null) {
			southPanel = new JPanel();
			southPanel.add(getOkButton(), null);
			southPanel.add(getCancelButton(), null);
		}
		return southPanel;
	}

	/**
	 * This method initializes jButton1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getOkButton() {
		if (okButton == null) {
			okButton = new JButton();
			okButton.setMaximumSize(new Dimension(108, 26));
			okButton.setPreferredSize(new Dimension(108, 26));
			okButton.setText("OK");
			okButton.setMinimumSize(new Dimension(108, 26));
			okButton.addActionListener(new OnOKButton());
		}
		return okButton;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getCancelButton() {
		if (canelButton == null) {
			canelButton = new JButton();
			canelButton.setMaximumSize(new Dimension(108, 26));
			canelButton.setPreferredSize(new Dimension(108, 26));
			canelButton.setText("Abbrechen");
			canelButton.setMinimumSize(new Dimension(108, 26));	
			canelButton.addActionListener(new OnCanelButton());
			
		}
		return canelButton;
	}


	/**
	 * This method initializes toolBar	
	 * 	
	 * @return javax.swing.JToolBar	
	 */
	private JToolBar getToolBar() {
		if (toolBar == null) {
			toolBar = new JToolBar();			
			toolBar.setOpaque(true);
			toolBar.setFloatable(false);
			toolBar.add(getExpandButton());
			toolBar.add(getCollapseButton());
						
		}
		return toolBar;
	}

	/**
	 * This method initializes expandButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getExpandButton() {
		if (expandButton == null) {
			expandButton = new JButton();
			expandButton.setIcon(Images.EXPAND_ALL);
			expandButton.setToolTipText("Baum aufklappen");
			expandButton.addActionListener(new OnExpandAll());
		}
		return expandButton;
	}

	/**
	 * This method initializes collapseButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getCollapseButton() {
		if (collapseButton == null) {
			collapseButton = new JButton();
			collapseButton.setIcon(Images.COLLAPSE_ALL);
			collapseButton.setToolTipText("Baum zusammenklappen");
			collapseButton.addActionListener(new OnCollapseAll());
		}
		return collapseButton;
	}
	
//	 L I S T E N E R S
	/**
	 * @author Mather
	 * Beim Schliessen
	 */
	private class WindowCloseEvent extends java.awt.event.WindowAdapter {
		public void windowClosing(java.awt.event.WindowEvent e) {
			controller.getParentController().getParentController().getMainWindow().setEnabled(true);
		}
	}	
	/**
	 * @author Mather
	 * beim Drücken des OK Button
	 */
	private class OnOKButton implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			
			controller.getParentController().getParentController().getMainWindow().setEnabled(true);
			TreeNodeBean nodeVO = controller.getSelectTreeNodeBean();
			
			((ArtikelSearchCriteriaPanel)controller.getParentController().getArtikelSearchPanel()
					.getSearchPanel()).getMerkmalKlasseTextField().setValueObject(nodeVO);
		}
	}
	
	/**
	 * @author Mather
	 * beim Drücken des CancelButton
	 */
	private class OnCanelButton implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			controller.getParentController().getParentController().getMainWindow().setEnabled(true);
			MerkmalsKlassenChooser.this.dispose();
		}
	}
	
	/**
	 * @author Mather
	 * wenn ein Lieferant ausgewählt wird
	 */
	private class DoubleClickOnTree extends java.awt.event.MouseAdapter {
		public void mouseClicked(java.awt.event.MouseEvent e) {
			
			if (e.getClickCount()==2) {
				
				controller.getParentController().getParentController().getMainWindow().setEnabled(true);
				TreeNodeBean nodeVO = controller.getSelectTreeNodeBean();
				
				((ArtikelSearchCriteriaPanel)controller.getParentController().getArtikelSearchPanel()
						.getSearchPanel()).getMerkmalKlasseTextField().setValueObject(nodeVO);
				
								
			}			
			
		}
	}
	

	private class OnExpandAll implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			controller.expandTree();
		}
	};

	private class OnCollapseAll implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			controller.collapseTree();
		}
	};
	
}  //  @jve:decl-index=0:visual-constraint="10,10"

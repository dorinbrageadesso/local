package eu.wittgruppe.dias.ui;

import eu.wittgruppe.dias.util.Images;

import javax.swing.*;
import java.awt.*;

public class WaitView extends JWindow {

	private JPanel jContentPane = null;
	private JPanel jPanel = null;
	private JLabel waitLabel = null;
	private JLabel textLabel = null;

	public WaitView(JFrame parent) {
		super(parent);
		initialize();
	}

	private void initialize() {
		this.setSize(124, 36);
		this.setBackground(java.awt.SystemColor.control);
		this.setContentPane(getJContentPane());
		
	}
	
	
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.setBackground(java.awt.SystemColor.control);
			jContentPane.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.LOWERED));
			jContentPane.add(getJPanel(), java.awt.BorderLayout.CENTER);
		}
		return jContentPane;
	}

	private JPanel getJPanel() {
		if (jPanel == null) {
			GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
			gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
			gridBagConstraints1.insets = new java.awt.Insets(0,2,0,0);
			gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
			GridBagConstraints gridBagConstraints = new GridBagConstraints();
			gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints.insets = new java.awt.Insets(0,0,0,2);
			textLabel = new JLabel();
			textLabel.setText("Bitte warten...");
			waitLabel = new JLabel();
			waitLabel.setIcon(Images.WAIT);
			jPanel = new JPanel();
			jPanel.setLayout(new GridBagLayout());
			jPanel.add(waitLabel, gridBagConstraints);
			jPanel.add(textLabel, gridBagConstraints1);
		}
		return jPanel;
	}

} 

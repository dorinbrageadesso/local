package eu.wittgruppe.dias.ui;

import eu.wittgruppe.dias.controller.ArtikelSearchController;

import javax.swing.*;
import java.awt.*;

public class ArtikelSearchPanel extends JPanel {
	
	private ArtikelSearchController controller = null;
	private GradientPanel searchPanel = null;
	private JPanel centerPanel = null;
	private JScrollPane centerScrollPane = null;
	private JPanel pageNumberPanel = null;
	private JPanel mainPanel = null;
	
	
	public ArtikelSearchPanel(ArtikelSearchController controller) {
		// TODO Auto-generated constructor stub
		this.controller = controller;
		initialize();
	}

	

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		
		
		this.setLayout(new BorderLayout());		
		///Dimension size = controller.getParentController().getMainWnd().getSize();
		this.setSize(800, 600);
		this.add(getMainPanel(), java.awt.BorderLayout.CENTER);
		
	}



	public GradientPanel getSearchPanel() {
		return searchPanel;
	}



	public void setSearchPanel(GradientPanel northPanel) {
		this.searchPanel = northPanel;
		this.add(searchPanel, java.awt.BorderLayout.NORTH);
		//this.searchPanel.getTextLabel().setHorizontalAlignment( SwingConstants.RIGHT );
	}



	/**
	 * This method initializes centerPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	public JPanel getCenterPanel() {
		if (centerPanel == null) {
			ScrollFlowLayout scrollFlowLayout = new ScrollFlowLayout();
			scrollFlowLayout.setHgap(10);
			scrollFlowLayout.setVgap(10);
			
			centerPanel = new JPanel();
			centerPanel.setLayout(scrollFlowLayout);
//			centerPanel.setMinimumSize(new java.awt.Dimension(689,344));
			//centerPanel.setPreferredSize(new java.awt.Dimension(689,344));
//			centerPanel.setFocusCycleRoot(false);
		}
		return centerPanel;
	}



	/**
	 * This method initializes centerScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	public JScrollPane getCenterScrollPane() {
		if (centerScrollPane == null) {
			centerScrollPane = new JScrollPane();
			//centerScrollPane.setMaximumSize(new java.awt.Dimension(689,344));
//			centerScrollPane.setMinimumSize(new java.awt.Dimension(707,347));
			//centerScrollPane.setPreferredSize(new java.awt.Dimension(689,344));
			centerScrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
			centerScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			centerScrollPane.setViewportView(getCenterPanel());
		}
		return centerScrollPane;
	}



	/**
	 * This method initializes northPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	public JPanel getPageNumberPanel() {
		if (pageNumberPanel == null) {
			pageNumberPanel = new JPanel();
		}
		return pageNumberPanel;
	}



	/**
	 * This method initializes mainPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getMainPanel() {
		if (mainPanel == null) {
			mainPanel = new JPanel();
			mainPanel.setLayout(new BorderLayout());
			mainPanel.add(getCenterScrollPane(), java.awt.BorderLayout.CENTER);
			mainPanel.add(getPageNumberPanel(), java.awt.BorderLayout.NORTH);
		}
		return mainPanel;
	}
	
	/**
	 * @param page
	 * setzt die Seitennummer als Link um durch click zu navigieren
	 */
	public void setPageNumber(int page) {
		
		JLabel pageNoLabel = new JLabel("<html><u>" + Integer.toString(page) + "</u></html>");
		pageNoLabel.setFont(new java.awt.Font("Dialog", java.awt.Font.PLAIN, 14));
		pageNoLabel.setForeground(Color.BLUE);
		pageNoLabel.setToolTipText(Integer.toString(page));
		pageNoLabel.addMouseListener(new PageLabelMouseListener());
		
		getPageNumberPanel().add(pageNoLabel);			
		
	}	
	
	/**
	 * Beim erzeugen des IndexArrays werden die Navigations Pfeile erzeugt
	 */
	public void createNavigationArrows() {
		
		
		JLabel firstPageLabel = new JLabel("<html><u>"+ "|&lt;" + "</u></html>");
		firstPageLabel.setFont(new java.awt.Font("Dialog", java.awt.Font.PLAIN, 14));
		firstPageLabel.setForeground(Color.BLUE);
		firstPageLabel.setToolTipText("Anfang");
		firstPageLabel.addMouseListener(new ArrowLabelMouseListener());
		
		getPageNumberPanel().add(firstPageLabel);	
		
		JLabel prevPageLabel = new JLabel("<html><u>"+ "&lt;&lt;" + "</u></html>");
		prevPageLabel.setFont(new java.awt.Font("Dialog", java.awt.Font.PLAIN, 14));
		prevPageLabel.setForeground(Color.BLUE);
		prevPageLabel.setToolTipText("vorherige");
		prevPageLabel.addMouseListener(new ArrowLabelMouseListener());
		
		getPageNumberPanel().add(prevPageLabel);		
		getPageNumberPanel().add(new JLabel("  "));
		
		JLabel nextPageLabel = new JLabel("<html><u>"+ "&gt;&gt;" + "</u></html>");
		nextPageLabel.setFont(new java.awt.Font("Dialog", java.awt.Font.PLAIN, 14));
		nextPageLabel.setForeground(Color.BLUE);
		nextPageLabel.setToolTipText("nächste");
		nextPageLabel.addMouseListener(new ArrowLabelMouseListener());
		
		getPageNumberPanel().add(nextPageLabel);
		
		JLabel lastPageLabel = new JLabel("<html><u>"+ "&gt;|" + "</u></html>");
		lastPageLabel.setFont(new java.awt.Font("Dialog", java.awt.Font.PLAIN, 14));
		lastPageLabel.setForeground(Color.BLUE);
		lastPageLabel.setToolTipText("Ende");
		lastPageLabel.addMouseListener(new ArrowLabelMouseListener());
		
		getPageNumberPanel().add(lastPageLabel);
		getPageNumberPanel().add(new JLabel(" "));
		
	}
	
	
	
	private class PageLabelMouseListener extends java.awt.event.MouseAdapter {
		
		public void mouseClicked(java.awt.event.MouseEvent e) {
			
			if (e.getClickCount()==1) {
				// Farbe der PageLabels auf Blau setzen
				controller.resetPageLabelColor(ArtikelSearchPanel.this.getPageNumberPanel());
				// geclickten Label grau setzen
				JLabel pageNoLabel = (JLabel)e.getSource();
				
				controller.setAktPage(Integer.parseInt((pageNoLabel.getToolTipText())));
			
				// PageNr auslesen und Artikelbilder neu aufbauen
				controller.createArtikelPanels(controller.getSearchedArtikel(), 
													   controller.getAktPage());
				
			}			
		}	
		
		public void mouseEntered(java.awt.event.MouseEvent e) {
						
			ArtikelSearchPanel.this.setCursor(new Cursor(Cursor.HAND_CURSOR));
		}
		
		public void mouseExited(java.awt.event.MouseEvent e) {
			
			ArtikelSearchPanel.this.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		}
		
	}
	
	private class ArrowLabelMouseListener extends java.awt.event.MouseAdapter {
		
		public void mouseClicked(java.awt.event.MouseEvent e) {
			
			if (e.getClickCount()==1) {
				
				JLabel pageNoLabel = (JLabel)e.getSource();
				
				int pageNr = 0 ;
				
				if (pageNoLabel.getToolTipText().equalsIgnoreCase("Anfang")) {
					pageNr = controller.getFirstPage();	
					
				}
				else if (pageNoLabel.getToolTipText().equalsIgnoreCase("vorherige")) {
					pageNr = controller.getPrevPage(controller.getAktPage());
					
				}
				else if (pageNoLabel.getToolTipText().equalsIgnoreCase("nächste")) {
					
					pageNr = controller.getNextPage(controller.getAktPage());					
				 
				}
				else if (pageNoLabel.getToolTipText().equalsIgnoreCase("Ende")) {
					pageNr = controller.getLastPage();					
					 
				}
				// aktuelle Seite setzen und PageNoLabel als geclickt ausweisen
				controller.setAktPage(pageNr);	
				
				// PageNr auslesen und Artikelbilder neu aufbauen
				controller.createArtikelPanels(controller.getSearchedArtikel(), 
											   controller.getAktPage());
			}			
		}	
		
		public void mouseEntered(java.awt.event.MouseEvent e) {
						
			ArtikelSearchPanel.this.setCursor(new Cursor(Cursor.HAND_CURSOR));
		}
		
		public void mouseExited(java.awt.event.MouseEvent e) {
			
			ArtikelSearchPanel.this.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		}
		
	}
	
	

}  //  @jve:decl-index=0:visual-constraint="10,10"

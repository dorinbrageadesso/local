package eu.wittgruppe.dias.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;

@Entity(name = "Merkmalklasse")
@Table(name = "merkmalklasse")
public class MerkmalklasseDiamant implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Column (name="merkmalklbez")
	private String bezeichnung = null;
	
	@Id
	@Column (name="merkmalklnr")
	private Long nr = null;
    
	public Long getNr() {
		return nr;
	}
	
	public void setNr(Long nr) {
		this.nr = nr;
	}
	
	public String getBezeichnung() {
		return bezeichnung;
	}
	
	public void setBezeichnung(String bezeichnung) {
		this.bezeichnung = bezeichnung;
	}
	
}

/**
 * 
 */
package eu.wittgruppe.dias.controller;

import eu.wittgruppe.dias.ui.KundenMatchDialog;
import lombok.extern.slf4j.Slf4j;
import witt.josef.uiswing.ui.UIUtils;

/**
 * @author Mather
 *
 */
@Slf4j
public class KundenMatchDialogController extends KundenMatchPanelController {
	
	private KundenRechnungenPanelController parentController = null;
	
	private KundenMatchDialog dialog = null;

	public KundenMatchDialogController(KundenRechnungenPanelController parentController) {
		super(parentController.getParentController());
		this.parentController = parentController;	
		
		this.dialog = new KundenMatchDialog(this);
		
	}		
	
	public void showDialog() {		
		
		//parentController.getParentController().getMainWnd().setIconImage(Images.KUNDE_MATCH.getImage());
		
		UIUtils.centerOverComponent(parentController.getParentController().getMainWindow(), this.dialog);
		
		this.dialog.setVisible(true);
		
	}
	
	public void closeDialog() {	
		
		this.dialog.setVisible(false);		
	}	
	
	
	public KundenRechnungenPanelController getParentController() {
		return this.parentController;
	}
	
	
	

	
	
}

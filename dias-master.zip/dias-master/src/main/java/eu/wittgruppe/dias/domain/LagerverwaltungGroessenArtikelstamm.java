package eu.wittgruppe.dias.domain;

import org.apache.commons.lang.builder.ToStringBuilder;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity(name = "LagerverwaltungGroessenArtikelstamm")
@Table(name = "LG_GR_ARTSTA")
public class LagerverwaltungGroessenArtikelstamm implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private LagerverwaltungGroessenArtikelstammPK pk = null;

	public LagerverwaltungGroessenArtikelstammPK getPk() {
		return pk;
	}

	public void setPk(LagerverwaltungGroessenArtikelstammPK pk) {
		this.pk = pk;
	}

	/*
	 * Aenderungsdatum
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "AENDDAT")
	private Date aenderungsdatum = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "benutzerid", referencedColumnName = "id")
	private Benutzer benutzer = null;

	/*
	 * letztes Fakturierdatum
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "FAKTDAT")
	private Date fakturierungsdatum = null;

	/*
	 * KZ, ob Artikel fakturierfaehig ist
	 */
	@Column(name = "FAKTFAEHIGKZ")
	private Long fakturierfaehigKz = null;

	/*
	 * Fakturiermenge, die zuletzt fakturiert wurde
	 */
	@Column(name = "FAKTMG")
	private Long fakturiermenge = null;

	/*
	 * Gangwagen des Artikels fuer Kommissionierlager
	 */
	@Column(name = "GANGWAGEN")
	private Long gangwagen = null;

	/*
	 * Grossstueckkennzeichen (J,N)
	 */
	@Column(name = "GROSSSTKKZ")
	private Long grossstueckkennzeichen = null;

	/*
	 * Dicke der Haengekonfektion in mm
	 */
	@Column(name = "HKDICKE_MM")
	private Long haengekonfektionDicke = null;

	/*
	 * KZ, ob Artikel lang oder kurz bei Haengekonfektion
	 */
	@Column(name = "HKLAENGEKZ")
	private Long haengekonfektionLaengeKz = null;

	/*
	 * Mindestbestand an Artikeln im Kommissionierlager
	 */
	@Column(name = "KOMLGBDMIN")
	private Long kommisionierungslagermindestbestand = null;

	/*
	 * Koordinate des Lagerortes 12-stellig (LLHHGGGFFEEP)
	 */
	@Column(name = "KOORD")
	private String koordinate = null;

	/*
	 * BUB im Lager; bei Meterware ist der BUB in cm (ab 01.03.2007)
	 */
	@Column(name = "LGBUB")
	private Long lagerBUB = null;

	/*
	 * Lagerbestand des Artikels im Kommissionierlager
	 */
	@Column(name = "LGKOMLAB")
	private Long lagerbestandKommisionierlager = null;

	/*
	 * Lagerbestand des Artikels im MAKL (=Kommissionierlager Halle 9)
	 */
	@Column(name = "LGKOMLAB_MAKL")
	private Long lagerbestandKommisionierlagerMAKL = null;

	/*
	 * Lagerbestand des Artikels im Kommissionierlager nach dem Nachschub
	 */
	@Column(name = "LGKOMLAB_NACHNACHSCHUB")
	private Long lagerbestandKommisionierlagerNachschub = null;

	/*
	 * LAB im Lager (lagerbestand gesamt)
	 */
	@Column(name = "LGLAB")
	private Long lagerbestand = null;

	/*
	 * LIB im Lager; bei Meterware ist der LIB in cm (ab 01.03.2007)
	 */
	@Column(name = "LGLIB")
	private Long lagerLIB = null;

	@Column(name = "LIBDIFKZ")
	private Long libdifkz = null;

	/*
	 * Kennzeichen, ob der Artikel (auch groessenabhaengig) nicht fuer den
	 * Sorter geeignet ist (0=geeignet, 1=ungeeignet)
	 */
	@Column(name = "NSFKZ")
	private Long nichtsortergeeignetKz = null;

	/*
	 * KZ, ob es sich um einen sog. Rennerartikel handelt
	 */
	@Column(name = "UMSCHLAGKZ")
	private Long umschlagKz = null;

	/*
	 * Benuzterkennung
	 */
	@Column(name = "USERNR")
	private Long usernummer = null;

	/*
	 * Gueltigkeitsdatum (Beginn) des Datensatzes
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "VONDAT")
	private Date vonDatum = null;

	/*
	 * Warentyp des Artikels
	 */
	@Column(name = "WATYP")
	private Long warentyp = null;

	public LagerverwaltungGroessenArtikelstamm() {
	}

	public Date getAenderungsdatum() {
		return aenderungsdatum;
	}

	public void setAenderungsdatum(Date aenderungsdatum) {
		this.aenderungsdatum = aenderungsdatum;
	}

	public Benutzer getBenutzer() {
		return benutzer;
	}

	public void setBenutzer(Benutzer benutzer) {
		this.benutzer = benutzer;
	}

	public Date getFakturierungsdatum() {
		return fakturierungsdatum;
	}

	public void setFakturierungsdatum(Date fakturierungsdatum) {
		this.fakturierungsdatum = fakturierungsdatum;
	}

	public Long getFakturierfaehigKz() {
		return fakturierfaehigKz;
	}

	public void setFakturierfaehigKz(Long fakturierfaehigKz) {
		this.fakturierfaehigKz = fakturierfaehigKz;
	}

	public Long getFakturiermenge() {
		return fakturiermenge;
	}

	public void setFakturiermenge(Long fakturiermenge) {
		this.fakturiermenge = fakturiermenge;
	}

	public Long getGangwagen() {
		return gangwagen;
	}

	public void setGangwagen(Long gangwagen) {
		this.gangwagen = gangwagen;
	}

	public Long getGrossstueckkennzeichen() {
		return grossstueckkennzeichen;
	}

	public void setGrossstueckkennzeichen(Long grossstueckkennzeichen) {
		this.grossstueckkennzeichen = grossstueckkennzeichen;
	}

	public Long getHaengekonfektionDicke() {
		return haengekonfektionDicke;
	}

	public void setHaengekonfektionDicke(Long haengekonfektionDicke) {
		this.haengekonfektionDicke = haengekonfektionDicke;
	}

	public Long getHaengekonfektionLaengeKz() {
		return haengekonfektionLaengeKz;
	}

	public void setHaengekonfektionLaengeKz(Long haengekonfektionLaengeKz) {
		this.haengekonfektionLaengeKz = haengekonfektionLaengeKz;
	}

	public Long getKommisionierungslagermindestbestand() {
		return kommisionierungslagermindestbestand;
	}

	public void setKommisionierungslagermindestbestand(
			Long kommisionierungslagermindestbestand) {
		this.kommisionierungslagermindestbestand = kommisionierungslagermindestbestand;
	}

	public String getKoordinate() {
		return koordinate;
	}

	public void setKoordinate(String koordinate) {
		this.koordinate = koordinate;
	}

	public Long getLagerBUB() {
		return lagerBUB;
	}

	public void setLagerBUB(Long lagerBUB) {
		this.lagerBUB = lagerBUB;
	}

	public Long getLagerbestandKommisionierlager() {
		return lagerbestandKommisionierlager;
	}

	public void setLagerbestandKommisionierlager(
			Long lagerbestandKommisionierlager) {
		this.lagerbestandKommisionierlager = lagerbestandKommisionierlager;
	}

	public Long getLagerbestandKommisionierlagerMAKL() {
		return lagerbestandKommisionierlagerMAKL;
	}

	public void setLagerbestandKommisionierlagerMAKL(
			Long lagerbestandKommisionierlagerMAKL) {
		this.lagerbestandKommisionierlagerMAKL = lagerbestandKommisionierlagerMAKL;
	}

	public Long getLagerbestandKommisionierlagerNachschub() {
		return lagerbestandKommisionierlagerNachschub;
	}

	public void setLagerbestandKommisionierlagerNachschub(
			Long lagerbestandKommisionierlagerNachschub) {
		this.lagerbestandKommisionierlagerNachschub = lagerbestandKommisionierlagerNachschub;
	}

	public Long getLagerbestand() {
		return lagerbestand;
	}

	public void setLagerbestand(Long lagerbestand) {
		this.lagerbestand = lagerbestand;
	}

	public Long getLagerLIB() {
		return lagerLIB;
	}

	public void setLagerLIB(Long lagerLIB) {
		this.lagerLIB = lagerLIB;
	}

	public Long getLibdifkz() {
		return libdifkz;
	}

	public void setLibdifkz(Long libdifkz) {
		this.libdifkz = libdifkz;
	}

	public Long getNichtsortergeeignetKz() {
		return nichtsortergeeignetKz;
	}

	public void setNichtsortergeeignetKz(Long nichtsortergeeignetKz) {
		this.nichtsortergeeignetKz = nichtsortergeeignetKz;
	}

	public Long getUmschlagKz() {
		return umschlagKz;
	}

	public void setUmschlagKz(Long umschlagKz) {
		this.umschlagKz = umschlagKz;
	}

	public Long getUsernummer() {
		return usernummer;
	}

	public void setUsernummer(Long usernummer) {
		this.usernummer = usernummer;
	}

	public Date getVonDatum() {
		return vonDatum;
	}

	public void setVonDatum(Date vonDatum) {
		this.vonDatum = vonDatum;
	}

	public Long getWarentyp() {
		return warentyp;
	}

	public void setWarentyp(Long warentyp) {
		this.warentyp = warentyp;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}

package eu.wittgruppe.dias.util.printer;

import org.apache.commons.lang.StringUtils;
import witt.josef.printer.valentin.Etikett;
import witt.josef.printer.valentin.PrinterConstants;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;


/**
 * Etikettenrenderer der die Etikettrohdaten maskiert und für
 * den Druck auf den Valentindrucker vorbereitet
 * @author Mather
 * @version 1.0
 */
public class ValentinLagerplatzEtikettRenderer implements ValentinEtikettRenderer {

    @Override
    public Collection<String> addMask( Etikett etikett ) {
        
        ValentinLagerplatzEtikett vetikett = ( ValentinLagerplatzEtikett )etikett;
        
        Collection colFields = new ArrayList(7);
        int feldNr = 0;
        
        // 1 - Artbez
        feldNr++;
        colFields.add(PrinterConstants.SOH + "AM[" + feldNr + "]600;8400;0;1;0;02;2;2;30" +
                      PrinterConstants.ETB + PrinterConstants.SOH + "BM[" + feldNr + "]" + 
                      vetikett.getArtikelBezeichnung() + PrinterConstants.ETB);
        // 2 - Farbe
        feldNr++;
        colFields.add(PrinterConstants.SOH + "AM[" + feldNr + "]950;8400;0;1;0;05;1;1;10" + 
                      PrinterConstants.ETB + PrinterConstants.SOH + "BM[" + feldNr + "]" + 
                      vetikett.getArtikelFarbe() + PrinterConstants.ETB);
        // 3 - Artikelnr
        feldNr++;
        colFields.add(PrinterConstants.SOH + "AM[" + feldNr + "]1500;8400;0;1;0;02;2;2;50" + 
                      PrinterConstants.ETB + PrinterConstants.SOH + "BM[" + feldNr + "]" + 
                      vetikett.getArtikelNummer() + PrinterConstants.ETB);       
        // 4 - ArtikelGr
        feldNr++;
        colFields.add(PrinterConstants.SOH + "AM[" + feldNr + "]1500;6400;0;1;0;02;2;2;50" + 
                      PrinterConstants.ETB + PrinterConstants.SOH + "BM[" + feldNr + "]" + 
                      StringUtils.leftPad(vetikett.getArtikelGroesse(), 3, '0')  + PrinterConstants.ETB);        
        // 5 - Sortkz
        feldNr++;
        colFields.add(PrinterConstants.SOH + "AM[" + feldNr + "]1500;5300;0;1;0;02;2;2;50" + 
                      PrinterConstants.ETB + PrinterConstants.SOH + "BM[" + feldNr + "]" + 
                      vetikett.getSortKennzeichen() + PrinterConstants.ETB);
        // 6 - Lagerplatz
        feldNr++;
        colFields.add(PrinterConstants.SOH + "AM[" + feldNr + "]1750;8400;0;4;0;1;200;200;10" + 
                      PrinterConstants.ETB + PrinterConstants.SOH + "BM[" + feldNr + "]" + 
                      vetikett.getFormattedLagerKoord() + PrinterConstants.ETB);
        // 7 - Menge in cm
        feldNr++;
        colFields.add(PrinterConstants.SOH + "AM[" + feldNr + "]1750;5300;0;4;0;1;200;200;10" + 
                      PrinterConstants.ETB + PrinterConstants.SOH + "BM[" + feldNr + "]" + 
                      "cm: "+ StringUtils.leftPad(vetikett.getMengeCm().toString(), 4, '0') + PrinterConstants.ETB);     
    
        // 8 - EAN-CODE, CRS-KZ, ARtikelnummer, ArtikelGr, Sortkz
        feldNr++;
        colFields.add(PrinterConstants.SOH + "AM[" + feldNr + "]4400;8200;0;31;0;2500;9;3;0;0" + 
                      PrinterConstants.ETB + PrinterConstants.SOH + "BM[" + feldNr + "]" + 
                      "00" + // CRskz 
                      vetikett.getArtikelNummer() +  
                      StringUtils.leftPad(vetikett.getArtikelGroesse(), 3, '0') + 
                      vetikett.getSortKennzeichen() + PrinterConstants.ETB);
        
        Date today = new Date();
        SimpleDateFormat sdfmt = new SimpleDateFormat("ddMMHHmm");
        // 9 - Datum Uhrzeit
        feldNr++;
        colFields.add(PrinterConstants.SOH + "AM[" + feldNr + "]4300;4000;0;4;1;1;300;150;1" +
                      PrinterConstants.ETB + PrinterConstants.SOH + "BM[" + feldNr + "]" +  
                      sdfmt.format(today) + PrinterConstants.ETB);
        // 10 - Bedienernr
        feldNr++;
        colFields.add(PrinterConstants.SOH + "AM[" + feldNr + "]3200;4000;0;4;1;1;300;150;1" +
                      PrinterConstants.ETB + PrinterConstants.SOH + "BM[" + feldNr + "]" +  
                      (vetikett.getBedienerNummer() == null ? "999" : vetikett.getBedienerNummer().toString()) + 
                      PrinterConstants.ETB);        
        
        // 11 - Firmenkürzel
        feldNr++;
        colFields.add(PrinterConstants.SOH + "AM[" + feldNr + "]2300;4000;0;4;1;1;300;150;1" +
                      PrinterConstants.ETB + PrinterConstants.SOH + "BM[" + feldNr + "]" +  
                      vetikett.getBestFirmKzBez() + PrinterConstants.ETB);       
//          
        
        return colFields;   
    }

    @Override
    public long getEtikettLaengeInMillimeter() {
        // TODO Auto-generated method stub
        return 2680;
    }

    @Override
    public long getSchlitzabstandInMillimeter() {
        // TODO Auto-generated method stub
        return 400;
    }



}

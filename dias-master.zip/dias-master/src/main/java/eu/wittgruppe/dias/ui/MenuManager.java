/*
 * Created on 17.11.2005
 */
package eu.wittgruppe.dias.ui;

import javax.swing.*;
import java.util.Collection;
import java.util.Vector;

public class MenuManager {
    private Vector menuItems = new Vector();
    
    public MenuManager() {}
    
    public void add( JMenu menu ) {
        menuItems.add( menu );
    }
    
    public void add( JMenu menu, int index ) {
        menuItems.add( index, menu );
    }
    
    public boolean removeMenuItem( JMenu menu ) {
        return menuItems.remove( menu );
    }
    
    public void removeMenuItem( int index ) {
        menuItems.remove( index );
    }
    
    public JMenu getMenuItem( int index ) {
        return ( JMenu )menuItems.get( index );
    }
    
    public Collection getMenuItems() {
        return menuItems;
    }
    
    public int getSize() {
        return menuItems.size();
    }
}

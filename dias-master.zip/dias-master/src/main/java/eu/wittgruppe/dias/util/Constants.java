package eu.wittgruppe.dias.util;

public class Constants {

	public static final long FARBEN_MERKMALKLNR = 5;
	// über wieviele Saisons wird selektiert
	public static final int SAISON_ZEITRAUM = 2;
	// wieviel Artikel werden pro Seite angezeigt
	public static final int PAGE_SIZE = 12;
	// wieviel Kunden sollen als Ergebnismenge gematcht werden
	public static final int MATCH_SIZE = 40;
	public static final String NDS_PORDUCT_NAME = "dias";
	
	// Keys für Zugriff auf Parameterverwaltung
	public static final String PARAM_PROGNAME = "DIAS";
	public static final String PARAM_PARAMGRP = "TISCHDRUCKER";
	public static final String PARAM_BITRATE = "BITRATE";
	public static final String PARAM_DATABITS = "DATABITS";
	public static final String PARAM_STOPBITS = "STOPBITS";
	public static final String PARAM_PARITAET = "PARITAET";
	public static final String PARAM_PORT = "PORT";
	public static final String PARAM_MODELL = "MODELL";
	// Kennzeichen für Dias_statistik Eintrag
	public static final int STATISTIK_ARTIKEL_SEARCH = 1;
	public static final int STATISTIK_ARTIKEL_CRS_SEARCH = 2;
	public static final int STATISTIK_RECHNUNG_SEARCH = 3;
}

package eu.wittgruppe.dias.util;

import org.apache.commons.lang.StringUtils;

/**
 * Hilfsklasse zur Stringmanipulation.
 * <br><b>Man sollte f&uuml;r Stringmanipulationen und Textverarbeitung die Klassen
 * aus dem jakarta Commons Lang Paket benutzen.</b>
 * @version 0.1 09/03/02
 * @author ulrkle
 */
public final class StringUtilities {

     private StringUtilities() {}

    /**
     * &uuml;berpr&uuml;fen, ob String eine Zahl ist
     * @param string der String der &uuml;berpr&uuml;ft werden soll
     * @return true wenn String eine Zahl ist, ansonsten false
     */
    public static boolean isNumber( String string ) {
        return StringUtils.isNumeric( string );
    }

    /**
     * Teile eines Strings in einem String ersetzen
     * @param str der String in dem ersetzt werden soll
     * @param pattern was soll ersetzt werden
     * @param replace durch was soll ersetzt werden
     * @return ersetzter String
     */
    public static String replace( String str, String pattern, String replace ) {
        return StringUtils.replace( str, pattern, replace );
    }

    /**
     * String linksb&uuml;ndig mit Leerzeichen auff&uuml;llen
     * @param str String der aufgef&uuml;llt werden soll
     * @param length auf welche L&auml;nge soll aufgef&uuml;llt werden
     * @return String
     */
    public static String leftPad( String str, int length ) {
        return leftPad( str, length, " " );
    }

    public static String leftPadNVL( String str, int length ) {
        if( str == null ) {
            return leftPad( "", length );
        } else {
            return leftPad( str, length );
        }
    }

    public static String leftPadNVL( String str, int length, String toFillWith ) {
        if( str == null ) {
            return leftPad( "", length, toFillWith );
        } else {
            return leftPad( str, length, toFillWith );
        }
    }

    /**
     * String links mit einem anderen String auff&uuml;llen
     * @param str String der aufgef&uuml;llt werden soll
     * @param length auf welche L&auml;nge soll aufgef&uuml;llt werden
     * @param toFillWith aufzuf&uuml;llende Zeichen
     * @return String
     */
    public static String leftPad( String str, int length, String toFillWith ) {
        if( str == null || toFillWith == null ) {
            return null;
        }

        //erst mal schauen, ob die Laenge kleiner oder gleich der Laenge
        //des Strings str ist
        String temp = checkPaddingLength( str, length );
        return StringUtils.leftPad( temp, length, toFillWith );
    }

    /**
     * genauso wie rightPad( String, int ) nur der Unterschied, wenn
     * str null ist wie nicht null zur&uuml;ckgegeben, sondern ein
     * entsprechend langer Leerstring
     * @param str String der aufgef&uuml;llt werden soll
     * @param length auf welche L&auml;nge soll aufgef&uuml;llt werden
     * @return String
     */
    public static String rightPadNVL( String str, int length ) {
        if( str == null ) {
            return rightPad( "", length );
        } else {
            return rightPad( str, length );
        }
    }

    /**
     * String rechtsb&uuml;ndig mit Leerzichen auf L&auml;nge auff&uuml;llen
     * @param str String der aufgef&uuml;llt werden soll
     * @param length auf welche L&auml;nge soll aufgef&uuml;llt werden
     * @return String
     */
    public static String rightPad( String str, int length ) {
        return rightPad( str, length, " " );
    }

    public static String rightPadNVL( String str, int length, String toFillWith ) {
        if( str == null ) {
            return rightPad( "", length, toFillWith );
        } else {
            return rightPad( str, length, toFillWith );
        }
    }

    /**
     * String rechts mit einem anderen String auff&uuml;llen
     * @param str String der aufgef&uuml;llt werden soll
     * @param length auf welche L&auml;nge soll aufgef&uuml;llt werden
     * @param toFillWith aufzuf&uuml;llende Zeichen
     * @return String
     */
    public static String rightPad( String str, int length, String toFillWith ) {
        if( str == null || toFillWith == null ) {
            return null;
        }
        //erst mal schauen, ob die Laenge kleiner oder gleich der Laenge
        //des Strings str ist
        String temp = checkPaddingLength( str, length );

        return StringUtils.rightPad( temp, length, toFillWith );
    }

    /**
     * Methode u&uuml;berpr&uuml;ft ob die &uuml;bergebene L&auml;nge
     * gleich, kleiner oder negativ ist
     * <br>
     * wenn die L&auml;nge kleiner als die La&uml;nge des Strings ist
     * wird der String entsprechend auf die L&auml;nge gek&uuml;rzt
     * @param str String der mit der L&auml;nge &uuml;berpr&uuml;ft werden soll
     * @param length L&auml;nge
     * @return String oder null wenn keine &Auml;ndernug vorgenommen worden ist
     */
    private static String checkPaddingLength( String str, int length ) {
        if( str.length() == length ) {
            return str;
        } else if( length < 0 ) {
            return str;
        //wenn Laenge kleiner ist als der String dann den String auf
        //die entsprechende Laenge kuerzen
        } else if( length < str.length() ) {
            return str.substring( 0, length );
        //es ist nichts zum Aendern gewesen
        } else {
             return str;
        }
    }

    /**
     * entfernt Leerzeichen am linken Rand des Strings
     * @param string String an dessen linken Rand die Leerzeichen entfernt werden
     *               soll
     * @return den linksseitig getrimten String
     * @see java.lang.String#trim()
     */
    public static String leftTrim( String string ) {
        return StringUtils.stripStart( string, null );
    }

    public static String leftTrimNVL( String string ) {
        if( string == null ) {
            return "";
        } else {
            return leftTrim( string );
        }
    }

    /**
     * entfernt Leerzeichen am rechten Rand des Strings
     * @param string String an dessen rechten Rand die Leerzeichen entfernt werden
     *               soll
     * @return den rechtsseitig getrimten String
     * @see java.lang.String#trim()
     */
    public static String rightTrim( String string ) {
        return StringUtils.stripEnd( string, null );
    }

    public static String rightTrimNVL( String string ) {
        if( string == null ) {
            return "";
        } else {
            return rightTrim( string );
        }
    }

    /**
    * Spreizt die Umlaute für den übergebenen String <i>(ä,ö,ü,ß)</i>
    * Der Ergebnisstring wird pro Umlaut um ein Zeichen größer als vorher.
    * @param  stringToSpread  der zu spreizende String
    * @return String  den gespreizten String
    */
    public static String spreadCharacters(String stringToSpread)
    {
      char[] zeichen = stringToSpread.toCharArray();

      String erg = "";
      String replacer = "";
      boolean isOnlyBig = true;
      int anzahl = zeichen.length;
      for(int i=0; i<anzahl;++i)
      {
        if(Character.isLowerCase(zeichen[i]))
          isOnlyBig = false;

        switch(zeichen[i]){
		case 0xe4:
			replacer = "ae";
			break;
		case 0xf6:
			replacer = "oe";
			break;
		case 0xfc:
			replacer = "ue";
			break;
		case 0xc4:
			replacer = "Ae";
			break;
		case 0xd6:
			replacer = "Oe";
			break;
		case 0xdc:
			replacer = "Ue";
			break;
          default:
            replacer = stringToSpread.substring(i,i+1);   //Ein Zeichen schreiben
        }
        erg += replacer;
      }
      if(isOnlyBig)
        erg = erg.toUpperCase();

      return erg;
    }
}

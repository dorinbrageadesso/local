package eu.wittgruppe.dias.bean;

import java.util.Hashtable;

public class GroupableKunderechnungsposition extends KunderechnungspositionBean {

	private static Hashtable index = new Hashtable();

	private static int group = 0;

	private KunderechnungspositionBean pos = null;

	public GroupableKunderechnungsposition(KunderechnungspositionBean pos) {
		this.pos = pos;

		String id = this.getPos().getKundenrechnungskopfBean().getId();
		Integer i = (Integer) index.get(id);
		if (i == null) {
			index.put(id, new Integer(group++));
		}
	}

	public int getGroup() {
		String id = this.getPos().getKundenrechnungskopfBean().getId();
		Integer i = (Integer) index.get(id);
		return i.intValue();
	}

	public KunderechnungspositionBean getPos() {
		return pos;
	}
}
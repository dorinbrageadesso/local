package eu.wittgruppe.dias.domain;

import org.apache.commons.lang.builder.ToStringBuilder;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

import static jakarta.persistence.FetchType.LAZY;

@Entity(name = "Kunde")
@Table(name = "kunde")
public class Kunde implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "ANLAUFDAT")
    private Date anlaufDatum = null;

    @Column(name = "ANLAUFSAISON")
    private Long anlaufSaison = null;

    @Column(name = "ANLMAPPENNR")
    private Long anlageMappenNummer = null;

    @Column(name = "BUFUEEINH")
    private Long buchfuehrendeEinheit = null;

    @Column(name = "GUTSCHEINKZ")
    private String gutscheinKennzeichen = null;

    @Id
    private final String id = null;

    @Column(name = "IWL")
    private Long interessentenWerbelistenSchluessel = null;

    @Column(name = "KATERSTVERSKZ")
    private String katalogErstversandKennzeichen = null;

    @Column(name = "KATLIMIT")
    private Long katalogLimit = null;

    @Column(name = "KATNACHVERS")
    private Long katalogNachversand = null;

    @Column(name = "KDNR")
    private Long kundenNummer = null;

    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "KUNDENFIRMAID")
    private Kundenfirma kundenfirma;

    @Column(name = "LETZTAENDDAT")
    private Date letztesAenderungsdatum = null;

    @Column(name = "LETZTAENDDATHOST")
    private Date letztesAenderungsdatumHost = null;

    @Column(name = "LETZTAKTDATHOST")
    private Date letztesAktualisierungsdatumHost = null;

    @Column(name = "LETZTTRANSFERDAT")
    private Date letztesTransferdatum = null;

    @Column(name = "LETZTAENDDATMAHNEB")
    @Temporal(TemporalType.TIMESTAMP)
    private Date letztesMahnebeneAenderungsdatum = null;

    @Column(name = "LETZTAENDDATMAHNSTRANG")
    @Temporal(TemporalType.TIMESTAMP)
    private Date letztesMahnstrangAenderungsdatum = null;

    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "MEBBENUTZERID")
    private Benutzer mahnebeneBenutzer;

    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "MSBENUTZERID")
    private Benutzer mahnstrangBenutzer;

    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "PERSONID")
    private Person person;

    @Column(name = "PWD")
    private String passwort = null;

    @Column(name = "RATEKFRKZ")
    private String ratenKaeuferKennzeichen = null;

    @Column(name = "RGKFUMSTDAT")
    private Date rechnungsKaufUmstellungsDatum = null;

    @Column(name = "TESTGRP")
    private String testGruppe = null;

    @Column(name = "TRANSFERKZ")
    private Long transferKennzeichen = null;

    @Column(name = "VALKZ")
    private Long valutaKennzeichen = null;

    @Column(name = "VERWKDNR")
    private Long verweisKundenNummer = null;

    @Column(name = "VTINFOKDGRP")
    private Long vtInfoKundenGruppe = null;

    @Column(name = "WKZ")
    private Long werbeKennziffer = null;

    public Kunde() {}

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString( this );
    }

    public Date getAnlaufDatum() {
        return anlaufDatum;
    }

    public void setAnlaufDatum( Date anlaufDatum ) {
        this.anlaufDatum = anlaufDatum;
    }

    public Long getAnlaufSaison() {
        return anlaufSaison;
    }

    public void setAnlaufSaison( Long anlaufSaison ) {
        this.anlaufSaison = anlaufSaison;
    }

    public Long getAnlageMappenNummer() {
        return anlageMappenNummer;
    }

    public void setAnlageMappenNummer( Long anlageMappenNummer ) {
        this.anlageMappenNummer = anlageMappenNummer;
    }

    public Long getBuchfuehrendeEinheit() {
        return buchfuehrendeEinheit;
    }

    public void setBuchfuehrendeEinheit( Long buchfuehrendeEinheit ) {
        this.buchfuehrendeEinheit = buchfuehrendeEinheit;
    }

    public String getGutscheinKennzeichen() {
        return gutscheinKennzeichen;
    }

    public void setGutscheinKennzeichen( String gutscheinKennzeichen ) {
        this.gutscheinKennzeichen = gutscheinKennzeichen;
    }

    public String getId() {
        return id;
    }

    public Long getInteressentenWerbelistenSchluessel() {
        return interessentenWerbelistenSchluessel;
    }

    public void setInteressentenWerbelistenSchluessel( Long interessentenWerbelistenSchluessel ) {
        this.interessentenWerbelistenSchluessel = interessentenWerbelistenSchluessel;
    }

    public String getKatalogErstversandKennzeichen() {
        return katalogErstversandKennzeichen;
    }

    public void setKatalogErstversandKennzeichen( String katalogErstversandKennzeichen ) {
        this.katalogErstversandKennzeichen = katalogErstversandKennzeichen;
    }

    public Long getKatalogLimit() {
        return katalogLimit;
    }

    public void setKatalogLimit( Long katalogLimit ) {
        this.katalogLimit = katalogLimit;
    }

    public Long getKatalogNachversand() {
        return katalogNachversand;
    }

    public void setKatalogNachversand( Long katalogNachversand ) {
        this.katalogNachversand = katalogNachversand;
    }

    public Long getKundenNummer() {
        return kundenNummer;
    }

    public void setKundenNummer( Long kundenNummer ) {
        this.kundenNummer = kundenNummer;
    }

    public Kundenfirma getKundenfirma() {
        return kundenfirma;
    }

    public void setKundenfirma( Kundenfirma kundenfirma ) {
        this.kundenfirma = kundenfirma;
    }

    public Date getLetztesAenderungsdatum() {
        return letztesAenderungsdatum;
    }

    public void setLetztesAenderungsdatum( Date letztesAenderungsdatum ) {
        this.letztesAenderungsdatum = letztesAenderungsdatum;
    }

    public Date getLetztesAenderungsdatumHost() {
        return letztesAenderungsdatumHost;
    }

    public void setLetztesAenderungsdatumHost( Date letztesAenderungsdatumHost ) {
        this.letztesAenderungsdatumHost = letztesAenderungsdatumHost;
    }

    public Date getLetztesAktualisierungsdatumHost() {
        return letztesAktualisierungsdatumHost;
    }

    public void setLetztesAktualisierungsdatumHost( Date letztesAktualisierungsdatumHost ) {
        this.letztesAktualisierungsdatumHost = letztesAktualisierungsdatumHost;
    }

    public Date getLetztesTransferdatum() {
        return letztesTransferdatum;
    }

    public void setLetztesTransferdatum( Date letztesTransferdatum ) {
        this.letztesTransferdatum = letztesTransferdatum;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson( Person person ) {
        this.person = person;
    }

    public String getPasswort() {
        return passwort;
    }

    public void setPasswort( String passwort ) {
        this.passwort = passwort;
    }

    public String getRatenKaeuferKennzeichen() {
        return ratenKaeuferKennzeichen;
    }

    public void setRatenKaeuferKennzeichen( String ratenKaeuferKennzeichen ) {
        this.ratenKaeuferKennzeichen = ratenKaeuferKennzeichen;
    }

    public Date getRechnungsKaufUmstellungsDatum() {
        return rechnungsKaufUmstellungsDatum;
    }

    public void setRechnungsKaufUmstellungsDatum( Date rechnungsKaufUmstellungsDatum ) {
        this.rechnungsKaufUmstellungsDatum = rechnungsKaufUmstellungsDatum;
    }

    public String getTestGruppe() {
        return testGruppe;
    }

    public void setTestGruppe( String testGruppe ) {
        this.testGruppe = testGruppe;
    }

    public Long getTransferKennzeichen() {
        return transferKennzeichen;
    }

    public void setTransferKennzeichen( Long transferKennzeichen ) {
        this.transferKennzeichen = transferKennzeichen;
    }

    public Long getValutaKennzeichen() {
        return valutaKennzeichen;
    }

    public void setValutaKennzeichen( Long valutaKennzeichen ) {
        this.valutaKennzeichen = valutaKennzeichen;
    }

    public Long getVerweisKundenNummer() {
        return verweisKundenNummer;
    }

    public void setVerweisKundenNummer( Long verweisKundenNummer ) {
        this.verweisKundenNummer = verweisKundenNummer;
    }

    public Long getVtInfoKundenGruppe() {
        return vtInfoKundenGruppe;
    }

    public void setVtInfoKundenGruppe( Long vtInfoKundenGruppe ) {
        this.vtInfoKundenGruppe = vtInfoKundenGruppe;
    }

    public Long getWerbeKennziffer() {
        return werbeKennziffer;
    }

    public void setWerbeKennziffer( Long werbeKennziffer ) {
        this.werbeKennziffer = werbeKennziffer;
    }

    public Date getLetztesMahnebeneAenderungsdatum() {
        return letztesMahnebeneAenderungsdatum;
    }

    public void setLetztesMahnebeneAenderungsdatum( Date letztesMahnebeneAenderungsdatum ) {
        this.letztesMahnebeneAenderungsdatum = letztesMahnebeneAenderungsdatum;
    }

    public Date getLetztesMahnstrangAenderungsdatum() {
        return letztesMahnstrangAenderungsdatum;
    }

    public void setLetztesMahnstrangAenderungsdatum( Date letztesMahnstrangAenderungsdatum ) {
        this.letztesMahnstrangAenderungsdatum = letztesMahnstrangAenderungsdatum;
    }

    public Benutzer getMahnebeneBenutzer() {
        return mahnebeneBenutzer;
    }

    public void setMahnebeneBenutzer( Benutzer mahnebeneBenutzer ) {
        this.mahnebeneBenutzer = mahnebeneBenutzer;
    }

    public Benutzer getMahnstrangBenutzer() {
        return mahnstrangBenutzer;
    }

    public void setMahnstrangBenutzer( Benutzer mahnstrangBenutzer ) {
        this.mahnstrangBenutzer = mahnstrangBenutzer;
    }
}

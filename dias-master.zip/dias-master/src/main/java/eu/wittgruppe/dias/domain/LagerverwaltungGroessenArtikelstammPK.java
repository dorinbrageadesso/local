package eu.wittgruppe.dias.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class LagerverwaltungGroessenArtikelstammPK implements Serializable {

	/*
	 * Artikelgroese
	 */
	@Column(name = "ARTGR")
	private String artikelgroesse = null;

	/*
	 * 6-stellige Witt-Artikelnummer
	 */
	@Column(name = "ARTNR6")
	private Long artikelnummer6 = null;

	// /*
	// * Saisonkennzeichen
	// */
	// @ManyToOne(fetch = FetchType.LAZY)
	// @JoinColumn(name = "saison", referencedColumnName = "saison")
	//   
    @Column(name = "saison")
	private Saison saison = null;

	public LagerverwaltungGroessenArtikelstammPK() {
	}

	public LagerverwaltungGroessenArtikelstammPK(String artikelgroesse,
			Long artikelnummer6, Saison saison) {
		super();
		this.artikelgroesse = artikelgroesse;
		this.artikelnummer6 = artikelnummer6;
		this.saison = saison;
	}

	public String getArtikelgroesse() {
		return artikelgroesse;
	}

	public void setArtikelgroesse(String artikelgroesse) {
		this.artikelgroesse = artikelgroesse;
	}

	public Long getArtikelnummer6() {
		return artikelnummer6;
	}

	public void setArtikelnummer6(Long artikelnummer6) {
		this.artikelnummer6 = artikelnummer6;
	}

	public Saison getSaison() {
		return saison;
	}

	public void setSaison(Saison saison) {
		this.saison = saison;
	}
}

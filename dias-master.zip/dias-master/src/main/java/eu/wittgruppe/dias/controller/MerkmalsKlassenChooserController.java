package eu.wittgruppe.dias.controller;

import eu.wittgruppe.dias.domain.Marktkennzeichen;
import eu.wittgruppe.dias.domain.MerkmalklasseDiamant;
import eu.wittgruppe.dias.service.DiasService;
import eu.wittgruppe.dias.ui.MerkmalsKlassenChooser;
import eu.wittgruppe.dias.util.TreeNodeBean;
import eu.wittgruppe.dias.util.TreeUtils;
import lombok.extern.slf4j.Slf4j;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;

@Slf4j
public class MerkmalsKlassenChooserController {

	MerkmalsKlassenChooser chooser = null;
	ArtikelSearchController parentController = null;

	public MerkmalsKlassenChooserController(
			ArtikelSearchController parentController) {
		this.parentController = parentController;
		chooser = new MerkmalsKlassenChooser(this);
		this.expandTree();
	}

    public DiasService getDiasService() {
        return parentController.getDiasService();
    }


	public ArtikelSearchController getParentController() {
		return parentController;
	}

	public void setParentController(ArtikelSearchController parentController) {
		this.parentController = parentController;
	}

	public void showDialog() {
		chooser.setVisible(true);

	}

	public DefaultMutableTreeNode createTreeNodes() {

		DefaultMutableTreeNode root = new DefaultMutableTreeNode("Klassen");
		Collection marktkzCol = null;
		Hashtable table = new Hashtable();

        marktkzCol = getDiasService().sucheAllMarktKennzeichen();
		// Parent ist immer die Merkmalsklasse
		DefaultMutableTreeNode parent = null;

		for (Iterator iter = marktkzCol.iterator(); iter.hasNext();) {

			Marktkennzeichen marktKz = (Marktkennzeichen) iter.next();
			// zu welcher Merkmalsklasse gehört das Marktkennzeichen
			MerkmalklasseDiamant klasse = marktKz.getMerkmalklasseDiamant();

            if( klasse != null ) {

                // existiert schon ein Node schon zum Marktkennzeichen
                if( !table.containsKey( new Integer( klasse.hashCode() ) ) ) {

                    parent = new DefaultMutableTreeNode( new TreeNodeBean( klasse.getBezeichnung(), klasse ) );
                    root.add( parent );
                    table.put( new Integer( klasse.hashCode() ), parent );
                } else {
                    parent = ( DefaultMutableTreeNode )table.get( new Integer( klasse.hashCode() ) );
                }

                DefaultMutableTreeNode marktKzLeaf = new DefaultMutableTreeNode();
                marktKzLeaf.setUserObject( new TreeNodeBean( marktKz.getMarktKennzeichenBezeichnung(), marktKz ) );
                marktKzLeaf.setAllowsChildren( false );
                parent.add( marktKzLeaf );
            }
		}

		return root;
	}

	public TreeNodeBean getSelectTreeNodeBean() {

		TreeNodeBean nodeVO = null;
		TreePath path = chooser.getMerkmalsTree().getSelectionPath();

		if (path != null) {

			DefaultMutableTreeNode node = (DefaultMutableTreeNode) path
					.getLastPathComponent();

			if (!node.isRoot()) {
				nodeVO = (TreeNodeBean) node.getUserObject();
				chooser.dispose();
			} else {
				JOptionPane
						.showMessageDialog(
								chooser,
								"Keine gültige Klasse ausgewählt. Bitte eine auswählen!",
								"Klassenauswahl", JOptionPane.WARNING_MESSAGE);
			}
		} else {

			JOptionPane
					.showMessageDialog(
							chooser,
							"Keine Klasse ausgewählt. Bitte wählen Sie eine Klasse aus!",
							"Klassenauswahl", JOptionPane.WARNING_MESSAGE);

		}

		return nodeVO;
	}

	public void collapseTree() {
		TreeUtils.collapseWithoutRoot(chooser.getMerkmalsTree());
	}

	public void expandTree() {
		TreeUtils.expandAll(chooser.getMerkmalsTree());
	}
}

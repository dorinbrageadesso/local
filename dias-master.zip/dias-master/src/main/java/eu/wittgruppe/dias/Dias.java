package eu.wittgruppe.dias;

import eu.wittgruppe.dias.controller.MainWindowController;
import eu.wittgruppe.dias.util.Images;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import witt.josef.security.CredentialsDecryptor;
import witt.josef.uiswing.ui.ApplicationDetails;
import witt.josef.uiswing.ui.SplashScreen;
import witt.josef.uiswing.ui.UIUtils;
import witt.josef.util.EnvironmentUtils;

import java.awt.*;
import java.util.Locale;

@SpringBootApplication
@ComponentScan({"witt.josef.infrastructure", "witt.josef.benutzerverwaltung", "eu.wittgruppe"})
@Slf4j
@Data
public class Dias implements CommandLineRunner {
    private final Locale locale = Locale.getDefault();
    @Autowired
    private MainWindowController mainWindowController;

    static SplashScreen splash;

    private void initialize(SplashScreen splash) {
        mainWindowController.show(splash);
    }

    public Locale getActiveUserLocale() {
        return this.locale;
    }

    private static ApplicationDetails getApplicationDetails() {
        ApplicationDetails applicationDetails = new ApplicationDetails();
        applicationDetails = new ApplicationDetails();
        applicationDetails.setApplicationName( "DIAS" );
        applicationDetails.setLongDescription( "Digitale Artikelsuche" );
        applicationDetails.setShortDescription( "Digitale Artikelsuche" );
        applicationDetails.setSplash( Images.SPLASH_KLEIN );
        return applicationDetails;
    }

    public static void main( String[] args ) {
        EnvironmentUtils.redirectStreams( "dias" );
        UIUtils.setLookAndFeel();

        splash = new SplashScreen(getApplicationDetails());
        splash.setProgressBarUsed(true);
        splash.setProgressMaximum( 4 );
        splash.setBackground( Color.WHITE );
        splash.setVisible( true );
        splash.toFront();

        splash.setProgress( 1 );
        splash.setProgressText( "Lade Applikationsdetails" );

        CredentialsDecryptor.decryptCredentialProperties();

        SpringApplication.run(Dias.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        initialize(splash);
    }
}

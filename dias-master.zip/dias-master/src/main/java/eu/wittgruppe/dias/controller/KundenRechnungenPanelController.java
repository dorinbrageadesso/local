package eu.wittgruppe.dias.controller;

import eu.wittgruppe.dias.bean.GroupableKunderechnungsposition;
import eu.wittgruppe.dias.bean.KundenrechnungskopfBean;
import eu.wittgruppe.dias.bean.KunderechnungspositionBean;
import eu.wittgruppe.dias.bean.ReportBean;
import eu.wittgruppe.dias.domain.Kunde;
import eu.wittgruppe.dias.domain.Kundenfirma;
import eu.wittgruppe.dias.service.DiasService;
import eu.wittgruppe.dias.ui.KundenFirmaChooserDialog;
import eu.wittgruppe.dias.ui.KundenRechnungenPanel;
import eu.wittgruppe.dias.ui.UIUtils;
import eu.wittgruppe.dias.util.Constants;
import eu.wittgruppe.dias.util.Images;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.swing.JRViewer;
import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import witt.josef.infrastructure.Message;
import witt.josef.uiswing.ui.ErrorDialog;

import javax.swing.*;
import javax.swing.table.JTableHeader;
import java.awt.event.MouseListener;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Slf4j
public class KundenRechnungenPanelController {

    //RETAB-156 - Über ein Rolle wird geprüft, ob der Benutzer nur Rechnungen von CH oder alle sehen darf...
    private boolean onlyCH = false;

    private MainWindowController parentController = null;

    private KundenRechnungenPanel kundenRechnungenPanel = null;

    public DiasService getDiasService() {
        return parentController.getDiasService();
    }

    public KundenRechnungenPanelController( MainWindowController parentController, boolean onlyCH ) {
        super();
        this.parentController = parentController;
        this.kundenRechnungenPanel = new KundenRechnungenPanel( this );
        this.onlyCH = onlyCH;
    }

    public KundenRechnungenPanel getKundenRechnungenPanel() {
        return this.kundenRechnungenPanel;
    }

    public void sucheRechnungsPositionen( Long retschl ) {

        KundenrechnungskopfBean rechKopf = null;
        Kunde displayKunde = null;
        // Status zurücksetzen
        try {
            rechKopf = getDiasService().sucheRechnungsKopf( retschl, onlyCH );

            if( rechKopf != null ) {
                displayKunde = getDiasService().sucheKunden( rechKopf.getKundenfirma(), rechKopf.getKundennummer() );
                setKundenDetails( displayKunde );
                searchRechnungsPositionen( rechKopf );
            } else {
                JOptionPane.showMessageDialog( parentController.getMainWindow(), "Keine Rechnung gefunden!", "Suchen", JOptionPane.INFORMATION_MESSAGE );

                clearFrame();
            }

        } catch( Exception e ) {
            log.error( "Fehler beim Zugriff auf Applicationserver", e );
            // Beginn Einbau messageDialog, da new ErrorDialog nicht funktioniert!
            clearFrame();
            JOptionPane.showMessageDialog( parentController.getMainWindow(), "Applicationserver Zugriff" + e.getMessage(), "Suchen", JOptionPane.INFORMATION_MESSAGE );
            // Ende Einbau messageDialog, da new ErrorDialog nicht funktioniert!

            new ErrorDialog( parentController.getMainWindow(), "Applicationserver Zugriff", true, e, e.getMessage(), true ).show();
        }
    }

    public void sucheRechnungsPositionen( String kdfirmId, Long kdnr ) {

        Kundenfirma kundenFirma = null;
        Kunde displayKunde = null;

        try {

            displayKunde = searchKunde( kdfirmId, kdnr );

            // wenn Kundennr und Kundenfirma ermittelt werden konnten
            if( displayKunde != null ) {

                kundenFirma = displayKunde.getKundenfirma();

                setKundenDetails( displayKunde );
                searchRechnungsPositionen( kdnr, kundenFirma );
            }

        } catch( Exception e ) {
            log.error( "Fehler beim Zugriff auf Applicationserver", e );
            // Beginn Einbau messageDialog, da new ErrorDialog nicht funktioniert!
            clearFrame();
            JOptionPane.showMessageDialog( parentController.getMainWindow(), "Applicationserver Zugriff" + e.getMessage(), "Suchen", JOptionPane.INFORMATION_MESSAGE );
            // Ende Einbau messageDialog, da new ErrorDialog nicht funktioniert!

            new ErrorDialog( parentController.getMainWindow(), "Applicationserver Zugriff", true, e, e.getMessage(), true ).show();
        }
    }

    private Kunde searchKunde( String kdfirmId, Long kdnr ){

        Collection kunden = null;
        Vector kundenFirmen = new Vector();
        Kundenfirma kundenFirma = null;
        Kunde displayKunde = null;
        // Status zurücksetzen

        kunden = getDiasService().sucheKunden( kdnr, onlyCH );

        if( kunden.size() == 0 ) {
            log.debug( "Kunde nicht gefunden -> " + kdnr.toString() );
            parentController.getMainWindow().showMessageDialog( "Kunde wurde nicht gefunden!", "Kundensuche" );
            clearFrame();
        }
        // wenn mehrere Kunden gefunden, und kundenfirma vorgegeben
        else if( kunden.size() > 1 && kdfirmId != null ) {

            for( Iterator iter = kunden.iterator(); iter.hasNext(); ) {
                Kunde kunde = ( Kunde )iter.next();
                if( kunde.getKundenfirma().getId().equals( kdfirmId ) ) {
                    displayKunde = kunde;
                    break;
                }
            }
        }
        // wenn mehrere Kunden gefunden, dessen Kundenfirmen zur Auswahl
        // anzeigen
        else if( kunden.size() > 1 ) {
            // Im Vector merken welche Kundenfirmen es zu kdnr gibt
            for( Iterator iter = kunden.iterator(); iter.hasNext(); ) {
                Kunde kunde = ( Kunde )iter.next();
                kundenFirmen.add( kunde.getKundenfirma() );
            }
            // Auswahldialog mit Kundenfirmen anzeigen
            KundenFirmaChooserDialog dialog = new KundenFirmaChooserDialog( parentController.getMainWindow(), kundenFirmen );

            dialog.setVisible( true );
            // ausgewählte Kundenfirma holen
            kundenFirma = dialog.getSelectedKundenfirma();
            // Kunden zur ausgewählten Kundenfirma holen
            if( kundenFirma != null ) {
                for( Iterator iter = kunden.iterator(); iter.hasNext(); ) {
                    Kunde kunde = ( Kunde )iter.next();
                    if( kunde.getKundenfirma().equals( kundenFirma ) ) {
                        displayKunde = kunde;
                        break;
                    }
                }
            }
        }
        // nur ein Kunde gefunden
        else if( kunden.size() > 0 ) {
            displayKunde = ( Kunde )kunden.iterator().next();
        }

        return displayKunde;
    }

    private void searchRechnungsPositionen( Long kdnr, Kundenfirma kundenFirma )  {

        Collection rechPos = getDiasService().sucheRechnungsPositionen( kundenFirma, kdnr );

        Collection tableData = new ArrayList( rechPos.size() );
        for( Iterator iter = rechPos.iterator(); iter.hasNext(); ) {
            KunderechnungspositionBean pos = ( KunderechnungspositionBean )iter.next();
            GroupableKunderechnungsposition groupPos = new GroupableKunderechnungsposition( pos );
            tableData.add( groupPos );
        }

        UIUtils.clearFillSortTable( kundenRechnungenPanel.getRechposTable(), kundenRechnungenPanel.getTableModel(), tableData );

        JTableHeader header = kundenRechnungenPanel.getRechposTable().getTableHeader();
        MouseListener[] l = header.getMouseListeners();
        for( int i = 0; i < l.length; i++ ) {
            header.removeMouseListener( l[i] );
        }

        kundenRechnungenPanel.getRechposTable().getTableHeader().getColumnModel().getColumn( 0 ).setPreferredWidth( 100 );
        kundenRechnungenPanel.getRechposTable().getTableHeader().getColumnModel().getColumn( 1 ).setPreferredWidth( 90 );
        kundenRechnungenPanel.getRechposTable().getTableHeader().getColumnModel().getColumn( 2 ).setPreferredWidth( 50 );
        kundenRechnungenPanel.getRechposTable().getTableHeader().getColumnModel().getColumn( 4 ).setPreferredWidth( 60 );
        kundenRechnungenPanel.getRechposTable().getTableHeader().getColumnModel().getColumn( 5 ).setPreferredWidth( 60 );
        kundenRechnungenPanel.getRechposTable().getTableHeader().getColumnModel().getColumn( 6 ).setPreferredWidth( 180 );
        kundenRechnungenPanel.getRechposTable().getTableHeader().getColumnModel().getColumn( 7 ).setPreferredWidth( 190 );
        kundenRechnungenPanel.getRechposTable().getTableHeader().getColumnModel().getColumn( 10 ).setPreferredWidth( 80 );
        kundenRechnungenPanel.getRechposTable().getTableHeader().getColumnModel().getColumn( 11 ).setPreferredWidth( 80 );

        parentController.getMainWindow().setStatusTextLeft( "Anzahl Rechnungspositionen : " + rechPos.size() );
    }

    private void searchRechnungsPositionen( KundenrechnungskopfBean kopf )  {

        Collection rechPos = getDiasService().sucheRechnungsPositionen( kopf );
        Collection tableData = new ArrayList( rechPos.size() );

        for( Iterator iter = rechPos.iterator(); iter.hasNext(); ) {
            KunderechnungspositionBean pos = ( KunderechnungspositionBean )iter.next();
            GroupableKunderechnungsposition groupPos = new GroupableKunderechnungsposition( pos );
            tableData.add( groupPos );
        }
        UIUtils.clearFillSortTable( kundenRechnungenPanel.getRechposTable(), kundenRechnungenPanel.getTableModel(), tableData );

        kundenRechnungenPanel.getRechposTable().getTableHeader().getColumnModel().getColumn( 0 ).setPreferredWidth( 100 );
        kundenRechnungenPanel.getRechposTable().getTableHeader().getColumnModel().getColumn( 1 ).setPreferredWidth( 90 );
        kundenRechnungenPanel.getRechposTable().getTableHeader().getColumnModel().getColumn( 2 ).setPreferredWidth( 50 );
        kundenRechnungenPanel.getRechposTable().getTableHeader().getColumnModel().getColumn( 4 ).setPreferredWidth( 60 );
        kundenRechnungenPanel.getRechposTable().getTableHeader().getColumnModel().getColumn( 5 ).setPreferredWidth( 60 );
        kundenRechnungenPanel.getRechposTable().getTableHeader().getColumnModel().getColumn( 6 ).setPreferredWidth( 180 );
        kundenRechnungenPanel.getRechposTable().getTableHeader().getColumnModel().getColumn( 7 ).setPreferredWidth( 190 );
        kundenRechnungenPanel.getRechposTable().getTableHeader().getColumnModel().getColumn( 10 ).setPreferredWidth( 80 );
        kundenRechnungenPanel.getRechposTable().getTableHeader().getColumnModel().getColumn( 11 ).setPreferredWidth( 80 );

        parentController.getMainWindow().setStatusTextLeft( "Anzahl Rechnungspositionen : " + rechPos.size() );
    }

    private void setKundenDetails( Kunde displayKunde ) {

        kundenRechnungenPanel.getVornameTextField().setText( displayKunde.getPerson().getVorname() );
        kundenRechnungenPanel.getNachnameTextField().setText( displayKunde.getPerson().getNachname() );

        if( displayKunde.getPerson().getAdresse().getStrasse() != null ) {

            kundenRechnungenPanel.getStrasseTextField().setText( displayKunde.getPerson().getAdresse().getStrasse() );
            String hausNr = null;
            hausNr = displayKunde.getPerson().getAdresse().getHausnummer() == null ? "" : displayKunde.getPerson().getAdresse().getHausnummer().toString();
            kundenRechnungenPanel.getHsnrTextField().setText( hausNr );
            kundenRechnungenPanel.getPlzTextField().setText( displayKunde.getPerson().getAdresse().getPostleitzahl() );
            kundenRechnungenPanel.getOrtTextField().setText( displayKunde.getPerson().getAdresse().getOrt() );

        }

        kundenRechnungenPanel.getKdfirmTextField().setText( displayKunde.getKundenfirma().getKundenfirmenKennzeichen().toString() + " - " + displayKunde.getKundenfirma().getBezeichnung() );
        kundenRechnungenPanel.getDisplayKdnrTextField().setText( displayKunde.getKundenNummer().toString() );
    }

    private void clearFrame() {

        kundenRechnungenPanel.getVornameTextField().setText( "" );
        kundenRechnungenPanel.getNachnameTextField().setText( "" );
        kundenRechnungenPanel.getStrasseTextField().setText( "" );
        kundenRechnungenPanel.getHsnrTextField().setText( "" );
        kundenRechnungenPanel.getPlzTextField().setText( "" );
        kundenRechnungenPanel.getOrtTextField().setText( "" );
        kundenRechnungenPanel.getKdfirmTextField().setText( "" );
        kundenRechnungenPanel.getDisplayKdnrTextField().setText( "" );

        UIUtils.clearFillSortTable( kundenRechnungenPanel.getRechposTable(), kundenRechnungenPanel.getTableModel(), null );

    }

    public void showCRSArtikelSearchDialog( Long artikelnummerWitt, String artikelGroesse ) {

        parentController.showCRSArtikelSearchDialog( artikelnummerWitt, artikelGroesse, Constants.STATISTIK_ARTIKEL_CRS_SEARCH );

    }

    public MainWindowController getParentController() {
        return parentController;
    }

    public void showDialog() {
        final JInternalFrame kundenRechnungenFrame = parentController.getMainWindow().addMDIWindow( kundenRechnungenPanel, "Rechnungssuche", true, true, true, true, null, 0, 0 );

        parentController.getMainWindow().setStatusTextLeft( "" );
        kundenRechnungenPanel.getKdnrTextField().requestFocus();
        kundenRechnungenFrame.setFrameIcon( Images.RECHNUNGEN_SEARCH );

        SwingUtilities.invokeLater( new Runnable() {
            @Override
            public void run() {
                try {
                    kundenRechnungenFrame.setMaximum( true );
                } catch( Exception e ) {
                    log.error( "Fehler beim Maximieren des KundenRechnungenFrame", e );
                }
            }
        } );
    }

    public void printRechnungsPositionen() {
        Collection reportCol = new ArrayList( kundenRechnungenPanel.getRechposTable().getModel().getRowCount() );
        // Hilfsklasse für Formatierungen von Datum
        SimpleDateFormat sdfmt = new SimpleDateFormat( "dd.MM.yyyy" );
        DecimalFormat fmt = new DecimalFormat( "##0.00" );

        // aus dem Model die bisher angezeigten Positionen holen und aufbereiten
        for( int i = 0; i < kundenRechnungenPanel.getRechposTable().getModel().getRowCount(); i++ ) {

            GroupableKunderechnungsposition groupRechPos = ( GroupableKunderechnungsposition )kundenRechnungenPanel.getRechposTable().getModel().getValueAt( i, 0 );
            KunderechnungspositionBean rechPos = groupRechPos.getPos();
            ReportBean reportBean = new ReportBean();

            reportBean.setRechnungsdatum( sdfmt.format( rechPos.getRechnungsdatum().getTime() ) );
            reportBean.setRetoureschluessel( rechPos.getRetoureschluessel().toString() );
            reportBean.setPositionsnummer( rechPos.getPositionsnummer().toString() );
            reportBean.setArtikelnummerWitt( rechPos.getArtikelnummerWitt().toString() );
            reportBean.setPromotionnummer( rechPos.getPromotionnummer() );
            reportBean.setArtikelgroesse( rechPos.getArtikelgroesse() );
            reportBean.setArtikelbezeichnung( ( rechPos.getArtikelbezeichnung() == null ? "" : rechPos.getArtikelbezeichnung() ) );
            reportBean.setFarbe( rechPos.getFarbe() == null ? "" : rechPos.getFarbe() );
            reportBean.setBestellmenge( rechPos.getBestellmenge() == null ? "" : rechPos.getBestellmenge().toString() );
            reportBean.setBestellbetrag( fmt.format( rechPos.getBestellbetrag() == null ? Double.valueOf( 0.0 ) : rechPos.getBestellbetrag() ) );
            reportBean.setGutschriftmenge( rechPos.getGutschriftmenge() == null ? "" : rechPos.getGutschriftmenge().toString() );
            reportBean.setGutschriftkennzeichen( rechPos.getGutschriftkennzeichen() == null ? "" : rechPos.getGutschriftkennzeichen().toString() );
            reportBean.setLieferkennzeichen( "" );
            if( rechPos.getLieferkennzeichen() != null ) {
                reportBean.setLieferkennzeichen( rechPos.getLieferkennzeichen().getLiKennzeichenKurzBezeichnung() );
            }
            reportBean.setRatenkennzeichen( rechPos.getRatenkennzeichen() == null ? "" : rechPos.getRatenkennzeichen().toString() );
            reportBean.setNaliwoche( rechPos.getNALIWoche().toString() );
            reportBean.setGruppe( groupRechPos.getGroup() );

            reportCol.add( reportBean );
        }

        if( reportCol.size() > 0 ) {
            JRDataSource datasourcce = new JRBeanCollectionDataSource( reportCol );
            Map reportData = new HashMap();
            reportData.put( "kdnr", kundenRechnungenPanel.getDisplayKdnrTextField().getText() );
            reportData.put( "kdfirma", kundenRechnungenPanel.getKdfirmTextField().getText() );
            reportData.put( "name", kundenRechnungenPanel.getVornameTextField().getText() + " " + kundenRechnungenPanel.getNachnameTextField().getText() );
            reportData.put( "strasse", kundenRechnungenPanel.getStrasseTextField().getText() + " " + kundenRechnungenPanel.getHsnrTextField().getText() );
            reportData.put( "ort", kundenRechnungenPanel.getPlzTextField().getText() + " " + kundenRechnungenPanel.getOrtTextField().getText() );

            try {
                showReportFrame( datasourcce, "/reports/dias_report_rechpos.jasper", reportData, "Rechnungspositionen drucken" );
            } catch( Exception e ) {
                log.error( "Fehler beim erstellen des Reports", e );
            }

        } else {
            JOptionPane.showMessageDialog( parentController.getMainWindow(), "Keine Daten zu den eingegebenen Suchkriterien gefunden!" );
        }

    }

    private void showReportFrame( JRDataSource datasource, String reportFileName, Map reportData, String frameTitle ) throws Exception {
        JasperPrint printer = null;
        InputStream in = KundenRechnungenPanelController.class.getResourceAsStream( reportFileName );
        printer = JasperFillManager.fillReport( in, reportData, datasource );

        JRViewer viewer = new JRViewer( printer );
        JInternalFrame report = parentController.getMainWindow().addMDIWindow( viewer, frameTitle );

        try {
            report.setMaximum( true );
        } catch( Exception e ) {
            log.error( "Fehler beim Maximieren des ReportFrame", e );
        }
    }

    public void runDiadem2( final Long kdnr ) {

        try {
            Long searchKdfirmKz = getDisplayKdfirmKz();

            JSONObject json = new JSONObject();
            json.put( "aktion", "load_konto");
            json.put( "erfassungstyp", "online");
            json.put( "kundenfirma", searchKdfirmKz.toString());
            json.put( "kontonummer", kdnr.toString());
            json.put( "zahlmethode", "0");
            json.put( "reiter", "kontobild");
            
            getParentController().getDefaultApplication().sendMessage( new Message( "DIADEM2", "DIAS", 1, json.toString()) );

        } catch( Exception e ) {
            log.error( "Fehler beim Starten von Diadem2.", e );
            JOptionPane.showMessageDialog( parentController.getMainWindow(), "Fehler beim Starten von Diadem2." );
        }

    }

    private Long getDisplayKdfirmKz() {

        Long kundenfirma = null;

        if( StringUtils.isNotEmpty( kundenRechnungenPanel.getKdfirmTextField().getText() ) ) {
            String kdfirmkz = StringUtils.substringBefore( kundenRechnungenPanel.getKdfirmTextField().getText(), "-" ).trim();
            kundenfirma = Long.parseLong(kdfirmkz);
        }

        return kundenfirma;

    }
}

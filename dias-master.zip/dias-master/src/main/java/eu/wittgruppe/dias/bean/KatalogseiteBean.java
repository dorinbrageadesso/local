package eu.wittgruppe.dias.bean;

import java.io.Serializable;

public class KatalogseiteBean implements Serializable {
	
	String katTyp = null;
	String katBez = null;
	String centeraID = null;
	String abbNr = null;
	Long druckSeitenNr = null;
	
	
	public KatalogseiteBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public String getAbbNr() {
		return abbNr;
	}


	public void setAbbNr(String abbNr) {
		this.abbNr = abbNr;
	}


	public String getCenteraID() {
		return centeraID;
	}


	public void setCenteraID(String cas) {
		this.centeraID = cas;
	}


	public Long getDruckSeitenNr() {
		return druckSeitenNr;
	}


	public void setDruckSeitenNr(Long druckSeitenNr) {
		this.druckSeitenNr = druckSeitenNr;
	}



	public String getKatBez() {
		return katBez;
	}


	public void setKatBez(String katBez) {
		this.katBez = katBez;
	}


	public String getKatTyp() {
		return katTyp;
	}


	public void setKatTyp(String katTyp) {
		this.katTyp = katTyp;
	}

}

package eu.wittgruppe.dias.domain;

import org.apache.commons.lang.builder.ToStringBuilder;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity(name = "OriginalArtikelstamm")
@Table(name = "Orig_ArtSta")
public class OriginalArtikelstamm implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OriginalArtikelstammPK pk = null;

	/*
	 * Datum der letzten Aenderung
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AENDDAT")
	private Date aenderungsdatum = null;

	/*
	 * Anzahl der Teile pro Set
	 */
	@Column(name = "ANZTEILESET")
	private Long anzahlTeileSet = null;

	/*
	 * Nummer der Artikelgruppe
	 */
	@Column(name = "ARTGRP")
	private String artikelgruppe = null;

	/*
	 * 6-stellige CRS-Artikelnummer bei Otto, d. h. so wird die
	 * Witt-Artikelnummer bei Otto bezeichnet.
	 */
	@Column(name = "ARTNR6CRS")
	private Long artikelnummer6CRS = null;

	/*
	 * 6-stellige Artikelnummer, wie sie bei Baur identifiziert wird.
	 */
	@Column(name = "ARTNR6CRSBAUR")
	private Long artikelnummer6CRSBaur = null;

	/*
	 * Auslandslieferantenkennzeichen bezueglich des Artikels (0 = kein
	 * Auslandslieferant, 1 = Auslandslieferant)
	 */
	@Column(name = "AUSLKZ")
	private String auslandslieferantenKz = null;

	/*
	 * EG-Lieferantenkennzeichen
	 */
	@Column(name = "EGKZ")
	private String eglieferantenKz = null;

	/*
	 * EG-Mengenkennezeichen (relevant fuer die Zollabwicklung)
	 */
	@Column(name = "EGMGKZ")
	private Long egMengenKz = null;

	/*
	 * EG-Quadratmeter-Faktor. (relevant fuer die Zollabwicklung)
	 */
	@Column(name = "EGQMETERFAKTOR")
	private Long egQuadratmeterFaktor = null;

	/*
	 * EG-Statistik Kennzeichen (relevant fuer die Zollabwicklung).
	 */
	@Column(name = "EGSTATKZ")
	private Long egStatistikKz = null;

	/*
	 * Nummer des Einkaufsbereichs
	 */
	@Column(name = "ETBER")
	private String etbereich = null;

	/*
	 * Gr|ner-Punkt-Kennzeichen
	 */
	@Column(name = "GRNPKTKZ")
	private String gruenerPunktKz = null;

	/*
	 * Entweder "H" (Haengeware), "L" (Legeware) oder "B" (Bauer Ware)
	 */
	@Column(name = "HAENGKZ")
	private String haengeKz = null;

	/*
	 * Hausgruppe (Kennzeichen Mediaartikel) z. B. A, B, C, D, ...
	 */
	@Column(name = "HAUSGRP")
	private String hausgruppe = null;

	/*
	 * Herkunftssaison
	 */
	@Column(name = "HERKSAISON")
	private Long herkunftssaison = null;

	/*
	 * Tuetenfaehigkeitskennzeichen Innenkarton (0 = Artikel nicht tuetenfaehig,
	 * 1 = Artikel ist tuetenfaehig, 6 = Minderwert.-Artikel, zu KLEX_SOKO
	 * zupackfaehig, 8 = Wertschmuck, generell Paket, 9=Im Originalkarton
	 * versandfaehig)
	 */
	@Column(name = "KARTONKZ")
	private Long kartonKz = null;

	/*
	 * Nummer des Katalogs
	 */
	@Column(name = "KATTYP")
	private String katalogtyp = null;

	/*
	 * Kritische Retoure, von WP gefplegt am HOST
	 */
	@Column(name = "KRITRET")
	private Long kritischeRetoure = null;

	/*
	 * Marktkennzeichen
	 */
	@Column(name = "MARKTKZ")
	private Long marktKz = null;

	/*
	 * Mengeneinheit des Artikels z. B. 1 fuer Stk. oder 100 fuer cm.
	 */
	@Column(name = "MGEINH")
	private Long mengeneinheit = null;

	/*
	 * Preisklasse
	 */
	@Column(name = "PRKL")
	private Long preisklasse = null;

	/*
	 * Kennzeichen, ob der Artikel ein Sammel- oder Setartikel ist.
	 * (1=Setartikel, 2=Sammelartikel)
	 */
	@Column(name = "SAMMELSETKZ")
	private Long sammelsetKz = null;

	/*
	 * Das Schutzkennzeichen wir din der Artikelkladde A in der Spalte 20
	 * (Kundenservicesymbol) erfasst (Ab Saison 102). Folgende Eintraege sind
	 * zugelassen: Eingabe Kategorie Erklaerung (leer) F frei - Der Artikel ist
	 * frei, d
	 */
	@Column(name = "SCHUTZKZ")
	private Long schutzKz = null;

	/*
	 * Setkennzeichen (Numerisch von 1 -999)
	 */
	@Column(name = "SETKZ")
	private Long setKz = null;

	/*
	 * Tara Kunststoff (Verpackungsgewicht) in Gramm
	 */
	@Column(name = "TARA_KUNSTST")
	private Long taraKunststoff = null;

	/*
	 * Tara Pappe (Verpackungsgewicht) in Gramm
	 */
	@Column(name = "TARA_PAPPE")
	private Long taraPappe = null;

	/*
	 * Transferkennzeichen fuer Grossrechner z. B. 0=nicht transferiert,
	 * 1=transferiert, aber noch nicht vom Grossrechner OK, 2= transferiert und
	 * OK vom HOST, 3=wird nicht transferiert. Defaultwert = 2, ==> kein
	 * Transfer zum HOST
	 */
	@Column(name = "TRANSFERKZ")
	private Long transferKz = null;

	/*
	 * Benutzernummer des Erfassers
	 */
	@Column(name = "USERNR")
	private Long usernummer = null;

	/*
	 * Gueltigkeitsdatum (Beginn) des Datensatzes
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "VONDAT")
	private Date vonDatum = null;

	/*
	 * Nummer der Warengruppe
	 */
	@Column(name = "WAGRP")
	private String warengruppe = null;

	public OriginalArtikelstamm() {
	}

	public Date getAenderungsdatum() {
		return aenderungsdatum;
	}

	public void setAenderungsdatum(Date aenderungsdatum) {
		this.aenderungsdatum = aenderungsdatum;
	}

	public Long getAnzahlTeileSet() {
		return anzahlTeileSet;
	}

	public void setAnzahlTeileSet(Long anzahlTeileSet) {
		this.anzahlTeileSet = anzahlTeileSet;
	}

	public String getArtikelgruppe() {
		return artikelgruppe;
	}

	public void setArtikelgruppe(String artikelgruppe) {
		this.artikelgruppe = artikelgruppe;
	}

	public Long getArtikelnummer6CRS() {
		return artikelnummer6CRS;
	}

	public void setArtikelnummer6CRS(Long artikelnummer6CRS) {
		this.artikelnummer6CRS = artikelnummer6CRS;
	}

	public Long getArtikelnummer6CRSBaur() {
		return artikelnummer6CRSBaur;
	}

	public void setArtikelnummer6CRSBaur(Long artikelnummer6CRSBaur) {
		this.artikelnummer6CRSBaur = artikelnummer6CRSBaur;
	}

	public String getAuslandslieferantenKz() {
		return auslandslieferantenKz;
	}

	public void setAuslandslieferantenKz(String auslandslieferantenKz) {
		this.auslandslieferantenKz = auslandslieferantenKz;
	}

	public String getEglieferantenKz() {
		return eglieferantenKz;
	}

	public void setEglieferantenKz(String eglieferantenKz) {
		this.eglieferantenKz = eglieferantenKz;
	}

	public Long getEgMengenKz() {
		return egMengenKz;
	}

	public void setEgMengenKz(Long egMengenKz) {
		this.egMengenKz = egMengenKz;
	}

	public Long getEgQuadratmeterFaktor() {
		return egQuadratmeterFaktor;
	}

	public void setEgQuadratmeterFaktor(Long egQuadratmeterFaktor) {
		this.egQuadratmeterFaktor = egQuadratmeterFaktor;
	}

	public Long getEgStatistikKz() {
		return egStatistikKz;
	}

	public void setEgStatistikKz(Long egStatistikKz) {
		this.egStatistikKz = egStatistikKz;
	}

	public String getEtbereich() {
		return etbereich;
	}

	public void setEtbereich(String etbereich) {
		this.etbereich = etbereich;
	}

	public String getGruenerPunktKz() {
		return gruenerPunktKz;
	}

	public void setGruenerPunktKz(String gruenerPunktKz) {
		this.gruenerPunktKz = gruenerPunktKz;
	}

	public String getHaengeKz() {
		return haengeKz;
	}

	public void setHaengeKz(String haengeKz) {
		this.haengeKz = haengeKz;
	}

	public String getHausgruppe() {
		return hausgruppe;
	}

	public void setHausgruppe(String hausgruppe) {
		this.hausgruppe = hausgruppe;
	}

	public Long getHerkunftssaison() {
		return herkunftssaison;
	}

	public void setHerkunftssaison(Long herkunftssaison) {
		this.herkunftssaison = herkunftssaison;
	}

	public Long getKartonKz() {
		return kartonKz;
	}

	public void setKartonKz(Long kartonKz) {
		this.kartonKz = kartonKz;
	}

	public String getKatalogtyp() {
		return katalogtyp;
	}

	public void setKatalogtyp(String katalogtyp) {
		this.katalogtyp = katalogtyp;
	}

	public Long getKritischeRetoure() {
		return kritischeRetoure;
	}

	public void setKritischeRetoure(Long kritischeRetoure) {
		this.kritischeRetoure = kritischeRetoure;
	}

	public Long getMarktKz() {
		return marktKz;
	}

	public void setMarktKz(Long marktKz) {
		this.marktKz = marktKz;
	}

	public Long getMengeneinheit() {
		return mengeneinheit;
	}

	public void setMengeneinheit(Long mengeneinheit) {
		this.mengeneinheit = mengeneinheit;
	}

	public Long getPreisklasse() {
		return preisklasse;
	}

	public void setPreisklasse(Long preisklasse) {
		this.preisklasse = preisklasse;
	}

	public Long getSammelsetKz() {
		return sammelsetKz;
	}

	public void setSammelsetKz(Long sammelsetKz) {
		this.sammelsetKz = sammelsetKz;
	}

	public Long getSchutzKz() {
		return schutzKz;
	}

	public void setSchutzKz(Long schutzKz) {
		this.schutzKz = schutzKz;
	}

	public Long getSetKz() {
		return setKz;
	}

	public void setSetKz(Long setKz) {
		this.setKz = setKz;
	}

	public Long getTaraKunststoff() {
		return taraKunststoff;
	}

	public void setTaraKunststoff(Long taraKunststoff) {
		this.taraKunststoff = taraKunststoff;
	}

	public Long getTaraPappe() {
		return taraPappe;
	}

	public void setTaraPappe(Long taraPappe) {
		this.taraPappe = taraPappe;
	}

	public Long getTransferKz() {
		return transferKz;
	}

	public void setTransferKz(Long transferKz) {
		this.transferKz = transferKz;
	}

	public Long getUsernummer() {
		return usernummer;
	}

	public void setUsernummer(Long usernummer) {
		this.usernummer = usernummer;
	}

	public Date getVonDatum() {
		return vonDatum;
	}

	public void setVonDatum(Date vonDatum) {
		this.vonDatum = vonDatum;
	}

	public String getWarengruppe() {
		return warengruppe;
	}

	public void setWarengruppe(String warengruppe) {
		this.warengruppe = warengruppe;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public OriginalArtikelstammPK getPk() {
		return pk;
	}

	public void setPk(OriginalArtikelstammPK pk) {
		this.pk = pk;
	}
}

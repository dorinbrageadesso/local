package eu.wittgruppe.dias.ui;

import org.apache.commons.lang.math.NumberUtils;
import witt.josef.uiswing.ui.LimitedDocument;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;

public class MengeInputDialog extends JDialog {

	private JPanel jContentPane = null;
	private JPanel centerPanel = null;
	private JButton okButton = null;
	private JButton cancelButton = null;
	private JFrame parent = null;
	private JTextField mengeTextField = null;
	private JPanel southPanel = null;
	private JLabel cmLabel = null;
	private Long menge = null;
	
	public Long getMenge() {
		return menge;
	}

	 
	public MengeInputDialog(JFrame parent) {
		super(parent);
		this.parent = parent;
		initialize();
		
		
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(324, 105);
		this.setTitle("Bitte Menge eingeben!");
		this.setModal(true);
		this.setContentPane(getJContentPane());
		UIUtils.centerOverComponent(parent, this);
		
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getCenterPanel(), java.awt.BorderLayout.CENTER);
			jContentPane.add(getSouthPanel(), BorderLayout.SOUTH);
		}
		return jContentPane;
	}

	/**
	 * This method initializes centerPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getCenterPanel() {
		if (centerPanel == null) {
			cmLabel = new JLabel();
			cmLabel.setText("cm");
			centerPanel = new JPanel();
			centerPanel.setLayout(new FlowLayout());
			centerPanel.add(getMengeTextField(), null);
			centerPanel.add(cmLabel, null);
		}
		return centerPanel;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getOkButton() {
		if (okButton == null) {
			okButton = new JButton();
			okButton.setPreferredSize(new java.awt.Dimension(100,26));
			okButton.setMaximumSize(new java.awt.Dimension(100,26));
			okButton.setText("OK");
			okButton.setMinimumSize(new java.awt.Dimension(100,26));
			OnOkButton okButtonListener = new OnOkButton();
			okButton.registerKeyboardAction( okButtonListener, 
					 "Enter", KeyStroke.getKeyStroke( KeyEvent.VK_ENTER, 0 ), 
					 JComponent.WHEN_IN_FOCUSED_WINDOW );
			okButton.addActionListener(okButtonListener);
		}
		return okButton;
	}

	/**
	 * This method initializes jButton1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getCancelButton() {
		if (cancelButton == null) {
			cancelButton = new JButton();
			cancelButton.setMaximumSize(new java.awt.Dimension(100,26));
			cancelButton.setPreferredSize(new java.awt.Dimension(100,26));
			cancelButton.setText("Abbrechen");
			cancelButton.setMinimumSize(new java.awt.Dimension(100,26));
			cancelButton.addActionListener(new OnCancelButton());
		}
		return cancelButton;
	}
	
	
	// L I S T E N E R S
	private class OnOkButton implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			
			menge = NumberUtils.createLong(getMengeTextField().getText());
			MengeInputDialog.this.setVisible(false);
		}
	};
	
	private class OnCancelButton implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			MengeInputDialog.this.setVisible(false);
		}
	}

	/**
	 * This method initializes mengeTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getMengeTextField() {
		if (mengeTextField == null) {
			mengeTextField = new JTextField();
			mengeTextField.setBackground(new java.awt.Color(231, 235, 235));
			mengeTextField.setMaximumSize(new Dimension(75, 20));
			mengeTextField.setMinimumSize(new Dimension(75, 20));
			mengeTextField.setPreferredSize(new Dimension(75, 20));
			mengeTextField.setDisabledTextColor(java.awt.Color.black);
			mengeTextField.setHorizontalAlignment(SwingConstants.RIGHT);
			LimitedDocument doc = new LimitedDocument(4, LimitedDocument.NUMBER);
			mengeTextField.setDocument(doc);
			SwingUtilities.invokeLater(new Runnable() {
	            public void run() {
	            	mengeTextField.requestFocus();
	            }
	        } );
		}
		return mengeTextField;
	}
	
	public void showDialog() {		
		this.setVisible(true);
	}


	/**
	 * This method initializes southPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getSouthPanel() {
		if (southPanel == null) {
			southPanel = new JPanel();
			southPanel.setLayout(new FlowLayout());
			southPanel.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			southPanel.add(getOkButton(), null);
			southPanel.add(getCancelButton(), null);
		}
		return southPanel;
	};

}  //  @jve:decl-index=0:visual-constraint="10,18"

package eu.wittgruppe.dias.service.dao;

import eu.wittgruppe.dias.bean.*;
import eu.wittgruppe.dias.domain.*;
import witt.josef.benutzerverwaltung.Account;

import java.util.Calendar;
import java.util.Collection;

public interface DiasDAO {

    public String getLKZFromZLKZAndBukr( String bukr, String zlkz );

    public Collection sucheLieferanten();

    /**
     * Gibt alle Merkmalsklassen zurück
     * 
     * @return Collection MerkmalklasseDiamant
     */
    public Collection<MerkmalklasseDiamant> sucheMerkmalsKlassen();

    /**
     * gibt zu einer Merkmalsklasse alle Marktkennzeichen zurück
     * 
     * @param klasse
     *            MerkmalklasseDiamant
     * @return Collection MarktKennzeichen
     */
    public Collection<Marktkennzeichen> sucheMarktKennzeichen( MerkmalklasseDiamant klasse );

    /**
     * Gibt alle Marktkennzeichen zurück
     * 
     * @return Collection MarktKennzeichen
     */
    public Collection<Marktkennzeichen> sucheAllMarktKennzeichen();

    /**
     * Gibt die Farbhierarchie zurück
     * 
     * @param farbe
     *            Farbe als String
     * @return Collection FarbeDefBean
     */
    public Collection<FarbeDefBean> sucheFarben( String farbe );

    /**
     * Sucht einen Artikel anhand der Artikelnr Unterscheidung ob Crosselling oder nicht
     * 
     * @param artnr
     *            artnr
     * @param isCrs
     *            isCrs
     * @return Collection VDiasArtikel
     */
    public Collection<VDiasArtikel> sucheArtikel( String artnr, Boolean isCrs );

    public Collection<VDiasArtikel> findByCriteria( String lkz, String artgr, String farbeId, String merkmalKlasse, String martkKz, Long aktSaison, int saison_zeitraum );

    public Collection<VDiasArtikel> findByCriteria( String artnr, Boolean isCrs, Long aktSaison, int saison_zeitraum );

    /**
     * sucht zu den übergebenen Parametern die dazu passenden Artikelpositionen
     * 
     * @param lkz
     *            lkz
     * @param artgr
     *            artgr
     * @param farbeId
     *            farbeId
     * @param merkmalKlasse
     *            merkmalKlasse
     * @param marktKz
     *            marktKz
     * @return Collection VDiasArtikel
     */
    public Collection<VDiasArtikel> sucheArtikel( String lkz, String artgr, String farbeId, String merkmalKlasse, String marktKz );

    /**
     * Liefert zu einer Artikelnummer den aktuellen Ersatzartikel zurück.
     * 
     * @param artnr6
     *            artnr6
     * @param artgr
     *            artgr
     * @param saison
     *            saison
     * @return ErsatzartikelBean ersatzartikel
     */
    public ErsatzartikelBean getErsatzartikel( String artnr6, String artgr, String saison );

    public long getAktuelleSaison();

    /**
     * Gibt zur MVnr ein x-beliebiges Bild zurück
     * 
     * @param mvnr
     *            MVNR
     * @return byte[] Array das den blob enthält
     */
    public byte[] getBild( Long mvnr );

    /**
     * Gibt Katalogtyp, katbez, cas, druckseitennr und abbnr zu einer Mvnr in einer Saison zurück
     * 
     * @param saison
     *            Saison
     * @param mvnr
     *            MVNr
     * @param isoSpracheCode
     *            Sprache z.B "DE"
     * @return KatalogSeiteBean
     */
    public KatalogseiteBean getKatalogSeiteCas( Long saison, Long mvnr, String isoSpracheCode );

    /**
     * Sucht zur Kundenfirma und Kundennummer alle vorhanden Rechnungspositionen
     * 
     * @param kundenFirma
     *            Kundenfirma
     * @param kdnr
     *            Kundennumer
     * @return Collection KunderechnungspositionBean 
     */
    public Collection sucheRechnungsPositionen( Kundenfirma kundenFirma, Long kdnr ) ;

    /**
     * Sucht zum Retoureschluessel den Kundenrechnungskopf
     * 
     * @param retschl Retoureschluessel
     * @param onlyCH Fuer Anwender aus CH duerfen nur Rechnungen aus Kundenfirmen von CH gefunden werden...
     * @return KundenrechnungskopfBean
     */
    public KundenrechnungskopfBean sucheRechnungsKopf( Long retschl, boolean onlyCH );

    /**
     * Sucht zum KundenrechnungskopfBean ( ID) alle vorhanden Rechnungspositionen
     * 
     * @param kopf
     *            KundenrechnungskopfBean
     * @return Collection KunderechnungspositionBean
     */
    public Collection sucheRechnungsPositionen( KundenrechnungskopfBean kopf ) ;

    public Collection getRechnungsPositionen( KundenrechnungskopfBean kopf, Kundenfirma kundenFirma, Long P_kdnr, boolean vonKopf );

    /**
     * Gibt zur Kdnr alle Kunden zurück
     * 
     * @param kdnr
     *            Kundennummer
     * @param onlyCH der Anwender darf nur Kunden aus CH sehen...
     * @return Collection Kunde
     */
    public Collection sucheKunden( Long kdnr, boolean onlyCH );

    /**
     * Selektiert Kundenobjekt
     * 
     * @param firma
     *            Kundenfirma
     * @param kdnr
     *            Kundennummer
     * @return Kunde
     */
    public Kunde sucheKunden( Kundenfirma firma, Long kdnr );

    /**
     * Zum Artikel das Retouresortkennzeichen suchen
     * 
     * @param artikelnummerWitt
     *            artikelnummerWitt
     * @param modellvariantengroesse
     *            modellvariantengroesse
     * @return GroessenArtikelstamm
     */
    public GroessenArtikelstamm sucheGroesseArtsta( Long artikelnummerWitt, String modellvariantengroesse );

    /**
     * Gibt Einstellungen für den Drucker für die Arbeitsstation zurück
     * 
     * @param dvNummer
     *            DVNummer
     * @return Collection ParamVerw
     */
    public Collection sucheParameter( String dvNummer );

    /**
     * Liest die Parameterverwaltung aus ob ein Drucker dieser DVNummer zugeordnet ist
     * 
     * @param dvNummer
     *            DVNR
     * @return True - Drucker zugewiesen
     */
    public Boolean druckerAngeschlossen( String dvNummer );

    /**
     * Suche Kunden mit Anschrift
     * 
     * @param personenIdCol
     *            Collections von Person Id's
     * @return Collection KundeSearchBean
     */
    public Collection sucheKundenMitAnschrift( Collection personenIdCol );

    /**
     * Legt einen Eintrag in der Tabelle Statistik an
     * 
     * @param kdnr
     *            artikelNummer
     * @param artikelNr
     *            artikelNr
     * @param artgr
     *            artgr
     * @param erfassungsKz
     *            erfassungsKz
     * @param cn
     *            cn
     */
    public void insertDiasStatistik( Long kdnr, Long artikelNr, String artgr, long erfassungsKz, String cn );

    /**
     * Selektiert die Gesamtanzahl erfasster Artikel für einen bestimmten Zeitraum
     * 
     * @param startCal
     *            Datum
     * @param endCal
     *            Datum
     * @return Collection StatistikBean
     */
    public Collection<StatistikBean> sucheDiasStatistikDaten( Calendar startCal, Calendar endCal );

    /**
     * Selektiert alle Statistikdaten für einen Benutzer in dem übergebenen Zeitraum
     * 
     * @param startCal
     *            Datum
     * @param endCal
     *            Datum
     * @param account
     *            Benutzeraccount
     * @return Collection StatistikBean
     */
    public Collection sucheDiasStatistikDaten( Calendar startCal, Calendar endCal, Account account );

    /**
     * selektiert die Bestandsfirma
     * 
     * @param firmKz
     *            Bestandsfirmakennzeichen
     * @return Bestandsfirma
     */
    public Bestandsfirma sucheBestandsFirma( int firmKz );

    public OriginalArtikelstamm sucheOriginalArtikel( Long saison, Long artikelNr );

    public String sucheLagerkoordinate( Long artikelNr, String artgr );

    public String formatLagerKoord( String koord );

}

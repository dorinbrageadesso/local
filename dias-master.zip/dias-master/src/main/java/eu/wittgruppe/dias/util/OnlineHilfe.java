
/*
*                                 J O S E F
*               Java Object Solutions Enterprise Framework
*                  Copyright 2002 - 2004 Josef Witt GmbH
*/


package eu.wittgruppe.dias.util;


import lombok.extern.slf4j.Slf4j;

import java.io.IOException;


/**
 * Startet den Internet Explorer und zeigt darin die &uuml;bergebene HTML-Datei<br> an. Wird ein Anker gesetzt, so wird an diesen Einsprungpunkt positioniert.
 *
 * @author Thomas Schell
 * @version 1.0
 */
@Slf4j
public class OnlineHilfe {
    //~ Instance fields ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    private String anker = null;
    private String browserStart = "C:\\Programme\\Internet Explorer\\iexplore.exe";
    private String htmlDatei = null;

    //~ Constructors -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    /**
     * Creates a new OnlineHilfe object.
     *
     * @param htmlDatei Die HilfeDatei
     */
    public OnlineHilfe( String htmlDatei ) {
        this.htmlDatei = htmlDatei;
    }
    
    /**
     * Creates a new OnlineHilfe object.
     *
     * @param htmlDatei Die HilfeDatei
     * @param anker Einsprungpunkt innerhalb der HTML-Datei
     */
    public OnlineHilfe( String htmlDatei, String anker ) {
        this.htmlDatei = htmlDatei;
        this.anker = anker;
    }


    /**
     * Creates a new OnlineHilfe object.
     */
    public OnlineHilfe(  ) {
    }

    //~ Methods ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    /**
     * Legt den Einsprungpunkt innerhalb der Hilfe-Datei fest.
     * Dieser muss mit dem gleichen Namen innerhalb des HTML-Dokumentes definiert sein.
     * @param anker Einsprungpunkt!
     */
    public void setAnker( String anker ) {
        this.anker = anker;
    }

    /**
     * Gibt den Einsprunktpunkt zur&uuml;ck
     * @return den Einsprunktpunkt
     */
    public String getAnker(  ) {
        return anker;
    }

    /**
     * Setzt den Startbefehl des Browsers
     * Wird diese Methode nicht aufgerufen wird automatisch der Internet Exploerer gestartet
     * (Achtung: Komplette Pfadangabe &uuml;bergeben)
     * @param browserStart Startbefehl des Browsers
     */
    public void setBrowserStart( String browserStart ) {
        this.browserStart = browserStart;
    }

    /**
     * Gibt den Startbefehl des Browsers zur&uuml;ck
     * @return Startbefehl des Browsers
     */
    public String getBrowserStart(  ) {
        return browserStart;
    }

    /**
     * Setzt die anzuzeigende HTML-Datei
     * @param htmlDatei die anzuzeigende HTML-Datei
     */
    public void setHtmlDatei( String htmlDatei ) {
        this.htmlDatei = htmlDatei;
    }

    /**
     * Gibt die HTML-Datei zur&uuml;ck
     * @return die HTML-Datei
     */
    public String getHtmlDatei(  ) {
        return htmlDatei;
    }

    /**
     * Starten den Browser mit den eingestellten Werten
     */
    public void show(  ) {
        try {
            if( htmlDatei != null ) {
                if( anker != null ) {
                    log.debug( "Hilfe mit HTML-Datei " + htmlDatei + " und Anker " + anker + " starten!" );
                    Runtime.getRuntime(  ).exec( browserStart + " " + htmlDatei + "#" + anker );
                } else {
                    log.debug( "Hilfe mit HTML-Datei " + htmlDatei + " starten!" );
                    Runtime.getRuntime(  ).exec( browserStart + " " + htmlDatei );
                }
            } else {
                log.debug( "Da keine HTML-Datei angegeben wurde wird der Browser mit der Standardseite geoeffnet!" );
                Runtime.getRuntime(  ).exec( browserStart );
            }
        } catch( IOException e ) {
            log.error( "Die Onlinehilfe konnte nicht gestartet werden!", e );
        }
    }
}

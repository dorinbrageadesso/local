package eu.wittgruppe.dias.util;

/**
 * <p>Überschrift: <BR>SortUtilities</p>
 * <p>Beschreibung: <BR>Bietet Hilfmethoden zur Sortierung verschiedenster Objektmengen.</p>
 * <p>Copyright: Copyright (c) 2001<BR></p>
 * <p>Organisation: Josef WITT GmbH<BR><BR></p>
	 * @author <a href="mailto:thomas.hoesl@witt-weiden.de">Thomas Hösl</a><BR>
 * @version 1.0
 */

import java.util.*;


public class SortUtilities
{

	/**
	 * Universalmethode zum Sortieren von Objektmengen.
	 *
	 * @param container Beliebige Objektmenge.
		 * @param dataHandler DataHandler-Instanz zum verarbeiten der Objektmenge.
		 * @param comparator Comparator zum vergleichen der Elemente der Ojektmenge.
	 * @param ascending Legt fest ob aufsteigend sortiert werden soll.
	 * @return Die sortierte Ergebnismenge;
	 */
	public static Object sort( Object container, Class dataHandler,
		Class comparator, boolean ascending ) {
		DataHandler handler = null;
		Comparator comp = null;

		// Container befüllt?
		if( container == null ) {
			return container;
		}

		// Handler erzeugen
		try {
			handler = ( DataHandler ) dataHandler.newInstance();
		}
		catch( NullPointerException ex ) {
			throw new IllegalArgumentException(
				"The arguement 'dataHandler' is 'null' !" );
		}
		catch( ClassCastException ex ) {
			throw new IllegalArgumentException( "The class '"
				+ dataHandler.getName() + "' does not implement "
				+ DataHandler.class.getName() + " !" );
		}
		catch( Exception ex ) {
			ex.printStackTrace();
			throw new IllegalArgumentException( "The class '"
				+ dataHandler.getName()
				+ "' could not be instantiated or an other error occured!" );
		}

		// Comparator erzeugen
		try {
			comp = ( Comparator ) comparator.newInstance();
			comp = new InnerSortComparator( comp, ascending );
		}
		catch( NullPointerException ex ) {
			throw new IllegalArgumentException(
				"The arguement 'comparator' is 'null' !" );
		}
		catch( ClassCastException ex ) {
			throw new IllegalArgumentException( "The class '"
				+ comparator.getName() + "' does not implement "
				+ Comparator.class.getName() + " !" );
		}
		catch( Exception ex ) {
			ex.printStackTrace();
			throw new IllegalArgumentException( "The class '"
				+ comparator.getName()
				+ "' could not be instantiated or an other error occured!" );
		}

		// Daten aus Container ermitteln
		Object[] data = handler.getDataFromContainer( container );

		// Daten sortieren
		Arrays.sort( data, comp );

		// Sortierte Daten in einen Container verpacken
		Object newContainer = handler.getContainerFromData( data );

		// neuen Container zurückgeben
		return newContainer;
	}

	/**
	 * Inner Class zur Anpassung der Sortierrichtung.
	 */
	private static class InnerSortComparator
		implements Comparator
	{
		private boolean ascending = true;
		private Comparator comparator = null;

		public InnerSortComparator( Comparator c, boolean ascending ) {
			this.comparator = c;
			this.ascending = ascending;
		}

		public boolean equals( Object o ) {
			return this.comparator.equals( o );
		}

		public int compare( Object o1, Object o2 ) {
			int value = this.comparator.compare( o1, o2 );
			if( this.ascending ) {
				return value;
			} else {
				return( value * -1 );
			}
		}
	}


	/**
	 * Handler-Interface für die Ermittlung der zu sortierenden Daten bzw.
	 * der Erzeugung eines neuen Containerobjektes (z.B. Iterator)
	 */
	public static interface DataHandler
	{
		/**
		 * Extrahiert aus container die zu sorierenden Daten.
		 *
		 * @param container Objekt das die zu sorierenden Daten enthält.
		 * @return Alle zu sorierenden Daten.
		 */
		public Object[] getDataFromContainer( Object container );

		/**
		 * Erzeugt aus den Daten einen neuen Container (z.B. Iterator).
		 *
			 * @param data Sortierte Daten die in den Container verpackt werden sollen.
		 * @return Ein Container gefüllt mit sortierten Daten.
		 */
		public Object getContainerFromData( Object[] data );
	}


	/**
	 * Referenzimplementierung für IIterator.
	 */
	public static class IteratorDataHandler
		implements DataHandler
	{
		public Object[] getDataFromContainer( Object container ) {
			Vector v = new Vector( 50 );
			// Object[] erzeugen
			Iterator iter = ( Iterator ) container;
			while( iter.hasNext() ) {
				v.add( iter.next() );
			}
			return v.toArray();
		}

		public Object getContainerFromData( Object[] data ) {
			// Neuen Iterator erzeugen
			ArrayList list = new ArrayList( data.length );
			for( int i = 0; i < data.length; i++ ) {
				list.add( data[ i ] );
			}
			return list.iterator();
		}
	}


	/**
	 * Referenzimplementierung für Pageable.
	 */
	public static class CollectionDataHandler
		implements DataHandler
	{

		public Object[] getDataFromContainer( Object container ) {
			Collection col = ( Collection ) container;
			return col.toArray();
		}

		public Object getContainerFromData( Object[] data ) {
			// Neuen Iterator erzeugen
			ArrayList list = new ArrayList( data.length );
			for( int i = 0; i < data.length; i++ ) {
				list.add( data[ i ] );
			}
			return list;
		}
	}

}
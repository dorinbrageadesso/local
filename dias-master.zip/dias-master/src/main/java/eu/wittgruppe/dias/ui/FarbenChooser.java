package eu.wittgruppe.dias.ui;

import eu.wittgruppe.dias.controller.FarbenChooserController;
import eu.wittgruppe.dias.ui.renderer.FarbenTreeCellRenderer;
import eu.wittgruppe.dias.util.Images;
import eu.wittgruppe.dias.util.TreeNodeBean;
import org.apache.commons.lang.StringUtils;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import java.awt.*;
import java.awt.event.KeyEvent;

;

public class FarbenChooser extends JDialog {
	
	FarbenChooserController controller = null;
	
	private JPanel jContentPane = null;
	private JScrollPane jScrollPane = null;
	private JTree farbenTree = null;
	private JPanel centerPanel = null;
	private JPanel southPanel = null;
	private JButton okButton = null;
	private JButton canelButton = null;

	private JToolBar toolBar = null;

	private JButton expandButton = null;

	private JButton collapseButton = null;

	private JButton filterColorButton = null;

	private JTextField farbeTextField = null;

	private JLabel farbeLabel = null;

	 
	public FarbenChooser(JFrame parent, FarbenChooserController controller) {
		super(parent);
		this.controller = controller;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(430, 528);
		this.setTitle("Farbenauswahl");
		this.setContentPane(getJContentPane());
		this.addWindowListener(new WindowCloseEvent());
		UIUtils.centerOnScreen(this);
		controller.getParentController().getParentController().getMainWindow().setEnabled(false);
		
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getCenterPanel(), java.awt.BorderLayout.CENTER);
			jContentPane.add(getSouthPanel(), java.awt.BorderLayout.SOUTH);
			jContentPane.add(getToolBar(), java.awt.BorderLayout.NORTH);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setViewportView(getFarbenTree());
		}
		return jScrollPane;
	}

	/**
	 * This method initializes farbenTree	
	 * 	
	 * @return javax.swing.JTree	
	 */
	public JTree getFarbenTree() {
		if (farbenTree == null) {
			DefaultMutableTreeNode root = controller.createTreeNodes(null);			
			farbenTree = new JTree(root);					
			farbenTree.setCellRenderer(new FarbenTreeCellRenderer());
			farbenTree.addMouseListener(new DoubleClickOnTree());
		}
		return farbenTree;
	}

	/**
	 * This method initializes northPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getCenterPanel() {
		if (centerPanel == null) {
			GridBagConstraints gridBagConstraints2 = new GridBagConstraints();
			gridBagConstraints2.gridx = 0;
			gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints2.insets = new java.awt.Insets(5,5,2,2);
			gridBagConstraints2.gridy = 0;
			farbeLabel = new JLabel();
			farbeLabel.setText("Farbe filtern:");
			GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
			gridBagConstraints1.fill = java.awt.GridBagConstraints.NONE;
			gridBagConstraints1.gridy = 1;
			gridBagConstraints1.weightx = 1.0;
			gridBagConstraints1.insets = new java.awt.Insets(0,5,5,0);
			gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints1.gridwidth = 1;
			gridBagConstraints1.gridx = 0;
			GridBagConstraints gridBagConstraints = new GridBagConstraints();
			gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
			gridBagConstraints.gridx = 0;
			gridBagConstraints.gridy = 2;
			gridBagConstraints.weightx = 1.0;
			gridBagConstraints.weighty = 1.0;
			gridBagConstraints.gridwidth = 1;
			gridBagConstraints.insets = new java.awt.Insets(5,5,5,5);
			centerPanel = new JPanel();
			centerPanel.setLayout(new GridBagLayout());
			centerPanel.add(getJScrollPane(), gridBagConstraints);
			centerPanel.add(getFarbeTextField(), gridBagConstraints1);
			centerPanel.add(farbeLabel, gridBagConstraints2);
		}
		return centerPanel;
	}

	/**
	 * This method initializes southPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getSouthPanel() {
		if (southPanel == null) {
			southPanel = new JPanel();
			southPanel.add(getOkButton(), null);
			southPanel.add(getCancelButton(), null);
		}
		return southPanel;
	}

	/**
	 * This method initializes jButton1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getOkButton() {
		if (okButton == null) {
			okButton = new JButton();
			okButton.setMaximumSize(new Dimension(108, 26));
			okButton.setPreferredSize(new Dimension(108, 26));
			okButton.setText("OK");
			okButton.setMinimumSize(new Dimension(108, 26));
			okButton.addActionListener(new OnOKButton());
		}
		return okButton;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getCancelButton() {
		if (canelButton == null) {
			canelButton = new JButton();
			canelButton.setMaximumSize(new Dimension(108, 26));
			canelButton.setPreferredSize(new Dimension(108, 26));
			canelButton.setText("Abbrechen");
			canelButton.setMinimumSize(new Dimension(108, 26));	
			canelButton.addActionListener(new OnCanelButton());
			
		}
		return canelButton;
	}


	/**
	 * This method initializes toolBar	
	 * 	
	 * @return javax.swing.JToolBar	
	 */
	private JToolBar getToolBar() {
		if (toolBar == null) {
			toolBar = new JToolBar();			
			toolBar.setOpaque(true);
			toolBar.setFloatable(false);
			toolBar.add(getExpandButton());
			toolBar.add(getCollapseButton());
			toolBar.add(getFilterColorButton());
						
		}
		return toolBar;
	}

	/**
	 * This method initializes expandButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getExpandButton() {
		if (expandButton == null) {
			expandButton = new JButton();
			expandButton.setIcon(Images.EXPAND_ALL);
			expandButton.setToolTipText("Baum aufklappen");
			expandButton.addActionListener(new OnExpandAll());
		}
		return expandButton;
	}

	/**
	 * This method initializes collapseButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getCollapseButton() {
		if (collapseButton == null) {
			collapseButton = new JButton();
			collapseButton.setIcon(Images.COLLAPSE_ALL);
			collapseButton.setToolTipText("Baum zusammenklappen");
			collapseButton.addActionListener(new OnCollapseAll());
		}
		return collapseButton;
	}
	
	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getFilterColorButton() {
		if (filterColorButton == null) {
			filterColorButton = new JButton();
			filterColorButton.setToolTipText("Farben filtern");
			filterColorButton.setIcon(Images.FARBE_FILTER);
			OnFilterFarbe listener = new OnFilterFarbe() ;
			filterColorButton.addActionListener(listener);
			filterColorButton.registerKeyboardAction( listener, 
					 "Enter", KeyStroke.getKeyStroke( KeyEvent.VK_ENTER, 0 ), 
					 JComponent.WHEN_IN_FOCUSED_WINDOW );
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					getFarbeTextField().requestFocus();
				}
			});
		}
		return filterColorButton;
	}

	/**
	 * This method initializes farbeTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getFarbeTextField() {
		if (farbeTextField == null) {
			farbeTextField = new JTextField();
			farbeTextField.setPreferredSize(new java.awt.Dimension(140,20));
			farbeTextField.setMaximumSize(new java.awt.Dimension(140,20));
			farbeTextField.setMinimumSize(new java.awt.Dimension(140,20));
		}
		return farbeTextField;
	};
	
	
//	 L I S T E N E R S
	/**
	 * @author Mather
	 * Beim Schliessen
	 */
	private class WindowCloseEvent extends java.awt.event.WindowAdapter {
		public void windowClosing(java.awt.event.WindowEvent e) {
			controller.getParentController().getParentController().getMainWindow().setEnabled(true);
		}
	}	
	/**
	 * @author Mather
	 * beim Drücken des OK Button
	 */
	private class OnOKButton implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			
			controller.getParentController().getParentController().getMainWindow().setEnabled(true);
			TreeNodeBean nodeVO = controller.getSelectTreeNodeBean();
			((ArtikelSearchCriteriaPanel)controller.getParentController().getArtikelSearchPanel().getSearchPanel())
				.getFarbeTextField().setValueObject(nodeVO);
		}
	}
	
	/**
	 * @author Mather
	 * beim Drücken des CancelButton
	 */
	private class OnCanelButton implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			controller.getParentController().getParentController().getMainWindow().setEnabled(true);
			FarbenChooser.this.dispose();
		}
	}
	
	/**
	 * @author Mather
	 * wenn ein Lieferant ausgewählt wird
	 */
	private class DoubleClickOnTree extends java.awt.event.MouseAdapter {
		public void mouseClicked(java.awt.event.MouseEvent e) {
			
			if (e.getClickCount()==2) {
				
				controller.getParentController().getParentController().getMainWindow().setEnabled(true);
				TreeNodeBean nodeVO = controller.getSelectTreeNodeBean();
				((ArtikelSearchCriteriaPanel)controller.getParentController().getArtikelSearchPanel()
					.getSearchPanel()).getFarbeTextField().setValueObject(nodeVO);				
								
			}			
			
		}
	}
	

	private class OnExpandAll implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			controller.expandTree();
		}
	};

	private class OnCollapseAll implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			controller.collapseTree();
		}
	}
	private class OnFilterFarbe implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {	
			
			String filterFarbe = StringUtils.trim(getFarbeTextField().getText());
			
			if (StringUtils.isEmpty(filterFarbe)) {
				 filterFarbe = "%";
			}
			
			DefaultTreeModel model = (DefaultTreeModel)farbenTree.getModel();			
			model.setRoot(controller.createTreeNodes( filterFarbe ));
			model.reload();
		}
	}
	
}  //  @jve:decl-index=0:visual-constraint="10,10"

package eu.wittgruppe.dias.ui.renderer;

import eu.wittgruppe.dias.bean.LieferantBean;

import javax.swing.*;
import java.awt.*;

public class LieferantenTableRenderer extends DiasTableCellRenderer {

	 public LieferantenTableRenderer() {
		 
	 }
	
	 public Component getTableCellRendererComponent( 
	        JTable table, Object value, boolean isSelected, boolean hasFocus,
	        int row, int column ) {        
	        
	        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, 
	                                            row, column);
	        
	        LieferantBean lieferant = (LieferantBean)value;
	       
	        switch (column) {
			case 0:
				this.setText(lieferant.getBuchungskreis().toString());
				break;

			case 1:
				this.setText(lieferant.getZlkz().toString());
				break;
			case 2: 
				this.setText(lieferant.getNummer().toString());
				break;
			case 3:
				this.setText(lieferant.getName());
				break;
			default:
				this.setText("LieferantenTableRenderer: not implemented");
			}       
	        
	        return this;
		        
	 }

}

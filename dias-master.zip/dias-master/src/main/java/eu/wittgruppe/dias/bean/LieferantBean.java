package eu.wittgruppe.dias.bean;

import java.io.Serializable;

public class LieferantBean implements Serializable {
	
	private Long buchungskreis;
	private Long zlkz;
	private Long nummer;
	private String name;
	
	public String getName() {
		return name;
	}
	public void setName(String liefBez) {
		this.name = liefBez;
	}
	public Long getNummer() {
		return nummer;
	}
	public void setNummer(Long lkz) {
		this.nummer = lkz;
	}
	public Long getZlkz() {
		return zlkz;
	}
	public void setZlkz(Long zlkz) {
		this.zlkz = zlkz;
	}
	public Long getBuchungskreis() {
		return buchungskreis;
	}
	public void setBuchungskreis(Long buchungskreis) {
		this.buchungskreis = buchungskreis;
	}
}

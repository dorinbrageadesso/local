package eu.wittgruppe.dias.controller;

import eu.wittgruppe.dias.bean.FarbeDefBean;
import eu.wittgruppe.dias.service.DiasService;
import eu.wittgruppe.dias.ui.FarbenChooser;
import eu.wittgruppe.dias.ui.SimpleErrorDialog;
import eu.wittgruppe.dias.util.TreeNodeBean;
import eu.wittgruppe.dias.util.TreeUtils;
import lombok.extern.slf4j.Slf4j;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

@Slf4j
public class FarbenChooserController {

    FarbenChooser chooser = null;

    ArtikelSearchController parentController = null;

    public FarbenChooserController( ArtikelSearchController parentController ) {
        this.parentController = parentController;
        chooser = new FarbenChooser( parentController.getParentController().getMainWindow(), this );
    }

    public ArtikelSearchController getParentController() {
        return parentController;
    }

    public void setParentController( ArtikelSearchController parentController ) {
        this.parentController = parentController;
    }

    public void showDialog() {
        chooser.setVisible( true );

    }

    public DiasService getDiasService() {
        return parentController.getDiasService();
    }

    public DefaultMutableTreeNode createTreeNodes( String farbe ) {

        DefaultMutableTreeNode root = new DefaultMutableTreeNode( "Farben" );
        Collection farbenCol = null;

        try {
            farbenCol = getDiasService().sucheFarben( farbe );
            // rekursive Funktion die den Baum aufbaut
            createNode( root, null, ( ArrayList )farbenCol );

        } catch( Exception e ) {
            log.error( "Fehler Remoteaufruf beim erstellen des Trees", e );
            new SimpleErrorDialog( parentController.getParentController().getMainWindow(), "Fehler Farben dialog", true, e.getMessage(), e );
        }

        return root;
    }

    private void createNode(DefaultMutableTreeNode parentNode, FarbeDefBean parentFarbe, ArrayList farben ) {

        Collection childs = getChilds( parentFarbe, farben );

        for( Iterator iter = childs.iterator(); iter.hasNext(); ) {

            FarbeDefBean child = ( FarbeDefBean )iter.next();
            DefaultMutableTreeNode childNode = new DefaultMutableTreeNode();
            TreeNodeBean nodeVO = new TreeNodeBean( child.getFarbe(), child );
            childNode.setUserObject( nodeVO );
            parentNode.add( childNode );

            createNode( childNode, child, farben );
        }

        return;

    }

    private Collection getChilds( FarbeDefBean parentFarbe, ArrayList farben ) {

        Collection col = new ArrayList();

        for( int i = 0; i < farben.size(); i++ ) {

            FarbeDefBean farbe = ( FarbeDefBean )farben.get( i );

            if( parentFarbe == null && farbe.getParentId() == null ) {
                col.add( farbe );
            } else if( parentFarbe != null && parentFarbe.getId().equals( farbe.getParentId() ) ) {
                col.add( farbe );
            }
        }

        return col;
    }

    public TreeNodeBean getSelectTreeNodeBean() {

        TreeNodeBean nodeVO = null;
        TreePath path = chooser.getFarbenTree().getSelectionPath();
        if( path == null ) {
            JOptionPane.showMessageDialog( chooser, "Keine Farbe ausgewählt. Bitte eine Farbe auswählen!", "Farbenauswahl", JOptionPane.WARNING_MESSAGE );
            return nodeVO;
        }
        DefaultMutableTreeNode node = ( DefaultMutableTreeNode )path.getLastPathComponent();

        if( node.isRoot() ) {
            JOptionPane.showMessageDialog( chooser, "Keine gültige Farbe ausgewählt. Bitte eine gültige Farbe auswählen!", "Farbenauswahl", JOptionPane.WARNING_MESSAGE );
            return nodeVO;
        }

        nodeVO = ( TreeNodeBean )node.getUserObject();
        chooser.dispose();

        return nodeVO;
    }

    public void collapseTree() {
        TreeUtils.collapseWithoutRoot( chooser.getFarbenTree() );
    }

    public void expandTree() {
        TreeUtils.expandAll( chooser.getFarbenTree() );
    }
}

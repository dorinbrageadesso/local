package eu.wittgruppe.dias.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;

@Entity(name = "Bestandsfirma")
@Table(name = "bestandsfirma")
public class Bestandsfirma implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "BEIRATSVORSITZENDER")
	private String beiratsvorsitzender = null;

	@Column(name = "FIRMBEZ")
	private String firmenBezeichnung = null;

	@Column(name = "FIRMKURZBEZ")
	private String firmenKurzbezeichnung = null;

	@Column(name = "FIRMKURZBEZ2")
	private String firmenKurzbezeichnung2 = null;

	@Column(name = "FIRMKZ")
	private Long kennzeichen = null;

	@Column(name = "FIRMORT")
	private String firmenOrt = null;

	@Column(name = "FIRMPLZ")
	private String firmenPLZ = null;

	@Column(name = "FIRMSTR")
	private String firmenStrasse = null;

	@Column(name = "GESCHFUEHRER_1")
	private String geschaeftsfuehrer = null;

	@Column(name = "GESCHFUEHRER_2")
	private String geschaeftsfuehrer2 = null;

	@Column(name = "GESCHFUEHRER_3")
	private String geschaeftsfuehrer3 = null;

	@Column(name = "GESCHFUEHRER_4")
	private String geschaeftsfuehrer4 = null;

	@Column(name = "GESCHFUERER_5")
	private String geschaeftsfueher5 = null;

	@Column(name = "HANDELSREGISTER")
	private String handelsregister = null;

	@Id
	private String id = null;

	@Column(name = "ILNNR")
	private String i18nLokationsnr = null;

	@Column(name = "USTIDNR")
	private String umsatzsteuerIDNr = null;

	public String getBeiratsvorsitzender() {
		return beiratsvorsitzender;
	}

	public void setBeiratsvorsitzender(String beiratsvorsitzender) {
		this.beiratsvorsitzender = beiratsvorsitzender;
	}

	public String getFirmenBezeichnung() {
		return firmenBezeichnung;
	}

	public void setFirmenBezeichnung(String firmenBezeichnung) {
		this.firmenBezeichnung = firmenBezeichnung;
	}

	public String getFirmenKurzbezeichnung() {
		return firmenKurzbezeichnung;
	}

	public void setFirmenKurzbezeichnung(String firmenKurzbezeichnung) {
		this.firmenKurzbezeichnung = firmenKurzbezeichnung;
	}

	public String getFirmenKurzbezeichnung2() {
		return firmenKurzbezeichnung2;
	}

	public void setFirmenKurzbezeichnung2(String firmenKurzbezeichnung2) {
		this.firmenKurzbezeichnung2 = firmenKurzbezeichnung2;
	}

	public Long getKennzeichen() {
		return kennzeichen;
	}

	public void setKennzeichen(Long kennzeichen) {
		this.kennzeichen = kennzeichen;
	}

	public String getFirmenOrt() {
		return firmenOrt;
	}

	public void setFirmenOrt(String firmenOrt) {
		this.firmenOrt = firmenOrt;
	}

	public String getFirmenPLZ() {
		return firmenPLZ;
	}

	public void setFirmenPLZ(String firmenPLZ) {
		this.firmenPLZ = firmenPLZ;
	}

	public String getFirmenStrasse() {
		return firmenStrasse;
	}

	public void setFirmenStrasse(String firmenStrasse) {
		this.firmenStrasse = firmenStrasse;
	}

	public String getGeschaeftsfuehrer() {
		return geschaeftsfuehrer;
	}

	public void setGeschaeftsfuehrer(String geschaeftsfuehrer) {
		this.geschaeftsfuehrer = geschaeftsfuehrer;
	}

	public String getGeschaeftsfuehrer2() {
		return geschaeftsfuehrer2;
	}

	public void setGeschaeftsfuehrer2(String geschaeftsfuehrer2) {
		this.geschaeftsfuehrer2 = geschaeftsfuehrer2;
	}

	public String getGeschaeftsfuehrer3() {
		return geschaeftsfuehrer3;
	}

	public void setGeschaeftsfuehrer3(String geschaeftsfuehrer3) {
		this.geschaeftsfuehrer3 = geschaeftsfuehrer3;
	}

	public String getGeschaeftsfuehrer4() {
		return geschaeftsfuehrer4;
	}

	public void setGeschaeftsfuehrer4(String geschaeftsfuehrer4) {
		this.geschaeftsfuehrer4 = geschaeftsfuehrer4;
	}

	public String getGeschaeftsfueher5() {
		return geschaeftsfueher5;
	}

	public void setGeschaeftsfueher5(String geschaeftsfueher5) {
		this.geschaeftsfueher5 = geschaeftsfueher5;
	}

	public String getHandelsregister() {
		return handelsregister;
	}

	public void setHandelsregister(String handelsregister) {
		this.handelsregister = handelsregister;
	}

	public String getId() {
		return id;
	}

	public String getI18nLokationsnr() {
		return i18nLokationsnr;
	}

	public void setI18nLokationsnr(String lokationsnr) {
		i18nLokationsnr = lokationsnr;
	}

	public String getUmsatzsteuerIDNr() {
		return umsatzsteuerIDNr;
	}

	public void setUmsatzsteuerIDNr(String umsatzsteuerIDNr) {
		this.umsatzsteuerIDNr = umsatzsteuerIDNr;
	}

	public String toString() {
		return getFirmenBezeichnung();
	}
}

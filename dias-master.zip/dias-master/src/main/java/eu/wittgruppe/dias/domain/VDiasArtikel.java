package eu.wittgruppe.dias.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;

@Entity(name = "VDiasArtikel")
@Table(name = "mv_dias_artikel")
public class VDiasArtikel implements Serializable {

	private static final long serialVersionUID = 1L;

    @Id
	@Column(name = "artnr6")
	private Long artikelnummerWitt = null;

	@Column(name = "saison")
	private Long saison = null;

	@Column(name = "liefnr")
	private Long lieferantennummer = null;

	@Column(name = "liefname")
	private String lieferantenname = null;

	@Column(name = "mvgr")
	private String modellvariantengroesse = null;

	@Column(name = "mvnr")
	private Long modellvariantennummer = null;

	@Column(name = "artbez")
	private String artikelbezeichnung = null;

	@Column(name = "katartorig")
	private String originalKatalogart = null;
	
	@Column (name = "farbe")
	private String farbe = null;

    @Column(name = "mgeinh")
    private String mengeneinheit = null;

	public Long getArtikelnummerWitt() {
		return artikelnummerWitt;
	}

	public void setArtikelnummerWitt(Long artikelnummerWitt) {
		this.artikelnummerWitt = artikelnummerWitt;
	}

    public void setMengeneinheit( String mengeneinheit ) {
        this.mengeneinheit = mengeneinheit;
    }

    public String getMengeneinheit() {
        return mengeneinheit;
    }

	public Long getSaison() {
		return saison;
	}

	public void setSaison(Long saison) {
		this.saison = saison;
	}

	public Long getLieferantennummer() {
		return lieferantennummer;
	}

	public void setLieferantennummer(Long lieferantennummer) {
		this.lieferantennummer = lieferantennummer;
	}

	public String getLieferantenname() {
		return lieferantenname;
	}

	public void setLieferantenname(String lieferantenname) {
		this.lieferantenname = lieferantenname;
	}

	public String getModellvariantengroesse() {
		return modellvariantengroesse;
	}

	public void setModellvariantengroesse(String modellvariantengroesse) {
		this.modellvariantengroesse = modellvariantengroesse;
	}

	public Long getModellvariantennummer() {
		return modellvariantennummer;
	}

	public void setModellvariantennummer(Long modellvariantennummer) {
		this.modellvariantennummer = modellvariantennummer;
	}

	public String getArtikelbezeichnung() {
		return artikelbezeichnung;
	}

	public void setArtikelbezeichnung(String artikelbezeichnung) {
		this.artikelbezeichnung = artikelbezeichnung;
	}
	
	public void setOriginalKatalogart(String originalKatalogart) {
		this.originalKatalogart = originalKatalogart;
	}
	
	public String getOriginalKatalogart() {
		return originalKatalogart;
	}
	
	public String getFarbe() {
		return farbe;
	}
	
	public void setFarbe(String farbe) {
		this.farbe = farbe;
	}
}

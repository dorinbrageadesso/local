package eu.wittgruppe.dias.domain;

import org.apache.commons.lang.builder.ToStringBuilder;

import jakarta.persistence.*;
import java.io.Serializable;
import java.sql.Date;

//import witt.service.common.parameterverwaltung.ParameterverwaltungService;

@Entity(name = "Parameterverwaltung")
@Table(name = "param_verw")
// @CRUD(service=ParameterverwaltungService.class)
public class Parameterverwaltung implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	@AttributeOverrides( {
			@AttributeOverride(name = "bezeichnung", column = @Column(name = "PARAMBEZ")),
			@AttributeOverride(name = "gruppe", column = @Column(name = "PARAMGRP")),
			@AttributeOverride(name = "programmname", column = @Column(name = "PROGNAME")),
			@AttributeOverride(name = "zielgruppe", column = @Column(name = "ZIELGRUPPE")) })
	private ParameterverwaltungPK parameterverwaltungPK = null;

	@Column(name = "AENDDAT")
	private Date datumLetzteAenderung = null;

	/*
	 * Parameterwert z. B. j:\absender\hankie\transfer\cs_baur.txt
	 */
	@Column(name = "PARAMWERT")
	private String wert = null;

	@Column(name = "USERNAME")
	private String username = null;

	public Parameterverwaltung() {
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public Date getDatumLetzteAenderung() {
		return datumLetzteAenderung;
	}

	public void setDatumLetzteAenderung(Date datumLetzteAenderung) {
		this.datumLetzteAenderung = datumLetzteAenderung;
	}

	public String getWert() {
		return wert;
	}

	public void setWert(String wert) {
		this.wert = wert;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public ParameterverwaltungPK getParameterverwaltungPK() {
		return parameterverwaltungPK;
	}

	public void setParameterverwaltungPK(
			ParameterverwaltungPK parameterverwaltungPK) {
		this.parameterverwaltungPK = parameterverwaltungPK;
	}

}

package eu.wittgruppe.dias.ui;

import eu.wittgruppe.dias.util.TreeNodeBean;

import javax.swing.*;
import javax.swing.text.Document;

public class ValueTextField extends JTextField {
	
	private TreeNodeBean value = null;
	
	public ValueTextField() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ValueTextField(int columns) {
		super(columns);
		// TODO Auto-generated constructor stub
	}

	public ValueTextField(String text) {
		super(text);
		// TODO Auto-generated constructor stub
	}

	public ValueTextField(String text, int columns) {
		super(text, columns);
		// TODO Auto-generated constructor stub
	}

	public ValueTextField(Document doc, String text, int columns) {
		super(doc, text, columns);
		// TODO Auto-generated constructor stub
	}
		
	
	public String toString() {
		super.toString();
		
		return value.getNodeText();
		
	}

	public TreeNodeBean getValueObject() {
		return value;
	}

	public void setValueObject(TreeNodeBean value) {
		this.value = value;
		if (value!=null) {
			this.setText(value.getNodeText());
		}
		
	}
	
	

}

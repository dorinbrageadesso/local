package eu.wittgruppe.dias.ui;

import eu.wittgruppe.dias.controller.MainWindowController;
import eu.wittgruppe.dias.util.Images;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import witt.josef.uiswing.ui.InfoDialog;
import witt.josef.uiswing.ui.application.MDIApplicationWindow;
import witt.josef.uiswing.ui.application.actions.ActionImpl;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Vector;

@Component
public class MainWindow extends MDIApplicationWindow {

    public static final String SEPARATOR_ACTION = "SEPERATOR";

    @Autowired
    private MainWindowController controller = null;

    private ArtikelSearchAction artikelSearchAction = null;
    private RechnungenSearchAction rechnungenSearchAction = null;
    private KundeMatchAction kundeMatchAction = null;
    private ArtikelCRSSearchAction crsArtikelSearchAction = null;
    private ShowStatistikAction showStatistikAction = null;
    private ExitAction exitAction = null;
    private InfoAction infoAction = null;
    private OpenHelpAction openHelpAction = null;

    public void setController( MainWindowController controller ) {
        this.controller = controller;
    }

    public MainWindowController getController() {
        return controller;
    }

    public void initialize() {
        super.initialize();
        this.artikelSearchAction = new ArtikelSearchAction();
        this.crsArtikelSearchAction = new ArtikelCRSSearchAction();
        this.rechnungenSearchAction = new RechnungenSearchAction();
        this.kundeMatchAction = new KundeMatchAction();
        this.showStatistikAction = new ShowStatistikAction();
        this.exitAction = new ExitAction();
        this.infoAction = new InfoAction();
        this.openHelpAction = new OpenHelpAction();

        setToolbarComponents(createToolBar());
        addMenusAndToolbars();
    }

    @Override
    protected List<JMenu> createMenu() {
        Vector<JMenu> menu = (Vector<JMenu>) super.createMenu();

        JMenu fileMenu = new JMenu("Datei");
        fileMenu.setMnemonic( 'D' );
        fileMenu.insert( showStatistikAction, 0 );
        fileMenu.insert( kundeMatchAction, 0 );
        fileMenu.insert( rechnungenSearchAction, 0 );
        fileMenu.insert( crsArtikelSearchAction, 0 );
        fileMenu.insert( artikelSearchAction, 0 );
        fileMenu.add(new JSeparator());
        fileMenu.add(exitAction);

        menu.add(0, fileMenu);

        JMenu helpMenu = new JMenu("Hilfe");
        helpMenu.setMnemonic('H');
        helpMenu.insert( openHelpAction, 0 );
        helpMenu.add( infoAction );
        menu.add(helpMenu);

        return menu;
    }

    private JButton createButtonForToolBar(ActionImpl action) {
        JButton button = new JButton(action);
        button.setText("");

        return button;
    }
    /*
     * (non-Javadoc)
     * @see witt.application.revis.revis.client.view.ApplicationWindow#createToolBar()
     */
    @Override
    protected List<JComponent> createToolBar() {
        List<JComponent> list = super.createToolBar();

        list.add(createButtonForToolBar(exitAction));
//        list.add(new JSeparator());   // TODO: separate me
        list.add(createButtonForToolBar(artikelSearchAction));
        list.add(createButtonForToolBar(crsArtikelSearchAction));
        list.add(createButtonForToolBar(rechnungenSearchAction));
//        list.add(new JSeparator());   // TODO: separate me
        list.add(createButtonForToolBar(kundeMatchAction));
//        list.add(new JSeparator());   // TODO: separate me
        list.add(createButtonForToolBar(showStatistikAction));

        return list;
    }

    public void onExitApplication() {
        if( showExitConfirmationDialog() == JOptionPane.YES_OPTION ) {
            doExit();
        }
    }

    @Override
    protected void doExit() {
        controller.getDefaultApplication().logOff();
        super.doExit();
    }

    // L I S T E N E R S
    private class ArtikelSearchAction extends ActionImpl {

        public ArtikelSearchAction() {
            super( "Artikelsuche", "Artikelsuche", KeyStroke.getKeyStroke( KeyEvent.VK_A, InputEvent.CTRL_MASK ), 'A', Images.ARTIKEL_SEARCH );
            setSecurityName( "ArtikelSucheAnzeigen" );
            // setupSecurity( g );
        }

        @Override
        public void actionPerformed( ActionEvent e ) {
            controller.showArtikelSearchDialog();
        }
    }

    private class ArtikelCRSSearchAction extends ActionImpl {

        public ArtikelCRSSearchAction() {
            super( "Artikelsuche/CRS", "Artikelsuche/CRS", KeyStroke.getKeyStroke( KeyEvent.VK_C, InputEvent.CTRL_MASK ), 'C', Images.CRS_SEARCH );
            setSecurityName( "ArtikelCrsSucheAnzeigen" );
            // setupSecurity( Dias.getInstance() );
        }

        @Override
        public void actionPerformed( ActionEvent e ) {
            controller.showCRSArtikelSearchDialog();
        }
    }

    private class KundeMatchAction extends ActionImpl {

        public KundeMatchAction() {
            super( "Kunden matchen", "Kunden matchen", KeyStroke.getKeyStroke( KeyEvent.VK_K, InputEvent.CTRL_MASK ), 'K', Images.KUNDE_MATCH );
            setSecurityName( "KundenSucheAnzeigen" );
            // setupSecurity( Dias.getInstance() );
        }

        @Override
        public void actionPerformed( ActionEvent e ) {
            controller.showKundenMatchDialog();
        }
    }

    private class RechnungenSearchAction extends ActionImpl {

        public RechnungenSearchAction() {
            super( "Rechnungssuche", "Rechnungssuche", KeyStroke.getKeyStroke( KeyEvent.VK_R, InputEvent.CTRL_MASK ), 'R', Images.RECHNUNGEN_SEARCH );
            setSecurityName( "KundenrechnungsSucheAnzeigen" );
            // setupSecurity( Dias.getInstance() );
        }

        @Override
        public void actionPerformed( ActionEvent e ) {
            controller.showKundenRechnungenSearchDialog();
        }
    }

    private class ShowStatistikAction extends ActionImpl {

        public ShowStatistikAction() {
            super( "Leistungsziehung", "Leistungsziehung", KeyStroke.getKeyStroke( KeyEvent.VK_L, InputEvent.CTRL_MASK ), 'L', Images.STATISTIK );
            setSecurityName( "StatistikAnzeigen" );
            // setupSecurity( Dias.getInstance() );
        }

        @Override
        public void actionPerformed( ActionEvent e ) {
            controller.showStatistikChooser();
        }
    }

    private class ExitAction extends ActionImpl {

        public ExitAction() {
            super( "Beenden", "Programm beenden", KeyStroke.getKeyStroke( KeyEvent.VK_B, InputEvent.CTRL_MASK ), 'B', Images.EXIT );
            setSecurityName( "Beenden" );
        }

        @Override
        public void actionPerformed( ActionEvent e ) {
            onExitApplication();
        }
    }

    private class OpenHelpAction extends ActionImpl {

        public OpenHelpAction() {
            super( "Hilfethemen", "Hilfethemen", KeyStroke.getKeyStroke( KeyEvent.VK_F1, InputEvent.CTRL_MASK ), 'H', Images.DIAS_HELP );
        }

        @Override
        public void actionPerformed( ActionEvent e ) {
            controller.linkToHelpFile();
        }
    }

    private class InfoAction extends ActionImpl {

        public InfoAction() {
            super( "Info", "Info", KeyStroke.getKeyStroke( 'I', KeyEvent.CTRL_MASK ), 'I', Images.INFO );
        }

        public void actionPerformed( ActionEvent e ) {
            JDialog d = createInfoDialog();
            d.setVisible(true);
        }
    }

    protected JDialog createInfoDialog() {
        InfoDialog d = new InfoDialog( this, "Info", true, controller.getApplicationDetails() );
        centerOverComponent( this, d );

        return d;
    }
}

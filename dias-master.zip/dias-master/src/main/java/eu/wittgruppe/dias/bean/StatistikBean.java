/**
 * 
 */
package eu.wittgruppe.dias.bean;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Mather
 *
 */
public class StatistikBean implements Serializable {

	/**
	 * 
	 */
	public StatistikBean() {				
	}	
	
	private String bedienerNr = null;
	private String vorname = null;
	private String nachname = null;
	private Date erfassungsDatum = null;
	private Date truncErfassungsDatum = null;
	private Long artikelNummer = null;
	private String artikelGroesse = null;
	private Long identKz = null;
	private String identKzString = null;
	private Integer anzahl = null;
	
	public Integer getAnzahl() {
		return anzahl;
	}
	public void setAnzahl(Integer anzahl) {
		this.anzahl = anzahl;
	}
	public String getArtikelGroesse() {
		return artikelGroesse;
	}
	public void setArtikelGroesse(String artikelGroesse) {
		this.artikelGroesse = artikelGroesse;
	}
	public Long getArtikelNummer() {
		return artikelNummer;
	}
	public void setArtikelNummer(Long artikelNummer) {
		this.artikelNummer = artikelNummer;
	}
	
	public Date getErfassungsDatum() {
		return erfassungsDatum;
	}
	public void setErfassungsDatum(Date erfassungdsDatum) {
		this.erfassungsDatum = erfassungdsDatum;
	}
	public Long getIdentKz() {
		return identKz;
	}
	public void setIdentKz(Long identKz) {
		this.identKz = identKz;
	}
	public String getNachname() {
		return nachname;
	}
	public void setNachname(String nachname) {
		this.nachname = nachname;
	}
	public String getVorname() {
		return vorname;
	}
	public void setVorname(String vorname) {
		this.vorname = vorname;
	}
	public String getBedienerNr() {
		return bedienerNr;
	}
	public void setBedienerNr(String bedienerNr) {
		this.bedienerNr = bedienerNr;
	}
	public String getIdentKzString() {
		return identKzString;
	}
	public void setIdentKzString(String identKzString) {
		this.identKzString = identKzString;
	}
	public void setTruncErfassungsDatum(Date erfdat) {		
	
		this.truncErfassungsDatum = erfdat;
	}
	public Date getTruncErfassungsDatum() {		
		
		return truncErfassungsDatum;
	}	
	
	
}

package eu.wittgruppe.dias.domain;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity(name = "Konzernfirma")
@Table(name = "konzernfirma")
public class Konzernfirma implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID")
	@org.hibernate.annotations.GenericGenerator(name = "getId", strategy = "witt.josef.orm.hibernate.IdGenerator")
	@GeneratedValue(generator = "getId")
	private String id = null;


	/*
	 * Postleitzahl Grosskunde
	 */
	@Column(name = "PLZGK")
	private String postleitzahlGrosskunde = null;

	/*
	 * Letztes Aenderungsdatum
	 */
	@Column(name = "LETZTAENDDAT")
	@Temporal(TemporalType.DATE)
	private Date letzteAenderungDatum = null;

	/*
	 * Postfachnummer
	 */
	@Column(name = "POSTFNR")
	private String postfachnummer = null;

	/*
	 * Postfachpostleitzahl
	 */
	@Column(name = "POSTFPLZ")
	private String postfachpostleitzahl = null;

	/*
	 * Postfach Ort
	 */
	@Column(name = "POSTFORT")
	private String postfachOrt = null;

	/*
	 * Bezeichnung der Konzernfirma fuer die entsprechende Anschrift
	 */
	@Column(name = "HRFIRMBEZ")
	private String hrFirmenbezeichnung = null;

	/*
	 * Strassenanschrift ORT
	 */
	@Column(name = "STRANSCHRORT")
	private String strassenanschriftOrt = null;

	/*
	 * Konzernfirmenkennzeichen
	 */
	@Column(name = "FIRMKZKONZ")
	private String konzernfirmenkennzeichen = null;

	/*
	 * Firmenpostleitzahl
	 */
	@Column(name = "PLZ")
	private String firmenpostleitzahl = null;

	/*
	 * HR Postleitzahl
	 */
	@Column(name = "HRPLZ")
	private String hrPostleitzahl = null;

	/*
	 * Firmentelefonnummer KB
	 */
	@Column(name = "TELNRKB")
	private String firmentelefonnummerKb = null;

	/*
	 * Bezeichnung der Konzernfirma fuer die entsprechende Anschrift
	 */
	@Column(name = "FIRMBEZWB")
	private String firmenbezeichnungWerbung = null;

	/*
	 * HR Strasse
	 */
	@Column(name = "HRSTR")
	private String hrStrasse = null;

	/*
	 * Postfachbezeichnung
	 */
	@Column(name = "POSTFBEZ")
	private String postfachbezeichnung = null;

	/*
	 * Firmenstr.
	 */
	@Column(name = "STR")
	private String firmenstrasse = null;

	/*
	 * Strassenanschrift Postleitzahl
	 */
	@Column(name = "STRANSCHRPLZ")
	private String strassenanschriftPostleitzahl = null;

	/*
	 * HR Ort
	 */
	@Column(name = "HRORT")
	private String hrOrt = null;

	@Column(name = "LANDID")
	private String landId = null;

	/*
	 * Firmenort
	 */
	@Column(name = "ORT")
	private String ort = null;

	/*
	 * Firmenbezeichnung
	 */
	@Column(name = "BEZ")
	private String bezeichnung = null;

	/*
	 * Firmentelefaxnummer KB
	 */
	@Column(name = "FAXNRKB")
	private String firmentelefaxnummerKb = null;

	/*
	 * Strassenanschrift Strasse
	 */
	@Column(name = "STRANSCHRSTR")
	private String strassenanschriftStrasse = null;

	/*
	 * Letzter Aenderer
	 */
	@Column(name = "BENUTZERIDLETZTAEND")
	private String benutzerIdLetzterAenderer = null;

	public Konzernfirma() {
	}

	public String getPostleitzahlGrosskunde() {
		return postleitzahlGrosskunde;
	}

	public void setPostleitzahlGrosskunde(String postleitzahlGrosskunde) {
		this.postleitzahlGrosskunde = postleitzahlGrosskunde;
	}

	public Date getLetzteAenderungDatum() {
		return letzteAenderungDatum;
	}

	public void setLetzteAenderungDatum(Date letzteAenderungDatum) {
		this.letzteAenderungDatum = letzteAenderungDatum;
	}

	public String getPostfachnummer() {
		return postfachnummer;
	}

	public void setPostfachnummer(String postfachnummer) {
		this.postfachnummer = postfachnummer;
	}

	public String getPostfachpostleitzahl() {
		return postfachpostleitzahl;
	}

	public void setPostfachpostleitzahl(String postfachpostleitzahl) {
		this.postfachpostleitzahl = postfachpostleitzahl;
	}

	public String getPostfachOrt() {
		return postfachOrt;
	}

	public void setPostfachOrt(String postfachOrt) {
		this.postfachOrt = postfachOrt;
	}

	public String getHrFirmenbezeichnung() {
		return hrFirmenbezeichnung;
	}

	public void setHrFirmenbezeichnung(String hrFirmenbezeichnung) {
		this.hrFirmenbezeichnung = hrFirmenbezeichnung;
	}

	public String getStrassenanschriftOrt() {
		return strassenanschriftOrt;
	}

	public void setStrassenanschriftOrt(String strassenanschriftOrt) {
		this.strassenanschriftOrt = strassenanschriftOrt;
	}

	public String getKonzernfirmenkennzeichen() {
		return konzernfirmenkennzeichen;
	}

	public void setKonzernfirmenkennzeichen(String konzernfirmenkennzeichen) {
		this.konzernfirmenkennzeichen = konzernfirmenkennzeichen;
	}

	public String getFirmenpostleitzahl() {
		return firmenpostleitzahl;
	}

	public void setFirmenpostleitzahl(String firmenpostleitzahl) {
		this.firmenpostleitzahl = firmenpostleitzahl;
	}

	public String getHrPostleitzahl() {
		return hrPostleitzahl;
	}

	public void setHrPostleitzahl(String hrPostleitzahl) {
		this.hrPostleitzahl = hrPostleitzahl;
	}

	public String getFirmentelefonnummerKb() {
		return firmentelefonnummerKb;
	}

	public void setFirmentelefonnummerKb(String firmentelefonnummerKb) {
		this.firmentelefonnummerKb = firmentelefonnummerKb;
	}

	public String getFirmenbezeichnungWerbung() {
		return firmenbezeichnungWerbung;
	}

	public void setFirmenbezeichnungWerbung(String firmenbezeichnungWerbung) {
		this.firmenbezeichnungWerbung = firmenbezeichnungWerbung;
	}

	public String getHrStrasse() {
		return hrStrasse;
	}

	public void setHrStrasse(String hrStrasse) {
		this.hrStrasse = hrStrasse;
	}

	public String getId() {
		return id;
	}

	public String getPostfachbezeichnung() {
		return postfachbezeichnung;
	}

	public void setPostfachbezeichnung(String postfachbezeichnung) {
		this.postfachbezeichnung = postfachbezeichnung;
	}

	public String getFirmenstrasse() {
		return firmenstrasse;
	}

	public void setFirmenstrasse(String firmenstrasse) {
		this.firmenstrasse = firmenstrasse;
	}

	public String getStrassenanschriftPostleitzahl() {
		return strassenanschriftPostleitzahl;
	}

	public void setStrassenanschriftPostleitzahl(
			String strassenanschriftPostleitzahl) {
		this.strassenanschriftPostleitzahl = strassenanschriftPostleitzahl;
	}

	public String getHrOrt() {
		return hrOrt;
	}

	public void setHrOrt(String hrOrt) {
		this.hrOrt = hrOrt;
	}

	public String getLandId() {
		return landId;
	}

	public void setLandId(String landId) {
		this.landId = landId;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getBezeichnung() {
		return bezeichnung;
	}

	public void setBezeichnung(String bezeichnung) {
		this.bezeichnung = bezeichnung;
	}

	public String getFirmentelefaxnummerKb() {
		return firmentelefaxnummerKb;
	}

	public void setFirmentelefaxnummerKb(String firmentelefaxnummerKb) {
		this.firmentelefaxnummerKb = firmentelefaxnummerKb;
	}

	public String getStrassenanschriftStrasse() {
		return strassenanschriftStrasse;
	}

	public void setStrassenanschriftStrasse(String strassenanschriftStrasse) {
		this.strassenanschriftStrasse = strassenanschriftStrasse;
	}

	public String getBenutzerIdLetzterAenderer() {
		return benutzerIdLetzterAenderer;
	}

	public void setBenutzerIdLetzterAenderer(String benutzerIdLetzterAenderer) {
		this.benutzerIdLetzterAenderer = benutzerIdLetzterAenderer;
	}


}

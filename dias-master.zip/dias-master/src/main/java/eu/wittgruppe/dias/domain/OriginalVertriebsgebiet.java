package eu.wittgruppe.dias.domain;

import org.apache.commons.lang.builder.ToStringBuilder;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity(name = "OriginalVertriebsgebiet")
@Table(name = "orig_vt")
public class OriginalVertriebsgebiet implements Serializable {

	private static final long serialVersionUID = 1L;

	/*
	 * Datum der letzten Änderung
	 */
	@Column(name = "AENDDAT")
	@Temporal(TemporalType.DATE)
	private Date aenderungDatum = null;

	/*
	 * Bezeichnung des Artikels
	 */
	@Column(name = "ARTBEZ")
	private String artikelBezeichnung = null;

	/*
	 * 6-stellige Witt-Artikelnummer
	 */
	@Column(name = "ARTNR6")
	private Long artikelNummer6 = null;

	/*
	 * Artikelart z. B. Edelmetall, ...
	 */
	@Column(name = "ARTNR6ART")
	private Long artikelnummerWittArtikel = null;

	@Column(name = "BENUTZERID")
	private String benutzerid = null;

	/*
	 * Ensemblekennzeichen (E=Ensemble)
	 */
	@Column(name = "ENSEMBLEKZ")
	private Long ensemblEinkaufZ = null;

	/*
	 * Exportschlüssel für die Zollabwicklung (nur für Schweiz relevant)
	 */
	@Column(name = "EXPSCHL")
	private Long exportSchluessel = null;

	/*
	 * Fakturierfähigkeit des Artikels (0 = nicht fakturierfähig (d. h. kann
	 * nicht geliefert werden) 1 = fakturierfähig) (( für alle Vertriebsgebiete
	 * relevant))
	 */
	@Column(name = "FAKTFAEHIGKZ")
	private String fakturierungFaehigKennzeichen = null;

	/*
	 * Farbe des Artikels
	 */
	@Column(name = "FARBE")
	private String farbe = null;

	/*
	 * Genehmigungskennzeichen für die Zollabwicklung (0=freier Artikel, 7=
	 * ausverkauft, unabhängig vom Lieferkennzeichen, vorhandenen NAB jedoch
	 * halten, 8=NALI unabhängig vom Lieferkennzeichen, 9=ausverkauft unabhängig
	 * vom Lieferkennzeichen
	 */
	@Column(name = "GENEHMIGKZ")
	private Long genehmigKennzeichen = null;

	@Id
    @org.hibernate.annotations.GenericGenerator(name = "getId", strategy = "witt.josef.orm.hibernate.IdGenerator")
	@GeneratedValue(generator = "getId")
	@Column(name = "ID")
	private String id = null;

	/*
	 * Importschlüssel für die Zollabwicklung (nur für Schweiz relevant).
	 */
	@Column(name = "IMPSCHL")
	private Long importSchluessel = null;

	/*
	 * Mehrwertsteuerkennzeichen
	 */
	@Column(name = "MWSTKZ")
	private Long mehrwertsteuerKennzeichen = null;

	@Column(name = "ORIG_ARTNRID")
	private String originalArtikelNummerId = null;

	/*
	 * Saisonkennzeichen
	 */
	@Column(name = "SAISON")
	private Long saison = null;

	/*
	 * Setnachlass in der entsprechenden Währung
	 */
	@Column(name = "SETNACHLASS")
	private Double setnachlass = null;

	/*
	 * Systemherkunft des Datensatzen "H"=Host, "D"=DB, "Z" = Zolldaten, "K" =
	 * Katalogproduktion
	 */
	@Column(name = "SYSTEMKZ")
	private String systemTemKennzeichen = null;

	/*
	 * Transferkennzeichen fuer Grossrechner z. B. 0=nicht transferiert,
	 * 1=transferiert, aber noch nicht vom Großrechner OK, 2= transferiert und
	 * OK vom HOST, 3=wird nicht transferiert. Defaultwert = 2, ==> kein
	 * Transfer zum HOST
	 */
	@Column(name = "TRANSFERKZ")
	private Long transferKennzeichen = null;

	/*
	 * Benutzernummer des Erfassers
	 */
	@Column(name = "USERNR")
	private Long userNummer = null;

	/*
	 * Vertriebsgebietskennzeichen z. B. F = Frankreich
	 */
	@Column(name = "VERTRGEBIET")
	private String vertriebsgebiet = null;

	/*
	 * Gueltigkeitsdatum (Beginn) des Datensatzes
	 */
	@Column(name = "VONDAT")
	@Temporal(TemporalType.DATE)
	private Date vonDatum = null;

	/*
	 * Interner Code für die Zollabwicklung. Nur für Schweiz relevant. z. B.
	 * Hinweis auf Preisbindung
	 */
	@Column(name = "ZOLLBEM")
	private String zollBemerkung = null;

	/*
	 * Zoll-spezifische Abbildung für Handelrechnung (EUROKATALOG).
	 */
	@Column(name = "ZOLLKATABB")
	private String zollKatalogAbbildung = null;

	/*
	 * Zoll-spezifische Abbildung der neuen Saison für Handelrechnung
	 * (EUROKATALOG ) .
	 */
	@Column(name = "ZOLLKATABBNEUSAI")
	private String zollKatalogAbbildungNEuropaeischeUnionSai = null;

	/*
	 * Zoll-spezifische Katalogseite für Handelrechnung (EUROKATALOG)
	 */
	@Column(name = "ZOLLKATSEITE")
	private Long zollKatalogSeite = null;

	/*
	 * Zoll-spezifische Katalogseite der neuen Saison für Handelrechnung
	 * (EUROKATALOG )
	 */
	@Column(name = "ZOLLKATSEITENEUSAI")
	private Long zollKatalogSeitenEuropaeischeUnionSai = null;

	/*
	 * Zoll-spezifische Katalogart für Handelrechnung (EUROKATALOG)
	 */
	@Column(name = "ZOLLKATTYP")
	private String zollKatalogTyp = null;

	/*
	 * Zoll-spezifische Katalogart der neuen Saison für Handelrechnung
	 * (EUROKATALOG )
	 */
	@Column(name = "ZOLLKATTYPNEUSAI")
	private String zollKatalogTypnEuropaeischeUnionSai = null;

	/*
	 * Zolltarifnummer eines Artikels. Für die Verzollung relevant. Eine
	 * Artikelnummer kann für mehrere Länder die selbe Zolltarifnummer haben.
	 * (Warennummer)
	 */
	@Column(name = "ZOLLTARIFNR")
	private Long zolltarifNummer = null;

	public OriginalVertriebsgebiet() {
	}

	@Override
    public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public Date getAenderungDatum() {
		return aenderungDatum;
	}

	public void setAenderungDatum(Date aenderungDatum) {
		this.aenderungDatum = aenderungDatum;
	}

	public String getArtikelBezeichnung() {
		return artikelBezeichnung;
	}

	public void setArtikelBezeichnung(String artikelBezeichnung) {
		this.artikelBezeichnung = artikelBezeichnung;
	}

	public Long getArtikelNummer6() {
		return artikelNummer6;
	}

	public void setArtikelNummer6(Long artikelNummer6) {
		this.artikelNummer6 = artikelNummer6;
	}

	public Long getArtikelnummerWittArtikel() {
		return artikelnummerWittArtikel;
	}

	public void setArtikelnummerWittArtikel(Long artikelnummerWittArtikel) {
		this.artikelnummerWittArtikel = artikelnummerWittArtikel;
	}

	public String getBenutzerid() {
		return benutzerid;
	}

	public void setBenutzerid(String benutzerid) {
		this.benutzerid = benutzerid;
	}

	public Long getEnsemblEinkaufZ() {
		return ensemblEinkaufZ;
	}

	public void setEnsemblEinkaufZ(Long ensemblEinkaufZ) {
		this.ensemblEinkaufZ = ensemblEinkaufZ;
	}

	public Long getExportSchluessel() {
		return exportSchluessel;
	}

	public void setExportSchluessel(Long exportSchluessel) {
		this.exportSchluessel = exportSchluessel;
	}

	public String getFakturierungFaehigKennzeichen() {
		return fakturierungFaehigKennzeichen;
	}

	public void setFakturierungFaehigKennzeichen(
			String fakturierungFaehigKennzeichen) {
		this.fakturierungFaehigKennzeichen = fakturierungFaehigKennzeichen;
	}

	public String getFarbe() {
		return farbe;
	}

	public void setFarbe(String farbe) {
		this.farbe = farbe;
	}

	public Long getGenehmigKennzeichen() {
		return genehmigKennzeichen;
	}

	public void setGenehmigKennzeichen(Long genehmigKennzeichen) {
		this.genehmigKennzeichen = genehmigKennzeichen;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Long getImportSchluessel() {
		return importSchluessel;
	}

	public void setImportSchluessel(Long importSchluessel) {
		this.importSchluessel = importSchluessel;
	}

	public Long getMehrwertsteuerKennzeichen() {
		return mehrwertsteuerKennzeichen;
	}

	public void setMehrwertsteuerKennzeichen(Long mehrwertsteuerKennzeichen) {
		this.mehrwertsteuerKennzeichen = mehrwertsteuerKennzeichen;
	}

	public String getOriginalArtikelNummerId() {
		return originalArtikelNummerId;
	}

	public void setOriginalArtikelNummerId(String originalArtikelNummerId) {
		this.originalArtikelNummerId = originalArtikelNummerId;
	}

	public Long getSaison() {
		return saison;
	}

	public void setSaison(Long saison) {
		this.saison = saison;
	}

	public Double getSetnachlass() {
		return setnachlass;
	}

	public void setSetnachlass(Double setnachlass) {
		this.setnachlass = setnachlass;
	}

	public String getSystemTemKennzeichen() {
		return systemTemKennzeichen;
	}

	public void setSystemTemKennzeichen(String systemTemKennzeichen) {
		this.systemTemKennzeichen = systemTemKennzeichen;
	}

	public Long getTransferKennzeichen() {
		return transferKennzeichen;
	}

	public void setTransferKennzeichen(Long transferKennzeichen) {
		this.transferKennzeichen = transferKennzeichen;
	}

	public Long getUserNummer() {
		return userNummer;
	}

	public void setUserNummer(Long userNummer) {
		this.userNummer = userNummer;
	}

	public String getVertriebsgebiet() {
		return vertriebsgebiet;
	}

	public void setVertriebsgebiet(String vertriebsgebiet) {
		this.vertriebsgebiet = vertriebsgebiet;
	}

	public Date getVonDatum() {
		return vonDatum;
	}

	public void setVonDatum(Date vonDatum) {
		this.vonDatum = vonDatum;
	}

	public String getZollBemerkung() {
		return zollBemerkung;
	}

	public void setZollBemerkung(String zollBemerkung) {
		this.zollBemerkung = zollBemerkung;
	}

	public String getZollKatalogAbbildung() {
		return zollKatalogAbbildung;
	}

	public void setZollKatalogAbbildung(String zollKatalogAbbildung) {
		this.zollKatalogAbbildung = zollKatalogAbbildung;
	}

	public String getZollKatalogAbbildungNEuropaeischeUnionSai() {
		return zollKatalogAbbildungNEuropaeischeUnionSai;
	}

	public void setZollKatalogAbbildungNEuropaeischeUnionSai(
			String zollKatalogAbbildungNEuropaeischeUnionSai) {
		this.zollKatalogAbbildungNEuropaeischeUnionSai = zollKatalogAbbildungNEuropaeischeUnionSai;
	}

	public Long getZollKatalogSeite() {
		return zollKatalogSeite;
	}

	public void setZollKatalogSeite(Long zollKatalogSeite) {
		this.zollKatalogSeite = zollKatalogSeite;
	}

	public Long getZollKatalogSeitenEuropaeischeUnionSai() {
		return zollKatalogSeitenEuropaeischeUnionSai;
	}

	public void setZollKatalogSeitenEuropaeischeUnionSai(
			Long zollKatalogSeitenEuropaeischeUnionSai) {
		this.zollKatalogSeitenEuropaeischeUnionSai = zollKatalogSeitenEuropaeischeUnionSai;
	}

	public String getZollKatalogTyp() {
		return zollKatalogTyp;
	}

	public void setZollKatalogTyp(String zollKatalogTyp) {
		this.zollKatalogTyp = zollKatalogTyp;
	}

	public String getZollKatalogTypnEuropaeischeUnionSai() {
		return zollKatalogTypnEuropaeischeUnionSai;
	}

	public void setZollKatalogTypnEuropaeischeUnionSai(
			String zollKatalogTypnEuropaeischeUnionSai) {
		this.zollKatalogTypnEuropaeischeUnionSai = zollKatalogTypnEuropaeischeUnionSai;
	}

	public Long getZolltarifNummer() {
		return zolltarifNummer;
	}

	public void setZolltarifNummer(Long zolltarifNummer) {
		this.zolltarifNummer = zolltarifNummer;
	}
}

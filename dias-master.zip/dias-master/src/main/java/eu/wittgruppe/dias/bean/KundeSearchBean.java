package eu.wittgruppe.dias.bean;

import java.io.Serializable;

public class KundeSearchBean implements Serializable{

	private String kdnr = null;
	private String kdfirmBez = null;
	private String kdfirmId = null;
	private String vorName = null;
	private String nachName = null;
	private String strasse = null;
	private String hausNr = null;
	private String hausNrZusatz = null;
	private String plz = null;
	private String ort = null;	 
	
	public KundeSearchBean() {
		super();		
	}

	public String getHausNr() {
		return hausNr;
	}

	public void setHausNr(String hausNr) {
		this.hausNr = hausNr;
	}

	public String getHausNrZusatz() {
		return hausNrZusatz;
	}

	public void setHausNrZusatz(String hausNrZusatz) {
		this.hausNrZusatz = hausNrZusatz;
	}

	public String getKdfirmBez() {
		return kdfirmBez;
	}

	public void setKdfirmBez(String kdfirmBez) {
		this.kdfirmBez = kdfirmBez;
	}

	public String getKdfirmId() {
		return kdfirmId;
	}

	public void setKdfirmId(String kdfirmId) {
		this.kdfirmId = kdfirmId;
	}

	public String getKdnr() {
		return kdnr;
	}

	public void setKdnr(String kdnr) {
		this.kdnr = kdnr;
	}

	public String getNachName() {
		return nachName;
	}

	public void setNachName(String nachName) {
		this.nachName = nachName;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getPlz() {
		return plz;
	}

	public void setPlz(String plz) {
		this.plz = plz;
	}

	public String getStrasse() {
		return strasse;
	}

	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}

	public String getVorName() {
		return vorName;
	}

	public void setVorName(String vorName) {
		this.vorName = vorName;
	}


}

package eu.wittgruppe.dias.domain;

import org.apache.commons.lang.StringUtils;

import jakarta.persistence.*;
import java.io.Serializable;

import static jakarta.persistence.FetchType.LAZY;


@Entity(name = "Kundenfirma")
@Table(name = "kundenfirma")
public class Kundenfirma implements Serializable {

	@Column(name = "kdfirmkz")
	private Long kundenfirmenKennzeichen;

	@Column(name = "email2")
	private String email2;

	@ManyToOne(fetch = LAZY)
    @JoinColumn(name = "KONZERNFIRMAID")
	private Konzernfirma konzernfirma;

	@Id
	@Column(name = "id")
	private String id;

	@Column(name = "kdfirmbez")
	private String bezeichnung;

	@Column(name = "firmkurz1")
	private String firmenKurzbezeichnung1;

	@Column(name = "firmkurz3")
	private String firmenKurzbezeichnung3;

	@ManyToOne(fetch = LAZY)
	@JoinColumn(name = "firmkz", referencedColumnName = "firmkz")
	private Bestandsfirma bestandsfirma;

	@Column(name = "vertrgebiet")
	private String vertriebsgebiet;

	@Column(name = "firmkurz2")
	private String firmenKurzbezeichnung2;

	@Column(name = "email1")
	private String email1;

	@ManyToOne(fetch = LAZY)
	@JoinColumn(name = "landid")
	private Land land;

	
	public String getFormattedKundenfirma() {
		return StringUtils.leftPad(getKundenfirmenKennzeichen().toString(), 2,
				'0')
				+ " | " + getFirmenKurzbezeichnung3();
	}




	
	private static final long serialVersionUID = 1L;

	public Kundenfirma() {
		super();
	}

	public String toString() {
		return getBezeichnung();
	}

	public Long getKundenfirmenKennzeichen() {
		return kundenfirmenKennzeichen;
	}

	public void setKundenfirmenKennzeichen(Long kundenfirmenKennzeichen) {
		this.kundenfirmenKennzeichen = kundenfirmenKennzeichen;
	}

	public String getEmail2() {
		return email2;
	}

	public void setEmail2(String email2) {
		this.email2 = email2;
	}

	public String getId() {
		return id;
	}

	public String getBezeichnung() {
		return bezeichnung;
	}

	public void setBezeichnung(String bezeichnung) {
		this.bezeichnung = bezeichnung;
	}

	public String getFirmenKurzbezeichnung1() {
		return firmenKurzbezeichnung1;
	}

	public void setFirmenKurzbezeichnung1(String firmenKurzbezeichnung1) {
		this.firmenKurzbezeichnung1 = firmenKurzbezeichnung1;
	}

	public String getFirmenKurzbezeichnung3() {
		return firmenKurzbezeichnung3;
	}

	public void setFirmenKurzbezeichnung3(String firmenKurzbezeichnung3) {
		this.firmenKurzbezeichnung3 = firmenKurzbezeichnung3;
	}

	public Bestandsfirma getBestandsfirma() {
		return bestandsfirma;
	}

	public void setBestandsfirma(Bestandsfirma bestandsfirma) {
		this.bestandsfirma = bestandsfirma;
	}

	public String getVertriebsgebiet() {
		return vertriebsgebiet;
	}

	public void setVertriebsgebiet(String vertriebsgebiet) {
		this.vertriebsgebiet = vertriebsgebiet;
	}

	public String getFirmenKurzbezeichnung2() {
		return firmenKurzbezeichnung2;
	}

	public void setFirmenKurzbezeichnung2(String firmenKurzbezeichnung2) {
		this.firmenKurzbezeichnung2 = firmenKurzbezeichnung2;
	}

	public String getEmail1() {
		return email1;
	}

	public void setEmail1(String email1) {
		this.email1 = email1;
	}

	public Land getLand() {
		return land;
	}

	public void setLand(Land land) {
		this.land = land;
	}

	public void setKonzernfirma(Konzernfirma konzernfirma) {
		this.konzernfirma = konzernfirma;
	}

	public Konzernfirma getKonzernfirma() {
		return konzernfirma;
	}



}

package eu.wittgruppe.dias.bean;

import java.io.Serializable;

public class ErsatzartikelBean implements Serializable{
	
	private static final long serialVersionUID = -1425180188350523390L;

	private Long artikelnummer = null;
	private String bezeichnung = null;
	private String farbe = null;
	
	public ErsatzartikelBean() {
		
	}
	
	public ErsatzartikelBean(Long artikelnummer, String bezeichnung, String farbe){
		
		this.artikelnummer = artikelnummer;
		this.bezeichnung = bezeichnung;
		this.farbe = farbe;
	}

	
	public Long getArtikelnummer() {
		return artikelnummer;
	}

	public void setArtikelnummer(Long artikelnummer) {
		this.artikelnummer = artikelnummer;
	}

	public String getBezeichnung() {
		return bezeichnung;
	}

	public void setBezeichnung(String bezeichnung) {
		this.bezeichnung = bezeichnung;
	}

	public String getFarbe() {
		return farbe;
	}

	public void setFarbe(String farbe) {
		this.farbe = farbe;
	}
}

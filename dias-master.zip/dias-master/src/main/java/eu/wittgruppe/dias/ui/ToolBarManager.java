/*
 * Created on 17.11.2005
 */
package eu.wittgruppe.dias.ui;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.io.Serializable;
import java.util.Collection;
import java.util.Vector;

/**
 * ToolbarManager verwaltet die einzlnen Actions die in der ToolBar verwendet 
 * werden 
 *
 * @see witt.josef.ui.ApplicationWindow
 * @author ulrkle
 */
public class ToolBarManager implements Serializable {
    //Erkennungskennzeichen für einen Seperator
    //Seperator werden als Actions abgelegt
    public static final String SEPERATOR_ACTION = "SEPERATOR";
    
    private Vector actions = new Vector();
    private Vector actionsWithSeperators = new Vector();
    
    public ToolBarManager() {}
    
    public void addAction( Action action ) {
        actions.add( action );
        actionsWithSeperators.add( action );
    }
    
    public void addSeperator() {
        actionsWithSeperators.add( new SeperatorAction() );
    }
    
    public Action getAction( int index ) {
        return ( Action )actions.get( index );
    }
    
    public boolean removeAction( Action action ) {
        return actions.remove( action ) && actionsWithSeperators.remove( action );
    }
    
    public void removeAction( int index ) {
        Action a = ( Action )actions.remove( index );
        actionsWithSeperators.remove( a );
    }

    public Collection getActions() {
        return actions;
    }
    
    protected Collection getActionsWithSeperators() {
        return actionsWithSeperators;
    }
    
    private class SeperatorAction extends AbstractAction {
        
        public SeperatorAction() {
            putValue( SEPERATOR_ACTION, Boolean.TRUE );
        }

        public void actionPerformed( ActionEvent e ) {}
    }
}

package eu.wittgruppe.dias.domain;

import org.apache.commons.lang.builder.ToStringBuilder;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.sql.Date;

@Entity(name = "PersonAnrede")
@Table(name = "persanrede")
public class PersonAnrede implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "ANR")
	private String anrede = null;

	@Column(name = "ANRKZ")
	private String anredeKennzeichen = null;

	@Id
	private String id = null;

	@Column(name = "LETZTAENDDAT")
	private Date letztesAenderungsdatum = null;

	public PersonAnrede() {
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public String getAnrede() {
		return anrede;
	}

	public void setAnrede(String anrede) {
		this.anrede = anrede;
	}

	public String getAnredeKennzeichen() {
		return anredeKennzeichen;
	}

	public void setAnredeKennzeichen(String anredeKennzeichen) {
		this.anredeKennzeichen = anredeKennzeichen;
	}

	public String getId() {
		return id;
	}

	public Date getLetztesAenderungsdatum() {
		return letztesAenderungsdatum;
	}

	public void setLetztesAenderungsdatum(Date letztesAenderungsdatum) {
		this.letztesAenderungsdatum = letztesAenderungsdatum;
	}

}
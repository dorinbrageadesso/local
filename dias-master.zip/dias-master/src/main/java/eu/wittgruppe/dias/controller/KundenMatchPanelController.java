/**
 * 
 */
package eu.wittgruppe.dias.controller;

import eu.wittgruppe.core.customersearch.transfer.request.RequestParameterNames;
import eu.wittgruppe.core.customersearch.transfer.response.UniservResult;
import eu.wittgruppe.core.customersearch.transfer.response.UniservResultContent;
import eu.wittgruppe.dias.bean.KundeSearchBean;
import eu.wittgruppe.dias.service.DiasService;
import eu.wittgruppe.dias.ui.KundenMatchPanel;
import eu.wittgruppe.dias.ui.WaitView;
import eu.wittgruppe.dias.util.Images;
import eu.wittgruppe.enumerations.KundenfirmaEnum;
//import eu.wittgruppe.uniserv.client.UniservClientException;
//import eu.wittgruppe.uniserv.client.transfer.PersonSuche;
//import eu.wittgruppe.uniserv.client.transfer.SearchResult;
//import eu.wittgruppe.uniserv.client.transfer.UniservPerson;
import foxtrot.Job;
import foxtrot.Worker;
import lombok.extern.slf4j.Slf4j;
import witt.josef.uiswing.ui.UIUtils;

import javax.swing.*;
import java.util.*;

/**
 * @author Mather
 */
@Slf4j
public class KundenMatchPanelController {

    private MainWindowController parentController = null;

    private KundenMatchPanel matchPanel = null;

    public DiasService getDiasService() {
        return parentController.getDiasService();
    }

    public KundenMatchPanelController( MainWindowController parentController ) {
        super();
        this.parentController = parentController;
        this.matchPanel = new KundenMatchPanel( this );
    }

    public KundenMatchPanel getMatchPanel() {
        return matchPanel;
    }

    public Collection searchKunden( final String vorName, final String nachName, final String strasse, final Long hsnr, final String plz, final String ort ) {

       Collection searchResult = null;
        parentController.getMainWindow().setStatusTextLeft( "suche..." );

        WaitView waitView = new WaitView( parentController.getMainWindow() );
        UIUtils.centerOverComponent( parentController.getMainWindow(), waitView );

        waitView.setVisible( true );
        //Collection resultCol = null;
        //Collection personenIdCol = new ArrayList();
        searchResult = ( Collection )Worker.post( new Job() {

            @Override
            public Object run() {

                String languagePool = "DE";
                Vector<String> uniservPersonen = new Vector<>();
                KundenfirmaEnum[] firmen = KundenfirmaEnum.values();

                try {
                    //KundenfirmaEnum kundenFirma = firmen[i];
                    Map<String, String> searchParameter = new HashMap<>();
                    searchParameter.put(RequestParameterNames.FIRSTNAME.getName(), vorName);
                    searchParameter.put(RequestParameterNames.LASTNAME.getName(), nachName);
                    searchParameter.put(RequestParameterNames.ZIP.getName(), plz);
                    searchParameter.put(RequestParameterNames.STREET.getName(), strasse);
                    searchParameter.put(RequestParameterNames.CITY.getName(), ort);
                    //searchParameter.put(RequestParameterNames.HOUSE_NUMBER.getName(), hausnummer);
                    searchParameter.put(RequestParameterNames.LANGUAGE_POOL.getName(), languagePool);
                    searchParameter.put(RequestParameterNames.TYPE.getName(), "K");
                    //searchParameter.put(RequestParameterNames.COMPANY_ID.getName(), kundenFirma.getId());
                    UniservResult uniservResult;
                    uniservResult = parentController.getCustomersearchRestClient().operations().searchIdentities(searchParameter);
                    for( UniservResultContent uniservIdentity : uniservResult.content) {
                        uniservPersonen.add( uniservIdentity.databaseReference );
                        log.debug("Uniserv Result: " +  uniservIdentity.databaseReference + " => " +  uniservIdentity.lastname +  ", " + uniservIdentity.firstname );
                    }
                    String errorText;
                    // Fehler/Warnung bei Uniserv-Suche aufgetreten oder fehlende Parameter
                    // Nur ein Fehler wird zurueckgeliefert. Gehe durch die Hierarchie ...
                    if( uniservResult.info.size() > 0 && uniservResult.info.get(0).level.equals("ERROR")) {
                        errorText = uniservResult.info.get(0).description;
                    }else if( uniservResult.info.size() > 0 && uniservResult.info.get(0).level.equals("WARN")) {
                        errorText = uniservResult.info.get(0).description;
                    }
                } catch( Exception ce ) {
                    log.debug("Fehler bei Uniserv-Suche! ", ce);
                }
                

                int resultSize = 0;
                Collection resultCollecction = null;
                if( uniservPersonen != null && uniservPersonen.size() > 0 ) {
                    log.debug("uniservPersonen Size gesamt: " +  uniservPersonen.size());
                    resultCollecction = getDiasService().sucheKundenMitAnschrift( uniservPersonen );
                    resultSize = resultCollecction.size();
                } else {
                    JOptionPane.showMessageDialog( parentController.getMainWindow(), "Es wurden keine Kunden gefunden!", "Kundensuche", JOptionPane.INFORMATION_MESSAGE );
                }

                parentController.getMainWindow().setStatusTextLeft( Integer.toString( resultSize ) + " Kunden gefunden" );
                log.debug(Integer.toString( resultSize ) + " Kunden gefunden" );
                eu.wittgruppe.dias.ui.UIUtils.clearFillSortTable( matchPanel.getKundeTable(), matchPanel.getTableModel(), resultCollecction );
                
                return resultCollecction;
            }
        } );

        waitView.setVisible( false );
        return searchResult;
    }

    public KundeSearchBean getSelectedSearchBean() {

        KundeSearchBean selectedBean = null;

        int selectedRow = matchPanel.getKundeTable().getSelectedRow();

        if( selectedRow != -1 ) {
            selectedBean = ( KundeSearchBean )matchPanel.getKundeTable().getValueAt( selectedRow, 0 );
        } else if( matchPanel.getKundeTable().getRowCount() == 0 ) {
            JOptionPane.showMessageDialog( parentController.getMainWindow(), "Keine Kunden im aktuellen Suchergebnis!", "Kundenauswahl", JOptionPane.WARNING_MESSAGE );
        } else {
            JOptionPane.showMessageDialog( parentController.getMainWindow(), "Kein Kunde ausgewählt. Bitte einen auswählen!", "Kundenauswahl", JOptionPane.WARNING_MESSAGE );
        }

        return selectedBean;
    }

    public void showDialog() {

        final JInternalFrame kundenMatchFrame = parentController.getMainWindow().addMDIWindow( matchPanel, "Kunden matchen", true, true, true, true, null, 0, 0 );

        parentController.getMainWindow().setStatusTextLeft( "" );
        kundenMatchFrame.setFrameIcon( Images.KUNDE_MATCH );
        matchPanel.getVornameTextField().requestFocus();
        SwingUtilities.invokeLater( new Runnable() {
            @Override
            public void run() {
                try {
                    kundenMatchFrame.setMaximum( true );
                } catch( Exception e ) {
                    log.error( "Fehler beim Maximieren des KundenRechnungenFrame", e );
                }
            }
        } );
    }

}

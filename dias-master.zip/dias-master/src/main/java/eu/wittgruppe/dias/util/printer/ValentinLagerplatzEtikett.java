package eu.wittgruppe.dias.util.printer;


import witt.josef.printer.valentin.Etikett;

public class ValentinLagerplatzEtikett implements Etikett {
	
	private String artikelBezeichnung = null;
	private String artikelFarbe = null;
	private String artikelGroesse = null;
	private String sortKennzeichen = null;
	private Long artikelNummer = null;
	private String bestFirmKzBez = null;
	private Integer bedienerNummer = null;	
	private String lagerKoord = null;
	private Long mengeCm = null;
	
	public ValentinLagerplatzEtikett(String artikelBezeichnung, String artikelFarbe, 
									 String artikelGroesse, String sortKennzeichen, 
									 String bestFirmKzBez, Long artikelNummer, 
									 Integer bedienerNummer, String koord,
									 Long mengeCm) {
		
		this.artikelBezeichnung = artikelBezeichnung;
		this.artikelFarbe = artikelFarbe;
		this.artikelGroesse = artikelGroesse;
		this.sortKennzeichen = sortKennzeichen;
		this.artikelNummer = artikelNummer;
		this.bestFirmKzBez = bestFirmKzBez;
		this.bedienerNummer = bedienerNummer;
		this.mengeCm = mengeCm;
		this.lagerKoord = koord;
	}

	public String getArtikelBezeichnung() {
		return artikelBezeichnung;
	}

	public void setArtikelBezeichnung(String artikelBezeichnung) {
		this.artikelBezeichnung = artikelBezeichnung;
	}

	public String getArtikelFarbe() {
		return artikelFarbe;
	}

	public void setArtikelFarbe(String artikelFarbe) {
		this.artikelFarbe = artikelFarbe;
	}

	public String getArtikelGroesse() {
		return artikelGroesse;
	}

	public void setArtikelGroesse(String artikelGroesse) {
		this.artikelGroesse = artikelGroesse;
	}

	public Long getArtikelNummer() {
		return artikelNummer;
	}

	public void setArtikelNummer(Long artikelNummer) {
		this.artikelNummer = artikelNummer;
	}

	public String getSortKennzeichen() {
		return sortKennzeichen;
	}

	public void setSortKennzeichen(String sortKennzeichen) {
		this.sortKennzeichen = sortKennzeichen;
	}

	public Integer getBedienerNummer() {
		return bedienerNummer;
	}

	public void setBedienerNummer(Integer bedienerNummer) {
		this.bedienerNummer = bedienerNummer;
	}

	public String getBestFirmKzBez() {
		return bestFirmKzBez;
	}

	public void setBestFirmKz(String bestFirmKz) {
		this.bestFirmKzBez = bestFirmKz;
	}

	public String getFormattedLagerKoord() {
		return lagerKoord;
	}

	public void setLagerKoord(String lagerKoord) {
		this.lagerKoord = lagerKoord;
	}

	public Long getMengeCm() {
		return mengeCm;
	}

	public void setMengeCm(Long mengeCm) {
		this.mengeCm = mengeCm;
	}

}

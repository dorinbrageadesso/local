/**
 * 
 */
package eu.wittgruppe.dias.bean;

import eu.wittgruppe.dias.domain.Benutzer;
import eu.wittgruppe.dias.domain.Kundenfirma;
import eu.wittgruppe.dias.domain.Lieferkennzeichen;
import eu.wittgruppe.dias.domain.Saison;

import java.io.Serializable;
import java.util.Calendar;

/**
 * @author Wolste
 *
 */
public class KunderechnungspositionBean implements Serializable {
 
static final long serialVersionUID = -1L;

	private String Artikelbezeichnung;
	private String Artikelgroesse;
	private String ArtikelgruppeCrossselling;
	private Long ArtikelnummerWitt;
	private Long ArtikelnummerWittCrossselling;
	private Long ArtikelnummerWittErsatz;
	private String Auftragspositionidentnummer;
	private Double Bestellbetrag;
	private Long Bestellmenge;
	private Long BestellteArtikelnummerWitt;
	private String Crossellingartikelkennzeichen;
	private Long EinspeichertagNALI;
	private Long Empfehlungsartkennzeichen;
	private Long Ersatzartikelnummer;
	private String Farbe;
	private Long Fehlerkennzeichen;
	private String Flexkennzeichen;
	private Long GOLDTransferkennzeichen;
	private String Grossstueckkennzeichen;
	private Long Gutschriftbelegnummer;
	private String Gutschriftkennzeichen;
	private Long Gutschriftmenge;
	private Long Gutschriftwoche;
	private String Haengekennzeichen;
	private Long HermesPaketnummer;
	private Long HKNummerzaehler;
	private String Id;
	private String KatalogtypCrossselling;
	private Kundenfirma Kundenfirma;
	private Long Kundennummer;
	private Long KundennummerCrossselling;
	private KundenrechnungskopfBean KundenrechnungskopfBean;
	private Long Lagerort;
	private String Lagerortbezeichnung;
	private Calendar LetztesAenderungsdatum;
	private eu.wittgruppe.dias.domain.Lieferkennzeichen Lieferkennzeichen;
	private Long Mappennummer;
	private Long Mengeneinheit;
	private Long NALIKennzeichen;
	private Long NALIWoche;
	private Long Paketkennzeichen;
	private Long Paketnummer;
	private Long Positionsnummer;
	private Long PositionsnummerCrossselling;
	private String Promotionnummer;
	private String PromotionnummerCrossselling;
	private Long Ratenkennzeichen;
	private Calendar Rechnungsdatum;
	private String Rechnungskennzeichen;
	private Long Rechnungsnummer;
	private Long Retouregrund;
	private Benutzer RetouregrunderfassungBenutzer;
	private Calendar Retouregrunderfassungsdatum;
	private Long Retoureschluessel;
	private String Ruckzuckkennzeichen;
	private eu.wittgruppe.dias.domain.Saison Saison;
	private Long Setartikelnummerkennzeichen;
	private Long Telefonkennzeichen;
	private Long Valutakennzeichen;
	private String WarengruppeCrossselling;
	private String Wertstueckkennzeichen;

public KunderechnungspositionBean() {
}

public String getArtikelbezeichnung() {
	return this.Artikelbezeichnung;
}

public String getArtikelgroesse() {
	return this.Artikelgroesse;
}

public String getArtikelgruppeCrossselling() {
	return this.ArtikelgruppeCrossselling;
}

public Long getArtikelnummerWitt() {
	return this.ArtikelnummerWitt;
}

public Long getArtikelnummerWittCrossselling() {
	return this.ArtikelnummerWittCrossselling;
}

public Long getArtikelnummerWittErsatz() {
	return this.ArtikelnummerWittErsatz;
}

public String getAuftragspositionidentnummer() {
	return this.Auftragspositionidentnummer;
}

public Double getBestellbetrag() {
	return this.Bestellbetrag;
}

public Long getBestellmenge() {
	return this.Bestellmenge;
}

public Long getBestellteArtikelnummerWitt() {
	return this.BestellteArtikelnummerWitt;
}

public String getCrossellingartikelkennzeichen() {
	return this.Crossellingartikelkennzeichen;
}

public Long getEinspeichertagNALI() {
	return this.EinspeichertagNALI;
}

public Long getEmpfehlungsartkennzeichen() {
	return this.Empfehlungsartkennzeichen;
}

public Long getErsatzartikelnummer() {
	return this.Ersatzartikelnummer;
}

public String getFarbe() {
	return this.Farbe;
}

public Long getFehlerkennzeichen() {
	return this.Fehlerkennzeichen;
}

public String getFlexkennzeichen() {
	return this.Flexkennzeichen;
}

public Long getGOLDTransferkennzeichen() {
	return this.GOLDTransferkennzeichen;
}

public String getGrossstueckkennzeichen() {
	return this.Grossstueckkennzeichen;
}

public Long getGutschriftbelegnummer() {
	return this.Gutschriftbelegnummer;
}

public String getGutschriftkennzeichen() {
	return this.Gutschriftkennzeichen;
}

public Long getGutschriftmenge() {
	return this.Gutschriftmenge;
}

public Long getGutschriftwoche() {
	return this.Gutschriftwoche;
}

public Long getHKNummerzaehler() {
	return this.HKNummerzaehler;
}

public String getHaengekennzeichen() {
	return this.Haengekennzeichen;
}

public Long getHermesPaketnummer() {
	return this.HermesPaketnummer;
}

public String getId() {
	return this.Id;
}

public String getKatalogtypCrossselling() {
	return this.KatalogtypCrossselling;
}

public Kundenfirma getKundenfirma() {
	return this.Kundenfirma;
}

public Long getKundennummer() {
	return this.Kundennummer;
}

public Long getKundennummerCrossselling() {
	return this.KundennummerCrossselling;
}

public KundenrechnungskopfBean getKundenrechnungskopfBean() {
	return this.KundenrechnungskopfBean;
}

public Long getLagerort() {
	return this.Lagerort;
}

public String getLagerortbezeichnung() {
	return this.Lagerortbezeichnung;
}

public Calendar getLetztesAenderungsdatum() {
	return this.LetztesAenderungsdatum;
}

public Lieferkennzeichen getLieferkennzeichen() {
	return this.Lieferkennzeichen;
}

public Long getMappennummer() {
	return this.Mappennummer;
}

public Long getMengeneinheit() {
	return this.Mengeneinheit;
}

public Long getNALIKennzeichen() {
	return this.NALIKennzeichen;
}

public Long getNALIWoche() {
	return this.NALIWoche;
}

public Long getPaketkennzeichen() {
	return this.Paketkennzeichen;
}

public Long getPaketnummer() {
	return this.Paketnummer;
}

public Long getPositionsnummer() {
	return this.Positionsnummer;
}

public Long getPositionsnummerCrossselling() {
	return this.PositionsnummerCrossselling;
}

public String getPromotionnummer() {
	return this.Promotionnummer;
}

public String getPromotionnummerCrossselling() {
	return this.PromotionnummerCrossselling;
}

public Long getRatenkennzeichen() {
	return this.Ratenkennzeichen;
}

public Calendar getRechnungsdatum() {
	return this.Rechnungsdatum;
}

public String getRechnungskennzeichen() {
	return this.Rechnungskennzeichen;
}

public Long getRechnungsnummer() {
	return this.Rechnungsnummer;
}

public Long getRetouregrund() {
	return this.Retouregrund;
}

public Benutzer getRetouregrunderfassungBenutzer() {
	return this.RetouregrunderfassungBenutzer;
}

public Calendar getRetouregrunderfassungsdatum() {
	return this.Retouregrunderfassungsdatum;
}

public Long getRetoureschluessel() {
	return this.Retoureschluessel;
}

public String getRuckzuckkennzeichen() {
	return this.Ruckzuckkennzeichen;
}

public Saison getSaison() {
	return this.Saison;
}

public Long getSetartikelnummerkennzeichen() {
	return this.Setartikelnummerkennzeichen;
}

public Long getTelefonkennzeichen() {
	return this.Telefonkennzeichen;
}

public Long getValutakennzeichen() {
	return this.Valutakennzeichen;
}

public String getWarengruppeCrossselling() {
	return this.WarengruppeCrossselling;
}

public String getWertstueckkennzeichen() {
	return this.Wertstueckkennzeichen;
}

public void setArtikelbezeichnung(String Artikelbezeichnung) {
	this.Artikelbezeichnung = Artikelbezeichnung;
}

public void setArtikelgroesse(String Artikelgroesse) {
	this.Artikelgroesse = Artikelgroesse;
}

public void setArtikelgruppeCrossselling(String ArtikelgruppeCrossselling) {
	this.ArtikelgruppeCrossselling = ArtikelgruppeCrossselling;
}

public void setArtikelnummerWitt(Long ArtikelnummerWitt) {
	this.ArtikelnummerWitt = ArtikelnummerWitt;
}

public void setArtikelnummerWittCrossselling(Long ArtikelnummerWittCrossselling) {
	this.ArtikelnummerWittCrossselling = ArtikelnummerWittCrossselling;
}

public void setArtikelnummerWittErsatz(Long ArtikelnummerWittErsatz) {
	this.ArtikelnummerWittErsatz = ArtikelnummerWittErsatz;
}

public void setAuftragspositionidentnummer(String Auftragspositionidentnummer) {
	this.Auftragspositionidentnummer = Auftragspositionidentnummer;
}

public void setBestellbetrag(Double Bestellbetrag) {
	this.Bestellbetrag = Bestellbetrag;
}

public void setBestellmenge(Long Bestellmenge) {
	this.Bestellmenge = Bestellmenge;
}

public void setBestellteArtikelnummerWitt(Long BestellteArtikelnummerWitt) {
	this.BestellteArtikelnummerWitt = BestellteArtikelnummerWitt;
}

public void setCrossellingartikelkennzeichen(String Crossellingartikelkennzeichen) {
	this.Crossellingartikelkennzeichen = Crossellingartikelkennzeichen;
}

public void setETBereichCrossselling(String aString) {
	// Body von Methode hier eingeben.
}

public void setEinspeichertagNALI(Long EinspeichertagNALI) {
	this.EinspeichertagNALI = EinspeichertagNALI;
}

public void setEmpfehlungsartkennzeichen(Long Empfehlungsartkennzeichen) {
	this.Empfehlungsartkennzeichen = Empfehlungsartkennzeichen;
}

public void setErsatzartikelnummer(Long Ersatzartikelnummer) {
	this.Ersatzartikelnummer = Ersatzartikelnummer;
}

public void setFarbe(String Farbe) {
	this.Farbe = Farbe;
}

public void setFehlerkennzeichen(Long Fehlerkennzeichen) {
	this.Fehlerkennzeichen = Fehlerkennzeichen;
}

public void setFlexkennzeichen(String Flexkennzeichen) {
	this.Flexkennzeichen = Flexkennzeichen;
}

public void setGOLDTransferkennzeichen(Long GOLDTransferkennzeichen) {
	this.GOLDTransferkennzeichen = GOLDTransferkennzeichen;
}

public void setGrossstueckkennzeichen(String Grossstueckkennzeichen) {
	this.Grossstueckkennzeichen = Grossstueckkennzeichen;
}

public void setGutschriftbelegnummer(Long Gutschriftbelegnummer) {
	this.Gutschriftbelegnummer = Gutschriftbelegnummer;
}

public void setGutschriftkennzeichen(String Gutschriftkennzeichen) {
	this.Gutschriftkennzeichen = Gutschriftkennzeichen;
}

public void setGutschriftmenge(Long Gutschriftmenge) {
	this.Gutschriftmenge = Gutschriftmenge;
}

public void setGutschriftwoche(Long Gutschriftwoche) {
	this.Gutschriftwoche = Gutschriftwoche;
}

public void setHKNummerzaehler(Long HKNummerzaehler) {
	this.HKNummerzaehler = HKNummerzaehler;
}

public void setHaengekennzeichen(String Haengekennzeichen) {
	this.Haengekennzeichen = Haengekennzeichen;
}

public void setHermesPaketnummer(Long HermesPaketnummer) {
	this.HermesPaketnummer = HermesPaketnummer;
}

public void setId(String Id) {
	this.Id = Id;
}

public void setKatalogtypCrossselling(String KatalogtypCrossselling) {
	this.KatalogtypCrossselling = KatalogtypCrossselling;
}

public void setKundenfirma(Kundenfirma Kundenfirma) {
	this.Kundenfirma = Kundenfirma;
}

public void setKundennummer(Long Kundennummer) {
	this.Kundennummer = Kundennummer;
}

public void setKundennummerCrossselling(Long KundennummerCrossselling) {
	this.KundennummerCrossselling = KundennummerCrossselling;
}

public void setKundenrechnungskopfBean(KundenrechnungskopfBean KundenrechnungskopfBean) {
	this.KundenrechnungskopfBean = KundenrechnungskopfBean;
}

public void setLagerort(Long Lagerort) {
	this.Lagerort = Lagerort;
}

public void setLagerortbezeichnung(String Lagerortbezeichnung) {
	this.Lagerortbezeichnung = Lagerortbezeichnung;
}

public void setLetztesAenderungsdatum(Calendar LetztesAenderungsdatum) {
	this.LetztesAenderungsdatum = LetztesAenderungsdatum;
}

public void setLieferkennzeichen(Lieferkennzeichen Lieferkennzeichen) {
	this.Lieferkennzeichen = Lieferkennzeichen;
}

public void setMappennummer(Long Mappennummer) {
	this.Mappennummer = Mappennummer;
}

public void setMengeneinheit(Long Mengeneinheit) {
	this.Mengeneinheit = Mengeneinheit;
}

public void setNALIKennzeichen(Long NALIKennzeichen) {
	this.NALIKennzeichen = NALIKennzeichen;
}

public void setNALIWoche(Long NALIWoche) {
	this.NALIWoche = NALIWoche;
}

public void setPaketkennzeichen(Long Paketkennzeichen) {
	this.Paketkennzeichen = Paketkennzeichen;
}

public void setPaketnummer(Long Paketnummer) {
	this.Paketnummer = Paketnummer;
}

public void setPositionsnummer(Long Positionsnummer) {
	this.Positionsnummer = Positionsnummer;
}

public void setPositionsnummerCrossselling(Long PositionsnummerCrossselling) {
	this.PositionsnummerCrossselling = PositionsnummerCrossselling;
}

public void setPromotionnummer(String Promotionnummer) {
	this.Promotionnummer = Promotionnummer;
}

public void setPromotionnummerCrossselling(String PromotionnummerCrossselling) {
	this.PromotionnummerCrossselling = PromotionnummerCrossselling;
}

public void setRatenkennzeichen(Long Ratenkennzeichen) {
	this.Ratenkennzeichen = Ratenkennzeichen;
}

public void setRechnungsdatum(Calendar Rechnungsdatum) {
	this.Rechnungsdatum = Rechnungsdatum;
}

public void setRechnungskennzeichen(String Rechnungskennzeichen) {
	this.Rechnungskennzeichen = Rechnungskennzeichen;
}

public void setRechnungsnummer(Long Rechnungsnummer) {
	this.Rechnungsnummer = Rechnungsnummer;
}

public void setRetouregrund(Long Retouregrund) {
	this.Retouregrund = Retouregrund;
}

public void setRetouregrunderfassungBenutzer(Benutzer RetouregrunderfassungBenutzer) {
	this.RetouregrunderfassungBenutzer = RetouregrunderfassungBenutzer;
}

public void setRetouregrunderfassungsdatum(Calendar Retouregrunderfassungsdatum) {
	this.Retouregrunderfassungsdatum = Retouregrunderfassungsdatum;
}

public void setRetoureschluessel(Long Retoureschluessel) {
	this.Retoureschluessel = Retoureschluessel;
}

public void setRuckzuckkennzeichen(String Ruckzuckkennzeichen) {
	this.Ruckzuckkennzeichen = Ruckzuckkennzeichen;
}

public void setSaison(Saison Saison) {
	this.Saison = Saison;
}

public void setSetartikelnummerkennzeichen(Long Setartikelnummerkennzeichen) {
	this.Setartikelnummerkennzeichen = Setartikelnummerkennzeichen;
}

public void setTelefonkennzeichen(Long Telefonkennzeichen) {
	this.Telefonkennzeichen = Telefonkennzeichen;
}

public void setValutakennzeichen(Long Valutakennzeichen) {
	this.Valutakennzeichen = Valutakennzeichen;
}

public void setWarengruppeCrossselling(String WarengruppeCrossselling) {
	this.WarengruppeCrossselling = WarengruppeCrossselling;
}

public void setWertstueckkennzeichen(String Wertstueckkennzeichen) {
	this.Wertstueckkennzeichen = Wertstueckkennzeichen;
}

}

package eu.wittgruppe.dias.domain;

import org.apache.commons.lang.builder.ToStringBuilder;

import jakarta.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity(name = "GroessenArtikelstamm")
@Table(name = "gr_artsta")
public class GroessenArtikelstamm implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private GroessenArtikelstammPK pk = null;

	/*
	 * Datum der letzten Aenderung
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AENDDAT")
	private Date letzeAenderung = null;

	/*
	 * Anzahl der Teile (z. B. bei Socken = 2)
	 */
	@Column(name = "ANZTEILE")
	private Long anzahlTeile = null;

	/*
	 * Kennzeichen, ob Auslandslieferant fuer diesen Artikel moeglich
	 */
	@Column(name = "AUSLKZ")
	private String auslandskennzeichen = null;

	/*
	 * Bedarfskennzeichen
	 */
	@Column(name = "BEDARFKZ")
	private Long bedarfskennzeichen = null;

	/*
	 * bewilligter Einkaufspreis
	 */
	@Column(name = "BEK")
	private BigDecimal bewilligterEinkaufpreis = null;

	/*
	 * bewilligter Einkaufspreis der neuen Saison (ABEVB)
	 */
	@Column(name = "BEKNEUSAI")
	private BigDecimal bekNeueSaison = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "benutzerid", referencedColumnName = "id")
	private Benutzer benutzer = null;

	/*
	 * Breite des Artikels im mm
	 */
	@Column(name = "BREITE_MM")
	private Long breiteMillimeter = null;

	/*
	 * Kennzeichen fuer Direktlieferant 1=Direktlieferant, 2=Direktlieferant mit
	 * Lieferproblemen, 0=kein Direktlieferant
	 */
	@Column(name = "DIREKTKZ")
	private Long direktlieferantenkennzeichen = null;

	/*
	 * Druckfdhige Grv_e
	 */
	@Column(name = "DRUCKF_GR")
	private String druckf_gr = null;

	/*
	 * Kennzeichen bei EG-Lieferanten
	 */
	@Column(name = "EGKZ")
	private String egkz = null;

	@Column(name = "EGMGKZ")
	private Long egmgkz = null;

	@Column(name = "EGQMETERFAKTOR")
	private Long egqmeterfaktor = null;

	@Column(name = "EGSTATKZ")
	private Long egstatkz = null;

	/*
	 * Ersatz bzw. Empfehlungskennzeichen (1=Ersatz, 2=Empfehlung, 3=beides,
	 * 4=fiktiv)
	 */
	@Column(name = "ERSATZEMPFKZ")
	private Long ersatzEmpfehlungskennzeichen = null;

	/*
	 * Kennzeichen der Bestandsfirma z. B. 03 = Sieh an!
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "firmkz", referencedColumnName = "FIRMKZ")
	private Bestandsfirma bestandsfirma = null;

	/*
	 * Gewicht in Gramm
	 */
	@Column(name = "GEW_GRAMM")
	private Long gewichtInGramm = null;

	/*
	 * Groessenschluessel
	 */
	@Column(name = "GRSCHL")
	private Long groessenSchluessel = null;

	/*
	 * Groessenverteilung
	 */
	@Column(name = "GRVERT")
	private BigDecimal groessenverteilung = null;

	/*
	 * Hoehe des Artikels im mm
	 */
	@Column(name = "HOEHE_MM")
	private Long hoeheMillimeter = null;

	/*
	 * Herkunftskennzeichen , Importkennzeichen
	 */
	@Column(name = "IMPKZ")
	private String herkunftskennzeichen = null;

	/*
	 * Tuetenfaehigkeitskennzeichen Innenkarton (0 = Artikel nicht tuetenfaehig,
	 * 1 = Artikel ist tuetenfaehig, 6 = Minderwert.-Artikel, zu KLEX_SOKO
	 * zupackfaehig, 8 = Wertschmuck, generell Paket, 9=Im Originalkarton
	 * versandfaehig )
	 */
	@Column(name = "KARTONKZ")
	private Long tuetenfaehigkeitskennzeichen = null;

	/*
	 * Laenge des Artikels in mm
	 */
	@Column(name = "LAENGE_MM")
	private Long laengeMillimeter = null;

	/*
	 * 8-stelliger Lagerort des Artikels
	 */
	@Column(name = "LGORT")
	private Long lagerort = null;

	/*
	 * Lieferauskunft Telekauf z. B. 24 = Ende Dezember
	 */
	@Column(name = "LIINFTELE")
	private Long lieferauskunftTelekauf = null;

	/*
	 * Lieferkennzeichen, z. B. ausverkauft
	 */
	@Column(name = "LIKZ")
	private Long lieferkennzeichen = null;

	/*
	 * Kennzeichen fuer NAB halten; Feld wird vom Host gefuellt (ANAL3)
	 */
	@Column(name = "LIKZ_HALTEN")
	private String kennzeichenNAB = null;

	/*
	 * wenn NALIKZ auf 3 gesetzt, dann entspricht das likz = ausverkauft auf
	 * Nachlieferung, wenn NALIKZ nicht gesetzt, dann enspricht das LIKZ =
	 * endgueltig ausverkauft
	 */
	@Column(name = "NALIKZ")
	private Long nachlieferungskennzeichen = null;

	/*
	 * Kennzeichen, ob eine Artikelgroesse auch in der neuen Saison eingesetzt
	 * ist / 0 = Nein; 1 = Ja (ASVKZ)
	 */
	@Column(name = "NEUSAIKZ")
	private Long neueSaisonKennzeichen = null;

	/*
	 * Durchschnittliche Retourenlaufzeit in Tagen
	 */
	@Column(name = "RETLAUFZEIT_TT_AVG")
	private BigDecimal retourelaufzeitInTagen = null;

	/*
	 * Retourensortkennzeichen fuer die Retourenabwicklung
	 */
	@Column(name = "RETSORTKZ")
	private Long retouresortkennzeichen = null;

	/*
	 * Verwendungskennzeichen bei Retouren
	 */
	@Column(name = "RETWEITERVERWKZ")
	private Long retoureWeiterVerwendungskennzeichen = null;

	/*
	 * sinnvolle Bestellmenge
	 */
	@Column(name = "SINNBESTMGKZ")
	private Long sinnvolleBestellmenge = null;

	/*
	 * freier Text (vom HOST)
	 */
	@Column(name = "TEXT")
	private String text = null;

	/*
	 * Totkennzeichen des Artikels 1=Uebernahmeartikel, 2 = neuer Artikel, 0 =
	 * lebendiger Artikel
	 */
	@Column(name = "TOTKZ")
	private Long totkennzeichen = null;

	/*
	 * Transferkennzeichen fuer Grossrechner z. B. 0=nicht transferiert,
	 * 1=transferiert, aber noch nicht vom Grossrechner OK, 2= transferiert und
	 * OK vom HOST, 3=wird nicht transferiert. Defaultwert = 2, ==> kein
	 * Transfer zum HOST
	 */
	@Column(name = "TRANSFERKZ")
	private Long transferkennzeichen = null;

	/*
	 * Umweltkennzeichen (1=PCP Artikel, 2=Artikel mit AZO-Farbstoff, 3=PCP,AZO
	 * Artikel)
	 */
	@Column(name = "UMWELTKZ")
	private Long umweltkennzeichen = null;

	/*
	 * Benutzernummer des Erfassers
	 */
	@Column(name = "USERNR")
	private Long benutzernummer = null;

	/*
	 * verrechneter Einkaufspreis
	 */
	@Column(name = "VEK")
	private BigDecimal verrechneterEinkaufpreis = null;

	/*
	 * verrechneter Einkaufspreis der neuen Saison (AVEVB)
	 */
	@Column(name = "VEKNEUSAI")
	private BigDecimal verrechneterEinkaufspreisNeueSaison = null;

	/*
	 * Verfuegbarkennzeichen (0=Eigene Ware, 1 = Konsignation, 3 =
	 * Durchlaufware)
	 */
	@Column(name = "VERFUEGBARKZ")
	private Long verfuegbarkennzeichen = null;

	/*
	 * Verhaltenskennzeichen
	 */
	@Column(name = "VERHALTENKZ")
	private Long verhaltenskennzeichen = null;

	/*
	 * Versandschluessel des Artikels (0=GangFachNr, 1 = Versandschluessel) vom
	 * HOST
	 */
	@Column(name = "VERSANDSCHL")
	private Long versandschluessel = null;

	/*
	 * Verwendungskennzeichen des Artikels z. B. Ersatz,Folgesaison
	 */
	@Column(name = "VERWKZ")
	private Long verwendungskennzeichen = null;

	/*
	 * Volumen in Liter
	 */
	@Column(name = "VOL_L")
	private BigDecimal volumenInLiter = null;

	/*
	 * Gueltigkeitsdatum (Beginn) des Datensatzes
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "VONDAT")
	private Date vondat = null;

	/*
	 * Warenbereichskennzeichen (12,13 = haengend)
	 */
	@Column(name = "WABERKZ")
	private Long warenbereichskennzeichen = null;
	
	/*
	 * Saison.
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "saison", referencedColumnName = "saison")
	private Saison saison = null;

	public GroessenArtikelstamm() {
	}

	public Date getLetzeAenderung() {
		return letzeAenderung;
	}

	public void setLetzeAenderung(Date letzeAenderung) {
		this.letzeAenderung = letzeAenderung;
	}

	public Long getAnzahlTeile() {
		return anzahlTeile;
	}

	public void setAnzahlTeile(Long anzahlTeile) {
		this.anzahlTeile = anzahlTeile;
	}

	public String getAuslandskennzeichen() {
		return auslandskennzeichen;
	}

	public void setAuslandskennzeichen(String auslandskennzeichen) {
		this.auslandskennzeichen = auslandskennzeichen;
	}

	public Long getBedarfskennzeichen() {
		return bedarfskennzeichen;
	}

	public void setBedarfskennzeichen(Long bedarfskennzeichen) {
		this.bedarfskennzeichen = bedarfskennzeichen;
	}

	public BigDecimal getBewilligterEinkaufpreis() {
		return bewilligterEinkaufpreis;
	}

	public void setBewilligterEinkaufpreis(BigDecimal bewilligterEinkaufpreis) {
		this.bewilligterEinkaufpreis = bewilligterEinkaufpreis;
	}

	public BigDecimal getBekNeueSaison() {
		return bekNeueSaison;
	}

	public void setBekNeueSaison(BigDecimal bekNeueSaison) {
		this.bekNeueSaison = bekNeueSaison;
	}

	public Benutzer getBenutzer() {
		return benutzer;
	}

	public void setBenutzer(Benutzer benutzer) {
		this.benutzer = benutzer;
	}

	public Long getBreiteMillimeter() {
		return breiteMillimeter;
	}

	public void setBreiteMillimeter(Long breiteMillimeter) {
		this.breiteMillimeter = breiteMillimeter;
	}

	public Long getDirektlieferantenkennzeichen() {
		return direktlieferantenkennzeichen;
	}

	public void setDirektlieferantenkennzeichen(
			Long direktlieferantenkennzeichen) {
		this.direktlieferantenkennzeichen = direktlieferantenkennzeichen;
	}

	public String getDruckf_gr() {
		return druckf_gr;
	}

	public void setDruckf_gr(String druckf_gr) {
		this.druckf_gr = druckf_gr;
	}

	public String getEgkz() {
		return egkz;
	}

	public void setEgkz(String egkz) {
		this.egkz = egkz;
	}

	public Long getEgmgkz() {
		return egmgkz;
	}

	public void setEgmgkz(Long egmgkz) {
		this.egmgkz = egmgkz;
	}

	public Long getEgqmeterfaktor() {
		return egqmeterfaktor;
	}

	public void setEgqmeterfaktor(Long egqmeterfaktor) {
		this.egqmeterfaktor = egqmeterfaktor;
	}

	public Long getEgstatkz() {
		return egstatkz;
	}

	public void setEgstatkz(Long egstatkz) {
		this.egstatkz = egstatkz;
	}

	public Long getErsatzEmpfehlungskennzeichen() {
		return ersatzEmpfehlungskennzeichen;
	}

	public void setErsatzEmpfehlungskennzeichen(
			Long ersatzEmpfehlungskennzeichen) {
		this.ersatzEmpfehlungskennzeichen = ersatzEmpfehlungskennzeichen;
	}

	public Long getGewichtInGramm() {
		return gewichtInGramm;
	}

	public void setGewichtInGramm(Long gewichtInGramm) {
		this.gewichtInGramm = gewichtInGramm;
	}

	public Long getGroessenSchluessel() {
		return groessenSchluessel;
	}

	public void setGroessenSchluessel(Long groessenSchluessel) {
		this.groessenSchluessel = groessenSchluessel;
	}

	public BigDecimal getGroessenverteilung() {
		return groessenverteilung;
	}

	public void setGroessenverteilung(BigDecimal groessenverteilung) {
		this.groessenverteilung = groessenverteilung;
	}

	public Long getHoeheMillimeter() {
		return hoeheMillimeter;
	}

	public void setHoeheMillimeter(Long hoeheMillimeter) {
		this.hoeheMillimeter = hoeheMillimeter;
	}

	public String getHerkunftskennzeichen() {
		return herkunftskennzeichen;
	}

	public void setHerkunftskennzeichen(String herkunftskennzeichen) {
		this.herkunftskennzeichen = herkunftskennzeichen;
	}

	public Long getTuetenfaehigkeitskennzeichen() {
		return tuetenfaehigkeitskennzeichen;
	}

	public void setTuetenfaehigkeitskennzeichen(
			Long tuetenfaehigkeitskennzeichen) {
		this.tuetenfaehigkeitskennzeichen = tuetenfaehigkeitskennzeichen;
	}

	public Long getLaengeMillimeter() {
		return laengeMillimeter;
	}

	public void setLaengeMillimeter(Long laengeMillimeter) {
		this.laengeMillimeter = laengeMillimeter;
	}

	public Long getLagerort() {
		return lagerort;
	}

	public void setLagerort(Long lagerort) {
		this.lagerort = lagerort;
	}

	public Long getLieferauskunftTelekauf() {
		return lieferauskunftTelekauf;
	}

	public void setLieferauskunftTelekauf(Long lieferauskunftTelekauf) {
		this.lieferauskunftTelekauf = lieferauskunftTelekauf;
	}

	public Long getLieferkennzeichen() {
		return lieferkennzeichen;
	}

	public void setLieferkennzeichen(Long lieferkennzeichen) {
		this.lieferkennzeichen = lieferkennzeichen;
	}

	public String getKennzeichenNAB() {
		return kennzeichenNAB;
	}

	public void setKennzeichenNAB(String kennzeichenNAB) {
		this.kennzeichenNAB = kennzeichenNAB;
	}

	public Long getNachlieferungskennzeichen() {
		return nachlieferungskennzeichen;
	}

	public void setNachlieferungskennzeichen(Long nachlieferungskennzeichen) {
		this.nachlieferungskennzeichen = nachlieferungskennzeichen;
	}

	public Long getNeueSaisonKennzeichen() {
		return neueSaisonKennzeichen;
	}

	public void setNeueSaisonKennzeichen(Long neueSaisonKennzeichen) {
		this.neueSaisonKennzeichen = neueSaisonKennzeichen;
	}

	public BigDecimal getRetourelaufzeitInTagen() {
		return retourelaufzeitInTagen;
	}

	public void setRetourelaufzeitInTagen(BigDecimal retourelaufzeitInTagen) {
		this.retourelaufzeitInTagen = retourelaufzeitInTagen;
	}

	public Long getRetouresortkennzeichen() {
		return retouresortkennzeichen;
	}

	public void setRetouresortkennzeichen(Long retouresortkennzeichen) {
		this.retouresortkennzeichen = retouresortkennzeichen;
	}

	public Long getRetoureWeiterVerwendungskennzeichen() {
		return retoureWeiterVerwendungskennzeichen;
	}

	public void setRetoureWeiterVerwendungskennzeichen(
			Long retoureWeiterVerwendungskennzeichen) {
		this.retoureWeiterVerwendungskennzeichen = retoureWeiterVerwendungskennzeichen;
	}

	public Long getSinnvolleBestellmenge() {
		return sinnvolleBestellmenge;
	}

	public void setSinnvolleBestellmenge(Long sinnvolleBestellmenge) {
		this.sinnvolleBestellmenge = sinnvolleBestellmenge;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Long getTotkennzeichen() {
		return totkennzeichen;
	}

	public void setTotkennzeichen(Long totkennzeichen) {
		this.totkennzeichen = totkennzeichen;
	}

	public Long getTransferkennzeichen() {
		return transferkennzeichen;
	}

	public void setTransferkennzeichen(Long transferkennzeichen) {
		this.transferkennzeichen = transferkennzeichen;
	}

	public Long getUmweltkennzeichen() {
		return umweltkennzeichen;
	}

	public void setUmweltkennzeichen(Long umweltkennzeichen) {
		this.umweltkennzeichen = umweltkennzeichen;
	}

	public Long getBenutzernummer() {
		return benutzernummer;
	}

	public void setBenutzernummer(Long benutzernummer) {
		this.benutzernummer = benutzernummer;
	}

	public BigDecimal getVerrechneterEinkaufpreis() {
		return verrechneterEinkaufpreis;
	}

	public void setVerrechneterEinkaufpreis(BigDecimal verrechneterEinkaufpreis) {
		this.verrechneterEinkaufpreis = verrechneterEinkaufpreis;
	}

	public BigDecimal getVerrechneterEinkaufspreisNeueSaison() {
		return verrechneterEinkaufspreisNeueSaison;
	}

	public void setVerrechneterEinkaufspreisNeueSaison(
			BigDecimal verrechneterEinkaufspreisNeueSaison) {
		this.verrechneterEinkaufspreisNeueSaison = verrechneterEinkaufspreisNeueSaison;
	}

	public Long getVerfuegbarkennzeichen() {
		return verfuegbarkennzeichen;
	}

	public void setVerfuegbarkennzeichen(Long verfuegbarkennzeichen) {
		this.verfuegbarkennzeichen = verfuegbarkennzeichen;
	}

	public Long getVerhaltenskennzeichen() {
		return verhaltenskennzeichen;
	}

	public void setVerhaltenskennzeichen(Long verhaltenskennzeichen) {
		this.verhaltenskennzeichen = verhaltenskennzeichen;
	}

	public Long getVersandschluessel() {
		return versandschluessel;
	}

	public void setVersandschluessel(Long versandschluessel) {
		this.versandschluessel = versandschluessel;
	}

	public Long getVerwendungskennzeichen() {
		return verwendungskennzeichen;
	}

	public void setVerwendungskennzeichen(Long verwendungskennzeichen) {
		this.verwendungskennzeichen = verwendungskennzeichen;
	}

	public BigDecimal getVolumenInLiter() {
		return volumenInLiter;
	}

	public void setVolumenInLiter(BigDecimal volumenInLiter) {
		this.volumenInLiter = volumenInLiter;
	}

	public Date getVondat() {
		return vondat;
	}

	public void setVondat(Date vondat) {
		this.vondat = vondat;
	}

	public Long getWarenbereichskennzeichen() {
		return warenbereichskennzeichen;
	}

	public void setWarenbereichskennzeichen(Long warenbereichskennzeichen) {
		this.warenbereichskennzeichen = warenbereichskennzeichen;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public Bestandsfirma getBestandsfirma() {
		return bestandsfirma;
	}

	public void setBestandsfirma(Bestandsfirma bestandsfirma) {
		this.bestandsfirma = bestandsfirma;
	}
	
	public Saison getSaison() {
		return saison;
	}
	
	public void setSaison(Saison saison) {
		this.saison = saison;
	}
}

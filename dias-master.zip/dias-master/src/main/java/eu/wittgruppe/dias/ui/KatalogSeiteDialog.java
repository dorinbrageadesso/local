package eu.wittgruppe.dias.ui;

import eu.wittgruppe.dias.controller.KatalogSeiteDialogController;
import witt.josef.uiswing.ui.ImageLabel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;

public class KatalogSeiteDialog extends JDialog {
	
	private KatalogSeiteDialogController controller = null;
	
	private JPanel jContentPane = null;
	private JPanel borderPanel = null;
	private JPanel northPanel = null;
	private JPanel centerPanel = null;
	private JPanel southPanel = null;
	private JScrollPane seiteScrollPane = null;
	public ImageLabel seiteLabel = null;
	private JSlider zoomSlider = null;

	private JLabel katalogLabel = null;

	private JTextField katalogTextField = null;

	private JLabel seiteLabel1 = null;

	private JTextField seiteTextField = null;

	private JLabel abbLabel = null;

	private JTextField abbTextField = null;

	private JButton cancelButton = null;

	private JViewport jViewport = null;

	private JScrollBar jScrollBar = null;

	private JLabel artnrLabel = null;

	private JTextField artnrTextField = null;

	 
	public KatalogSeiteDialog(JFrame parent, KatalogSeiteDialogController controller) {
		super(parent);
		this.controller = controller;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(1024, 768);
		this.setTitle("Katalogseite");
		this.setContentPane(getJContentPane());
		this.addWindowListener(new OnCloseButton());
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.setPreferredSize(new java.awt.Dimension(1024,768));
			jContentPane.setMaximumSize(new java.awt.Dimension(1024,768));
			jContentPane.setMinimumSize(new java.awt.Dimension(1024,768));
			jContentPane.add(getBorderPanel(), java.awt.BorderLayout.CENTER);
		}
		return jContentPane;
	}

	/**
	 * This method initializes borderPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getBorderPanel() {
		if (borderPanel == null) {
			borderPanel = new JPanel();
			borderPanel.setLayout(new BorderLayout());
			borderPanel.setPreferredSize(new java.awt.Dimension(900,675));
			borderPanel.setMinimumSize(new java.awt.Dimension(900,675));
			borderPanel.add(getNorthPanel(), java.awt.BorderLayout.NORTH);
			borderPanel.add(getCenterPanel(), java.awt.BorderLayout.CENTER);
			borderPanel.add(getSouthPanel(), java.awt.BorderLayout.SOUTH);
		}
		return borderPanel;
	}

	/**
	 * This method initializes northPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getNorthPanel() {
		if (northPanel == null) {
			artnrLabel = new JLabel();
			artnrLabel.setText("ArtNr.:");
			FlowLayout flowLayout = new FlowLayout();
			flowLayout.setAlignment(java.awt.FlowLayout.LEFT);
			abbLabel = new JLabel();
			abbLabel.setText("Abbildung: ");
			seiteLabel1 = new JLabel();
			seiteLabel1.setText("Seite: ");
			katalogLabel = new JLabel();
			katalogLabel.setText("Katalog: ");
			northPanel = new JPanel();
			northPanel.setLayout(flowLayout);
			northPanel.setComponentOrientation(java.awt.ComponentOrientation.LEFT_TO_RIGHT);
			northPanel.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
			northPanel.add(katalogLabel, null);
			northPanel.add(getKatalogTextField(), null);
			northPanel.add(seiteLabel1, null);
			northPanel.add(getSeiteTextField(), null);
			northPanel.add(abbLabel, null);
			northPanel.add(getAbbTextField(), null);
			northPanel.add(artnrLabel, null);
			northPanel.add(getArtnrTextField(), null);
			northPanel.add(getZoomSlider(), null);
		}
		return northPanel;
	}

	/**
	 * This method initializes centerPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	public JPanel getCenterPanel() {
		if (centerPanel == null) {
			GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
			gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
			gridBagConstraints1.weighty = 1.0;
			gridBagConstraints1.weightx = 1.0;
			centerPanel = new JPanel();
			centerPanel.setLayout(new GridBagLayout());
			centerPanel.setMaximumSize(new java.awt.Dimension(2147483647,2147483647));
			centerPanel.setPreferredSize(new java.awt.Dimension(900,675));
			centerPanel.setMinimumSize(new java.awt.Dimension(900,675));
			centerPanel.add(getSeiteScrollPane(), gridBagConstraints1);
		}
		return centerPanel;
	}

	/**
	 * This method initializes southPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getSouthPanel() {
		if (southPanel == null) {
			southPanel = new JPanel();
			southPanel.add(getCancelButton(), null);
		}
		return southPanel;
	}

	public JLabel getSeiteLabel() {
		return seiteLabel;
	}

	/**
	 * This method initializes seiteScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	public JScrollPane getSeiteScrollPane() {
		if (seiteScrollPane == null) {
			//seiteLabel = new JLabel();
			seiteScrollPane = new JScrollPane();
			seiteScrollPane.setViewportView(seiteLabel);
			seiteScrollPane.setMinimumSize(new java.awt.Dimension(2147483647,2147483647));
			seiteScrollPane.setPreferredSize(new java.awt.Dimension(2147483647,2147483647));
			seiteScrollPane.setViewport(getJViewport());
			seiteScrollPane.setVerticalScrollBar(getJScrollBar());
			seiteScrollPane.setMaximumSize(new java.awt.Dimension(2147483647,2147483647));
		}
		return seiteScrollPane;
	}

	/**
	 * This method initializes zoomSlider	
	 * 	
	 * @return javax.swing.JSlider	
	 */
	public JSlider getZoomSlider() {
		if (zoomSlider == null) {
			zoomSlider = new JSlider();
			  zoomSlider.setPreferredSize(new java.awt.Dimension(80,25));
	            zoomSlider.setMaximum( 300 );
	            zoomSlider.setMinimum( 1 );
	            zoomSlider.setValue( 75 );
	            zoomSlider.setExtent( 10 );
	            zoomSlider.setMaximumSize(new java.awt.Dimension(80,25));
	            zoomSlider.setToolTipText("Seite zoomen");
	            zoomSlider.setMinimumSize(new java.awt.Dimension(80,25));
	            zoomSlider.addChangeListener( new javax.swing.event.ChangeListener() {
	                public void stateChanged( javax.swing.event.ChangeEvent e ) {
	                    if( !zoomSlider.getValueIsAdjusting() ) {
	                        controller.scalePicture( ( new Double( zoomSlider.getValue() ).doubleValue() / 100), getSeiteScrollPane() );
	                    }
	                }
	            } );
	            zoomSlider.addPropertyChangeListener( new java.beans.PropertyChangeListener() {
	                public void propertyChange( java.beans.PropertyChangeEvent e ) {
	                    if( ( e.getPropertyName().equals( "value" ) ) ) {
	                        //logger.debug( "propertyChange(value)" );
	                        controller.scalePicture( ( new Double( zoomSlider.getValue() ).doubleValue() / 100), getSeiteScrollPane() );
	                    }
	                }
	            } );
		}
		return zoomSlider;
	}

	/**
	 * This method initializes katalogTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	public JTextField getKatalogTextField() {
		if (katalogTextField == null) {
			katalogTextField = new JTextField();
			katalogTextField.setMaximumSize(new java.awt.Dimension(164,21));
			katalogTextField.setPreferredSize(new java.awt.Dimension(164,21));
			katalogTextField.setBackground(new java.awt.Color(231,235,235));
			katalogTextField.setEnabled(false);
			katalogTextField.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
			katalogTextField.setDisabledTextColor(java.awt.Color.black);
			katalogTextField.setMinimumSize(new java.awt.Dimension(164,21));
		}
		return katalogTextField;
	}

	/**
	 * This method initializes jTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	public JTextField getSeiteTextField() {
		if (seiteTextField == null) {
			seiteTextField = new JTextField();
			seiteTextField.setMaximumSize(new java.awt.Dimension(52,21));
			seiteTextField.setPreferredSize(new java.awt.Dimension(52,21));
			seiteTextField.setEnabled(false);
			seiteTextField.setBackground(new java.awt.Color(231,235,235));
			seiteTextField.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
			seiteTextField.setDisabledTextColor(java.awt.Color.black);
			seiteTextField.setMinimumSize(new java.awt.Dimension(52,21));
		}
		return seiteTextField;
	}

	/**
	 * This method initializes abbTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	public JTextField getAbbTextField() {
		if (abbTextField == null) {
			abbTextField = new JTextField();
			abbTextField.setMaximumSize(new java.awt.Dimension(52,21));
			abbTextField.setPreferredSize(new java.awt.Dimension(52,21));
			abbTextField.setEnabled(false);
			abbTextField.setBackground(new java.awt.Color(231,235,235));
			abbTextField.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
			abbTextField.setDisabledTextColor(java.awt.Color.black);
			abbTextField.setMinimumSize(new java.awt.Dimension(52,21));
		}
		return abbTextField;
	}

	/**
	 * This method initializes cancelButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getCancelButton() {
		if (cancelButton == null) {
			cancelButton = new JButton();
			cancelButton.setPreferredSize(new java.awt.Dimension(100,26));
			cancelButton.setMaximumSize(new java.awt.Dimension(100,26));
			cancelButton.setText("Schließen");
			cancelButton.setMinimumSize(new java.awt.Dimension(100,26));
			cancelButton.addActionListener(new OnCloseButton());
		}
		return cancelButton;
	}

	/**
	 * This method initializes jViewport	
	 * 	
	 * @return javax.swing.JViewport	
	 */
	private JViewport getJViewport() {
		if (jViewport == null) {
			jViewport = new JViewport();
			jViewport.setSize(new java.awt.Dimension(900,675));
			jViewport.setMinimumSize(new java.awt.Dimension(900,675));
		}
		return jViewport;
	}

	/**
	 * This method initializes jScrollBar	
	 * 	
	 * @return javax.swing.JScrollBar	
	 */
	private JScrollBar getJScrollBar() {
		if (jScrollBar == null) {
			jScrollBar = new JScrollBar();
			jScrollBar.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
		}
		return jScrollBar;
	}
	
	// L I S T E N E R S
	private class OnCloseButton extends WindowAdapter implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			controller.closeDialog();
		}
		public void windowClosing(java.awt.event.WindowEvent e) {
			controller.closeDialog();
		}

	}

	/**
	 * This method initializes artnrTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	public JTextField getArtnrTextField() {
		if (artnrTextField == null) {
			artnrTextField = new JTextField();
			artnrTextField.setMaximumSize(new java.awt.Dimension(52,21));
			artnrTextField.setPreferredSize(new java.awt.Dimension(52,21));
			artnrTextField.setBackground(new java.awt.Color(231,235,235));
			artnrTextField.setEnabled(false);
			artnrTextField.setDisabledTextColor(java.awt.Color.black);
			artnrTextField.setMinimumSize(new java.awt.Dimension(52,21));
		}
		return artnrTextField;
	};
	

}  //  @jve:decl-index=0:visual-constraint="10,10"

package eu.wittgruppe.dias.service.dao.jpa;

import eu.wittgruppe.dias.bean.*;
import eu.wittgruppe.dias.domain.*;
import eu.wittgruppe.dias.service.dao.DiasDAO;
import eu.wittgruppe.dias.util.Constants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import witt.josef.benutzerverwaltung.Account;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import java.sql.Blob;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

import static eu.wittgruppe.dias.util.NumberUtils.toLong;

@Component
@Transactional
@Slf4j
public class DiasDAOJPAImpl implements DiasDAO {

    private static final long FARBEN_MERKMALKLNR = 5;

    @PersistenceContext
    private EntityManager em;

    private final RestTemplate restTemplate = new RestTemplate();

    @Override
    public String getLKZFromZLKZAndBukr( String bukr, String zlkz ) {

        log.debug( "LKZ aus Buchungskreis (" + bukr + ") und Zentrallieferantenkennzeichen (" + zlkz + ") laden..." );

        String lkz = null;

        StringBuffer sb = new StringBuffer();

        sb.append(" SELECT kls.liefnr ");
        sb.append(" FROM   konzernliefsta kls ");
        sb.append("        JOIN konzernfirma kf ON ( kf.id = kls.konzernfirmaid ) ");
        sb.append("        JOIN liefsta ls ON ( ls.id = kls.liefstaid ) ");
        sb.append("        JOIN bestandsfirma bf ON ( bf.konzernfirmaid = kf.id ) ");
        sb.append(" WHERE  kf.id = kls.konzernfirmaid ");
        sb.append(" AND    kls.aktivkz = 1 ");
        sb.append(" AND    kls.einkaufaktivkz = 1 ");
        sb.append(" AND    kf.firmkzkonz = '" + bukr  + "'");
        sb.append(" AND    ls.zentrallkz = " + zlkz );


        Query query = em.createNativeQuery( sb.toString() );
        Object o = query.getSingleResult();

        if( o != null ) {
            lkz = ( String )o;
        }

        log.debug( "Folgende LKZ wurde ermittelt: " + lkz );

        return lkz;
    }

    @Override
    public Collection sucheLieferanten() {

        Collection lieferantenVOCol = new ArrayList();

        log.debug( "Lieferanten laden..." );

        StringBuffer sb = new StringBuffer();

        sb.append(" SELECT LPAD( kf.firmkzkonz, 4, '0' ) AS buchungskreis, ");
        sb.append("        ls.zentrallkz AS liefnrzentral, ");
        sb.append("        kls.liefnr, ");
        sb.append("        ls.name AS liefname ");
        sb.append(" FROM   konzernliefsta kls ");
        sb.append("        JOIN konzernfirma kf ON ( kf.id = kls.konzernfirmaid ) ");
        sb.append("        JOIN liefsta ls ON ( ls.id = kls.liefstaid ) ");
        sb.append("        JOIN bestandsfirma bf ON ( bf.konzernfirmaid = kf.id ) ");
        sb.append(" WHERE  kf.id = kls.konzernfirmaid ");
        sb.append(" AND    kls.aktivkz = 1 ");
        sb.append(" AND    kls.einkaufaktivkz = 1 ");
        sb.append(" order by liefname ");


        Query query = em.createNativeQuery( sb.toString() );

        List<Object[]> resultList = query.getResultList();
        for( Object[] obj : resultList ) {
            LieferantBean lieferantVO = new LieferantBean();
            lieferantVO.setName( obj[3].toString() );
            lieferantVO.setNummer( Long.valueOf( obj[2].toString() ) );
            lieferantVO.setBuchungskreis( Long.valueOf( obj[0].toString() ) );
            lieferantVO.setZlkz( Long.valueOf( obj[1].toString() ) );

            lieferantenVOCol.add( lieferantVO );
        }
        return lieferantenVOCol;
    }

    @Override
    public Collection<MerkmalklasseDiamant> sucheMerkmalsKlassen() {
        Collection<MerkmalklasseDiamant> col = null;
        Query query = em.createQuery( "select m from MerkmalklasseDiamant m order by m.bezeichnung" );
        return query.getResultList();
    }

    @Override
    public Collection<Marktkennzeichen> sucheMarktKennzeichen( MerkmalklasseDiamant klasse ) {

        Collection<Marktkennzeichen> col = null;
        Query query = em.createNamedQuery( "select m from Marktkennzeichen m where m.merkmalklasseDiamant = :klasse" );
        query.setParameter( "klasse", klasse );

        return query.getResultList();
    }

    @Override
    public Collection<Marktkennzeichen> sucheAllMarktKennzeichen() {

        Query query = em.createQuery( "select m from Marktkennzeichen m join fetch m.merkmalklasseDiamant d order by d.bezeichnung, m.marktKennzeichenBezeichnung" );
        return query.getResultList();

    }

    @Override
    public Collection<FarbeDefBean> sucheFarben( String farbe ) {

        Vector vec = null;
        Collection col = new ArrayList();
        StringBuffer sb = new StringBuffer();
        if( farbe == null ) {
            sb.append( "select  id, farbdef, farbdefid, level " + "from farbdef " + "start with farbdefid is null " + "connect by prior id = farbdefid" );
        } else {
            sb.append( "select id, farbdef, farbdefid, level " + "from farbdef " + "start with id in (select distinct id " + "from farbdef " + "where level = 3 " + "start with id in (select distinct farbdefid " + "from wertvorgabe "
                    + "where merkmalvorlnr = 5 " + "and upper(wert) like '" + StringUtils.upperCase( farbe ) + "') " + "connect by prior farbdefid = id) " + "connect by prior id =  farbdefid" );
        }

        List<Object[]> resultList = em.createNativeQuery( sb.toString() ).getResultList();

        for( Object[] oa : resultList ) {
            FarbeDefBean farbeBean = new FarbeDefBean();
            farbeBean.setId( oa[0].toString() );
            farbeBean.setFarbe( oa[1].toString() );

            if( oa[2] != null ) {
                farbeBean.setParentId( oa[2].toString() );
            }
            if( oa[3] != null ) {
                farbeBean.setLevel( toLong( oa[3] ) );
            }
            col.add( farbeBean );
        }

        return col;

    }

    @Override
    public Collection<VDiasArtikel> sucheArtikel( String artnr, Boolean isCrs ) {

        log.debug( "Artikel suchen mit Artikelnr: " + artnr );

        Collection artikel = null;

        Long aktSaison = getAktuelleSaison() + 1; // wird im alten auch so gemacht, warum keine Ahnung..

        artikel = findByCriteria( artnr, isCrs, aktSaison, Constants.SAISON_ZEITRAUM );

        Integer vonSaison = Integer.valueOf( aktSaison.intValue() - Constants.SAISON_ZEITRAUM );

        StringBuffer sql = new StringBuffer();
        sql.append( "select * from mv_dias_artikel " );
        sql.append( "where saison between " + vonSaison.toString() + " and " + aktSaison.toString() + " " );

        sql.append( "and artnr6 = " );

        // wenn übergebene Artiklenr CRS ist, Witt Artikelnr suchen
        if( isCrs.booleanValue() ) {
            sql.append( "(select artnr6 from alfa_art join alfa_fremd on ALFA_FREMD.ALFA_ARTID = alfa_art.id where ALFA_FREMD.ARTNRFREMD = '" + artnr + "' ) " );
        } else {
            sql.append( artnr + " " );
        }

        sql.append( "order by saison desc, artnr6, mvgr " );

        Query query = em.createNativeQuery( sql.toString() );
        return convert( query.getResultList() );
    }

    private Collection<VDiasArtikel> convert( List d ) {
        Collection<VDiasArtikel> rw = new Vector<>();

        Iterator iter = d.iterator();
        while( iter.hasNext() ) {
            Object[] erg = ( Object[] )iter.next();
            VDiasArtikel art = new VDiasArtikel();
            art.setSaison( erg[0] != null ? toLong( erg[0] ) : null );
            art.setOriginalKatalogart( erg[1] != null ? ( String )erg[1] : null );
            art.setModellvariantennummer( erg[4] != null ? toLong( erg[4] ) : null );
            art.setArtikelbezeichnung( erg[9] != null ? ( String )erg[9] : null );
            art.setMengeneinheit( erg[7] != null ? ( String )erg[7] : null );
            art.setArtikelnummerWitt( erg[8] != null ? toLong( erg[8] ) : null );
            art.setFarbe( erg[10] != null ? ( String )erg[10] : null );
            art.setLieferantennummer( erg[12] != null ? toLong( erg[12] ) : null );
            art.setLieferantenname( erg[13] != null ? ( String )erg[13] : null );
            art.setModellvariantengroesse( erg[16] != null ? ( String )erg[16] : null );
            rw.add( art );
        }

        return rw;
    }

    @Override
    public Collection<VDiasArtikel> findByCriteria( String lkz, String artgr, String farbeId, String merkmalKlasse, String martkKz, Long aktSaison, int saison_zeitraum ) {

        Integer vonSaison = Integer.valueOf( aktSaison.intValue() - saison_zeitraum );

        StringBuffer sql = new StringBuffer();
        sql.append( "select /*+ USE_HASH(mv) */ * from mv_dias_artikel mv " );
        sql.append( "where mv.saison between " + vonSaison.toString() + " and " + aktSaison.toString() + " " );

        if( lkz != null ) {
            sql.append( "and mv.liefnr = " + lkz + " " );
        }

        if( artgr != null ) {
            sql.append( "and mv.mvgr = '" + artgr + "' " );
        }

        if( farbeId != null ) {
            sql.append( "and exists (select 1 " );
            sql.append( "from wertvorgabe w " );
            sql.append( "where w.merkmalvorlnr = " + FARBEN_MERKMALKLNR + " " );
            sql.append( "and w.farbdefid in (select f.id " );
            sql.append( "from farbdef f " );
            sql.append( "start with f.id = '" + farbeId + "' " );
            sql.append( "connect by prior f.id = f.farbdefid) " );
            sql.append( "and w.wert = mv.farbe ) " );
        }

        if( merkmalKlasse != null ) {
            sql.append( "and mv.merkmalklnr = " + merkmalKlasse + " " );
        }

        if( martkKz != null ) {
            sql.append( "and mv.marktkz = " + martkKz + " " );
        }

        sql.append( "order by mv.saison desc, mv.artnr6, mv.mvgr " );

        Query query = em.createNativeQuery( sql.toString() );
        return convert( query.getResultList() );

    }

    @Override
    public Collection<VDiasArtikel> findByCriteria( String artnr, Boolean isCrs, Long aktSaison, int saison_zeitraum ) {

        Integer vonSaison = Integer.valueOf( aktSaison.intValue() - saison_zeitraum );

        StringBuffer sql = new StringBuffer();
        sql.append( "select * from mv_dias_artikel " );
        sql.append( "where saison between " + vonSaison.toString() + " and " + aktSaison.toString() + " " );

        sql.append( "and artnr6 = " );

        // wenn übergebene Artiklenr CRS ist, Witt Artikelnr suchen
        if( isCrs.booleanValue() ) {
            sql.append( "(select artnr6 from alfa_art join alfa_fremd on ALFA_FREMD.ALFA_ARTID = alfa_art.id where ALFA_FREMD.ARTNRFREMD = '" + artnr + "' ) " );
        } else {
            sql.append( artnr + " " );
        }

        sql.append( "order by saison desc, artnr6, mvgr " );

        Query query = em.createNativeQuery( sql.toString() );
        return convert( query.getResultList() );
    }

    @Override
    public Collection<VDiasArtikel> sucheArtikel( String lkz, String artgr, String farbeId, String merkmalKlasse, String marktKz ) {

        // Wenn 11-stellig dann die normale LKZ ermitteln
        if( lkz != null && lkz.length() == 11 )
            lkz = getLKZFromZLKZAndBukr( lkz.substring( 0, 3 ), lkz.substring( 3, 11 ) );

        Collection artikel = null;

        Long aktSaison = getAktuelleSaison();

        artikel = findByCriteria( lkz, artgr, farbeId, merkmalKlasse, marktKz, aktSaison, Constants.SAISON_ZEITRAUM );
        //
        Integer vonSaison = Integer.valueOf( aktSaison.intValue() - Constants.SAISON_ZEITRAUM );

        StringBuffer sql = new StringBuffer();
        sql.append( "select /*+ USE_HASH(mv) */ * from mv_dias_artikel mv " );
        sql.append( "where mv.saison between " + vonSaison.toString() + " and " + aktSaison.toString() + " " );

        if( lkz != null ) {
            sql.append( "and mv.liefnr = " + lkz + " " );
        }

        if( artgr != null ) {
            sql.append( "and mv.mvgr = '" + artgr + "' " );
        }

        if( farbeId != null ) {
            sql.append( "and exists (select 1 " );
            sql.append( "from wertvorgabe w " );
            sql.append( "where w.merkmalvorlnr = " + Long.toString( FARBEN_MERKMALKLNR ) + " " );
            sql.append( "and w.farbdefid in (select f.id " );
            sql.append( "from farbdef f " );
            sql.append( "start with f.id = '" + farbeId + "' " );
            sql.append( "connect by prior f.id = f.farbdefid) " );
            sql.append( "and w.wert = mv.farbe ) " );
        }

        if( merkmalKlasse != null ) {
            sql.append( "and mv.merkmalklnr = " + merkmalKlasse + " " );
        }

        if( marktKz != null ) {
            sql.append( "and mv.marktkz = " + marktKz + " " );
        }

        sql.append( "order by mv.saison desc, mv.artnr6, mv.mvgr " );

        Query query = em.createNativeQuery( sql.toString() );
        return convert( query.getResultList() );

    }

    @Override
    public ErsatzartikelBean getErsatzartikel( String artnr6, String artgr, String saison ) {

        ErsatzartikelBean ersatzartikel = new ErsatzartikelBean();

        log.debug( "Eratzartikel für Artikelnummer (" + artnr6 + ") in Größe (" + artgr + ") laden..." );

        StringBuffer sb = new StringBuffer();
        
        sb.append(" select e.artnr6orig artnr6, aav.artbez, aav.farbe ");
        sb.append(" from v_ersatzartikel e ");
        sb.append(" join alfa_artvt aav on (aav.alfa_artid = e.alfa_artiders) ");
        sb.append(" join    vertrgebiet vt on (vt.id = aav.vertrgebietid) ");
        sb.append(" where aav.aktivkz = 'STA' ");
        sb.append(" and vt.vertrgebiet = 'I' ");
        sb.append(" and e.ersatzstatuskz = 2  ");
        sb.append(" and e.ersatzartkz = 3  ");
        sb.append(" and e.artnr6orig = " + artnr6  );
        sb.append(" and e.artgrorig = '" + artgr + "' " );
        sb.append(" and e.aktsaisoners = '" + saison + "'" );
        sb.append(" order by e.sortschl ");

        List<Object[]> resultList = em.createNativeQuery( sb.toString() ).getResultList();

        for( Object[] oa : resultList ) {
            ersatzartikel.setArtikelnummer( Long.valueOf( oa[0].toString() ) );
            ersatzartikel.setBezeichnung( oa[1].toString() );
            ersatzartikel.setFarbe( oa[2].toString() );
        }

        log.debug( "Folgender Ersatzartikel wurde ermittelt: " + ersatzartikel.getArtikelnummer() );

        return ersatzartikel;
    }


    @Override
    public long getAktuelleSaison() {
        String sql = "SELECT pkg_datum.f_get_saison( TRUNC( SYSDATE ) ) AS saison FROM dual";
        Query query = em.createNativeQuery( sql.toString() );
        Object o = query.getSingleResult();
        if( o != null ) {
            return toLong( o );
        }
        return -1;
    }

    @SuppressWarnings("unchecked")
    @Override
    public byte[] getBild( Long mvnr ) {
        List<Object[]> imageInfoList = em.createNativeQuery("""
                SELECT DISTINCT b.id AS bildId, meo.bildnr
                FROM   bild b
                JOIN   mediaobjekt meo ON meo.bildnr = b.bildnr
                JOIN   objektreferenz obr ON obr.meonr = meo.meonr
                JOIN   artikel art ON art.ARTID = obr.ARTID
                JOIN   mv ON mv.mvnr = obr.mvnr
                WHERE  art.id IN (
                        SELECT a.id
                        FROM   artikel a
                        JOIN   mv ON mv.mvnr = a.mvnr
                        JOIN   modell m ON mv.MODELLID = m.id
                        WHERE  m.id IN (
                                SELECT m2.id
                                from   artikel a2
                                join   mv mv2 ON mv2.mvnr = a2.mvnr
                                join   modell m2 ON mv2.modellid = m2.id
                                where  a2.mvnr = :mvnr
                               )
                       )
                ORDER  BY meo.bildnr
                """)
                .setParameter("mvnr", mvnr)
                .getResultList();

        if (imageInfoList.isEmpty()) {
            return null;
        }

        String imageId = String.valueOf(imageInfoList.get(0)[0]);
        String uriTemplate = "https://core-bild.ewp.witt-gruppe.cloud/ressource/image/%s/preview".formatted(imageId);
        return restTemplate.getForEntity(uriTemplate.formatted(imageId), byte[].class).getBody();
    }

    @Override
    public KatalogseiteBean getKatalogSeiteCas( Long saison, Long mvnr, String isoSpracheCode ) {

        log.debug( "Centera Seitenid holen mit Saison: " + saison.toString() + " Mvnr: " + mvnr );
        KatalogseiteBean seite = null;

        StringBuffer sql = new StringBuffer();

        sql.append( "select vksta.kattyp, vksta.katbez, k.cas, vkse.drsnr, vabb.abb " );
        sql.append( "from promotionmv pmv, v_promeinsatz vpmv, v_katabb vabb, " );
        sql.append( "v_katseite vks, v_katsta vksta, " );
        sql.append( "v_katwerbmitvers vkwm, v_katseiteeinsatz vkse, " );
        sql.append( "objektreferenz o, mediaobjekt m, kodac k, " );
        sql.append( "sprache sp, landsprache lsp, vertrgebiet vt " );
        sql.append( "where pmv.saison = vksta.saison " );
        sql.append( "and pmv.kattyp = vksta.kattyp " );
        sql.append( "and pmv.prommvnr = vpmv.prommvnr " );
        sql.append( "and vpmv.katabbid = vabb.id " );
        sql.append( "and vabb.katseiteid = vks.id " );
        sql.append( "and vks.id = vkse.katseiteid " );
        sql.append( "and vkse.katwerbmitversid = vkwm.id " );
        sql.append( "and vkwm.saison = vksta.saison " );
        sql.append( "and vkwm.kattyp = vksta.kattyp " );
        sql.append( "and vkwm.vertrgebiet = vt.vertrgebiet " );
        sql.append( "and vt.landspracheid = lsp.id " );
        sql.append( "and lsp.spracheid = sp.id " );
        if( isoSpracheCode != null ) {
            sql.append( "and sp.isolanguagecode = '" + isoSpracheCode.toUpperCase() + "' " );
            sql.append( "and vt.crskz = 'N' " );
        }
        sql.append( "and vkse.id = o.katseiteeinsatzid " );
        sql.append( "and vks.id = vkse.katseiteid " );
        sql.append( "and o.meonr = m.meonr " );
        sql.append( "and k.id = m.kodacid " );
        sql.append( "and k.art = 'JPEG' " );
        sql.append( "and pmv.mvnr = " + mvnr.toString() + " " );
        sql.append( "and pmv.saison = " + saison.toString() + " " );
        /*
         * sql.append("and pmv.kattyp = (select min(kattyp) "); sql.append("from promotionmv "); sql.append("where mvnr = " + mvnr.toString() + " "); sql.append("and saison = " + saison.toString() + ") ");
         */
        sql.append( "order by k.anldat desc " );

        Query query = em.createNativeQuery( sql.toString() );
        List<Object[]> resultList = query.getResultList();
        for( Object[] obj : resultList ) {

            seite = new KatalogseiteBean();
            // Transaktionsobjekt füllen
            seite.setKatTyp( obj[0].toString() );
            seite.setKatBez( obj[1].toString() );
            seite.setCenteraID( obj[2].toString() );
            seite.setDruckSeitenNr( obj[3] != null ?  Long.valueOf( obj[3].toString() ).longValue() : Long.valueOf(0) );
            seite.setAbbNr( obj[4].toString() );

        }

        return seite;
    }

    @Override
    public Collection sucheRechnungsPositionen( Kundenfirma kundenFirma, Long kdnr )  {
        return getRechnungsPositionen( null, kundenFirma, kdnr, false );
    }

    @Override
    public KundenrechnungskopfBean sucheRechnungsKopf( Long retschl, boolean onlyCH )  {

        KundenrechnungskopfBean rechKopf = null;

        String str_retschl = "-1";
        if( retschl != null )
            str_retschl = Long.valueOf( retschl.longValue() ).toString();

        StringBuffer sql = new StringBuffer();

        sql.append( "SELECT AA.ID                      AS AAID     " );
        sql.append( "      ,AA.KDNR                    AS KDNR     " );
        sql.append( "      ,AA.KDFIRMKZ                AS KDFIRMKZ " );
        sql.append( "FROM   FAKTAUFTRAG  AA                        " );
        sql.append( " WHERE AA.RETSCHL = '" + str_retschl + "'     " );
        sql.append( "   AND AA.BEARBSTATKZ <> 99                   " );
        sql.append( "   AND AA.RECHDAT > SYSDATE -(8*30)           " );
        if(onlyCH){
            sql.append(" and AA.kdfirmkz in (2,9,22,31,32) ");
        }
        sql.append( " ORDER BY AA.RECHDAT DESC                     " );

        Query query = em.createNativeQuery( sql.toString() );
        List<Object[]> resultList = query.getResultList();
        for( Object[] obj : resultList ) {

            rechKopf = new KundenrechnungskopfBean();

            String aaid = ( obj[0] != null ? obj[0].toString() : null );
            String kdnr = ( obj[1] != null ? obj[1].toString() : null );
            String kdfirmkz = ( obj[2] != null ? obj[2].toString() : null );
            rechKopf.setId( aaid );
            rechKopf.setRetoureschluessel( retschl );

            Long L_kdnr = Long.valueOf( kdnr ); // not null
            rechKopf.setKundennummer( L_kdnr );

            Kundenfirma kundenfirma = null;
            if( kdfirmkz != null ) {
                Query queryKundenfirma = em.createQuery( "select k from Kundenfirma k where k.kundenfirmenKennzeichen = ?1 " );
                queryKundenfirma.setParameter( 1, Long.valueOf( kdfirmkz ) );
                kundenfirma = ( Kundenfirma )queryKundenfirma.getSingleResult();
            }
            rechKopf.setKundenfirma( kundenfirma );

            break; // Nur 1. nehmen, siehe order By
        }

        return rechKopf;
    }

    public Collection sucheRechnungsPositionen( KundenrechnungskopfBean kopf ) {
        return getRechnungsPositionen( kopf, null, null, true );
    }

    public Collection getRechnungsPositionen( KundenrechnungskopfBean kopf, Kundenfirma kundenFirma, Long P_kdnr, boolean vonKopf ) {

        if( vonKopf ) {
            if( !( kopf != null && kopf.getId() != null ) )
                return null;
        } else {
            if( !( kundenFirma != null && kundenFirma.getKundenfirmenKennzeichen() != null && P_kdnr != null ) )
                return null;

        }
        Collection coll = new Vector();

        KundenrechnungskopfBean rechKopf = null;
        KunderechnungspositionBean position = null;
        String aaid_verg = "";
        Long L_kdnr = null;
        Kundenfirma kundenfirma = null;

        StringBuffer sql = new StringBuffer();

        sql.append( "SELECT AA.ID                       AS AAID         " );
        sql.append( "      ,AA.RETSCHL                  AS RETSCHL      " );
        sql.append( "      ,AA.KDNR                     AS KDNR         " );
        sql.append( "      ,AA.KDFIRMKZ                 AS KDFIRMKZ     " );
        sql.append( "      ,AA.RECHDAT                  AS RECHDAT      " );
        sql.append( "      ,AA.RECHTYPKZ                AS ZAHLUNGKZ    " );
        sql.append( "      ,CC.RETSCHLPOSNR            AS POSNR         " );
        sql.append( "      ,CC.FAKTARTNR6              AS ARTNR6        " );
        sql.append( "      ,CC.FAKTARTGR               AS ARTGR         " );
        sql.append( "      ,CC.FAKTPROMNR              AS PROMNR        " );
        sql.append( "      ,PKG_FAKT_GUTSCHR.GETGUTSCHRKZ( CC.ID, ',', 1 ) AS GUTSCHRKZ     " );
        sql.append( "      ,CC.ANZBEST                 AS BESTMG        " );
        sql.append( "      ,CC.METERBEST               AS METERBEST     " );
        sql.append( "      ,CC.ANZRATEN                AS RATENKZ       " );
        sql.append( "      ,CASE WHEN PKG_FAKT.METERWAREPOSITION( CC.METERKZ ) = 0 THEN PKG_FAKT_GUTSCHR.GETGUTSCHRMG( CC.ID ) ELSE NULL END AS GUTSCHRMG " );
        sql.append( "      ,CASE WHEN PKG_FAKT.METERWAREPOSITION( CC.METERKZ ) = 1 THEN PKG_FAKT_GUTSCHR.GETGUTSCHRMG( CC.ID ) ELSE NULL END AS GUTSCHRMETER " );
        sql.append( "      ,CC.LIKZ                    AS LKZ           " );
        sql.append( "      ,CC.ARTBEZ                  AS ARTBEZ        " );
        sql.append( "      ,CC.FARBE                   AS FARBE         " );
        sql.append( "      ,CC.METERKZ                 AS MGEINH        " );
        sql.append( "      ,CC.BESTBETRAG              AS BESTBETRAG    " );
        sql.append( "      ,CC.ID                      AS CCID          " );
        sql.append( "      ,NULL                       AS NALIWO        " );
        sql.append( "FROM                                               " );
        sql.append( "      FAKTAUFTRAG  AA                              " );
        sql.append( "     ,FAKTSENDUNG  BB                              " );
        sql.append( "     ,FAKTPOS      CC                              " );
        sql.append( " WHERE   BB.FAKTAUFTRAGID = AA.ID AND              " );
        sql.append( "         CC.FAKTSENDUNGID = BB.ID                  " );
        sql.append( "   AND   AA.BEARBSTATKZ <> 99                      " );
        if( vonKopf )
            sql.append( "   AND AA.ID       = '" + kopf.getId() + "'                 " );
        if( !vonKopf )
            sql.append( "   AND AA.KDNR     = '" + P_kdnr.toString() + "'            " );
        if( !vonKopf )
            sql.append( "   AND AA.KDFIRMKZ = '" + kundenFirma.getKundenfirmenKennzeichen().intValue() + "' " );
        sql.append( "   AND AA.RECHDAT > sysdate -(8*30)                                       " );
        sql.append( "   order by AA.RECHDAT DESC, AA.ID, CC.RETSCHLPOSNR                       " );

        Query query = em.createNativeQuery( sql.toString() );
        List<Object[]> resultList = query.getResultList();
        for( Object[] obj : resultList ) {

            String aaid = ( obj[0] != null ? obj[0].toString() : null );
            String retschl = ( obj[1] != null ? obj[1].toString() : null );
            String kdnr = ( obj[2] != null ? obj[2].toString() : null );
            String kdfirmkz = ( obj[3] != null ? obj[3].toString() : null );
            Date rechdat = ( obj[4] != null ? new Date( ((Timestamp )obj[4]).getTime()) : null );
            String zahlungkz = ( obj[5] != null ? obj[5].toString() : null );

            String posnr = ( obj[6] != null ? obj[6].toString() : null );
            String artnr6 = ( obj[7] != null ? obj[7].toString() : null );
            String artgr = ( obj[8] != null ? obj[8].toString() : null );
            String promnr = ( obj[9] != null ? obj[9].toString() : null );
            String gutschrkz = ( obj[10] != null ? obj[10].toString() : null );
            String bestmg = ( obj[11] != null ? obj[11].toString() : null );
            String meterbest = ( obj[12] != null ? obj[12].toString() : null );
            String ratenkz = ( obj[13] != null ? obj[13].toString() : null );
            String gutschrmg = ( obj[14] != null ? obj[14].toString() : null );
            String gutschrmeter = ( obj[15] != null ? obj[15].toString() : null );
            String lkz = ( obj[16] != null ? obj[16].toString() : null );
            String artbez = ( obj[17] != null ? obj[17].toString() : null );
            String farbe = ( obj[18] != null ? obj[18].toString() : null );
            String mgeinh = ( obj[19] != null ? obj[19].toString() : null );
            String bestbetrag = ( obj[20] != null ? obj[20].toString() : null );
            String ccid = ( obj[21] != null ? obj[21].toString() : null );
            String naliwo = ( obj[22] != null ? obj[22].toString() : "0" );

            Calendar cal = Calendar.getInstance();
            position = new KunderechnungspositionBean();

            if( !aaid_verg.equals( aaid ) ) {
                aaid_verg = aaid;

                rechKopf = new KundenrechnungskopfBean();
                rechKopf.setId( aaid );
                if( retschl != null )
                    rechKopf.setRetoureschluessel( Long.valueOf( retschl ) );

                L_kdnr = Long.valueOf( kdnr ); // not null
                rechKopf.setKundennummer( L_kdnr );

                cal.setTimeInMillis( rechdat.getTime() ); // not null
                rechKopf.setRechnungsdatum( cal );

                if( zahlungkz != null && zahlungkz.equals( "1" ) )
                    zahlungkz = "RK";
                if( zahlungkz != null && zahlungkz.equals( "2" ) )
                    zahlungkz = "RK";
                if( zahlungkz != null && zahlungkz.equals( "4" ) )
                    zahlungkz = "RK";
                if( zahlungkz != null && zahlungkz.equals( "3" ) )
                    zahlungkz = "NN";
                rechKopf.setZahlungskennzeichen( zahlungkz );

                if( kdfirmkz != null ) {
                    Query queryKundenfirma = em.createQuery( "select k from Kundenfirma k where k.kundenfirmenKennzeichen = ?1 " );
                    queryKundenfirma.setParameter( 1, Long.valueOf( kdfirmkz ) );
                    kundenfirma = ( Kundenfirma )queryKundenfirma.getSingleResult();
                }
                rechKopf.setKundenfirma( kundenfirma );
            } // endif aaid_verg also Kopf
              // Beginn Position
            position.setId( ccid );
            position.setKundennummer( L_kdnr );
            position.setKundenfirma( kundenfirma );
            cal.setTimeInMillis( rechdat.getTime() ); // not null
            position.setRechnungsdatum( cal );
            if( retschl != null )
                position.setRetoureschluessel( Long.valueOf( retschl ) );

            if( posnr != null )
                position.setPositionsnummer( Long.valueOf( posnr ) );
            if( artnr6 != null )
                position.setArtikelnummerWitt( Long.valueOf( artnr6 ) );
            if( artgr != null )
                position.setArtikelgroesse( artgr );
            if( promnr != null )
                position.setPromotionnummer( promnr );
            if( gutschrkz != null )
                position.setGutschriftkennzeichen( gutschrkz );
            if( ratenkz != null )
                position.setRatenkennzeichen( Long.valueOf( ratenkz ) );
            if( bestmg != null )
                position.setBestellmenge( Long.valueOf( bestmg ) );
            if( gutschrmg != null )
                position.setGutschriftmenge( Long.valueOf( gutschrmg ) );
            if( mgeinh != null && mgeinh.equals( "1" ) ) { // Meterware
                position.setBestellmenge( null );
                if( meterbest != null )
                    position.setBestellmenge((Double.valueOf(Double.parseDouble(meterbest) * 100)).longValue());
                position.setGutschriftmenge( null );
                if( gutschrmeter != null )
                    position.setGutschriftmenge((Double.valueOf(Double.parseDouble(gutschrmeter) * 100)).longValue());
            }

            if( lkz != null ) {
                Query queryLieferkennzeichen = em.createQuery( "select l from Lieferkennzeichen l where l.liKennzeichen = ?1 " );
                queryLieferkennzeichen.setParameter( 1, Long.valueOf( lkz ) );
                Lieferkennzeichen lief = ( Lieferkennzeichen )queryLieferkennzeichen.getSingleResult();
                position.setLieferkennzeichen( lief );
            }
            if( artbez != null )
                position.setArtikelbezeichnung( artbez );
            if( farbe != null )
                position.setFarbe( farbe );
            if( mgeinh != null )
                position.setMengeneinheit( Long.valueOf( mgeinh ) );
            if( bestbetrag != null )
                position.setBestellbetrag( Double.valueOf( bestbetrag ) );
            if( naliwo != null )
                position.setNALIWoche( Long.valueOf( naliwo ) );

            position.setKundenrechnungskopfBean( rechKopf );
            coll.add( position );
        } // endwhile

        return coll;

    }

    @Override
    public Collection sucheKunden( Long kdnr, boolean onlyCH ) {
        Query query;
        if(onlyCH){
            query = em.createQuery( "select k from Kunde k join fetch k.kundenfirma kf join fetch k.person p join fetch p.adresse where k.kundenNummer = ?1 and kf.kundenfirmenKennzeichen in (2,9,22,31,32) order by kf.kundenfirmenKennzeichen" );
        }else{
            query = em.createQuery( "select k from Kunde k join fetch k.kundenfirma kf join fetch k.person p join fetch p.adresse where k.kundenNummer = ?1 order by kf.kundenfirmenKennzeichen" );
        }
        query.setParameter( 1, kdnr );
        return query.getResultList();
    }

    @Override
    public Kunde sucheKunden( Kundenfirma firma, Long kdnr ) {

        Query query = em.createQuery( "select k from Kunde k join fetch k.kundenfirma kf join fetch k.person p join fetch p.adresse where kf.id = ?1 and k.kundenNummer = ?2 order by kf.kundenfirmenKennzeichen" );
        query.setParameter( 1, firma.getId() );
        query.setParameter( 2, kdnr );
        return ( Kunde )query.getSingleResult();
    }

    @Override
    public GroessenArtikelstamm sucheGroesseArtsta( Long artikelnummerWitt, String modellvariantengroesse ) {

        Query query = em.createQuery( "select g from GroessenArtikelstamm g where g.pk.artikelnummer6 = ?1 and g.pk.artikelGroesse = ?2 " );
        query.setParameter( 1, artikelnummerWitt );
        query.setParameter( 2, modellvariantengroesse );

        Object o = query.getSingleResult();
        if( o != null ) {
            return ( GroessenArtikelstamm )o;
        } else {
            log.debug( "Kein Satz in der Tabelle gr_artsta gefunden " + artikelnummerWitt.toString() + ", " + modellvariantengroesse );
            return null;
        }
    }

    @Override
    public Collection sucheParameter( String dvNummer ) {
        Query query = em.createQuery( "select p from Parameterverwaltung p where upper(p.parameterverwaltungPK.programmname) = ?1 and upper(p.parameterverwaltungPK.zielgruppe) = ?2 and upper(p.parameterverwaltungPK.gruppe) = ?3" );
        query.setParameter( 1, Constants.PARAM_PROGNAME.toUpperCase() );
        query.setParameter( 2, dvNummer );
        query.setParameter( 3, Constants.PARAM_PARAMGRP.toUpperCase() );

        return query.getResultList();
    }

    @Override
    public Boolean druckerAngeschlossen( String dvNummer ) {

        log.debug( "Suche Drucker fuer DV-NR: " + dvNummer );

        Query query = em
                .createQuery( "select p from Parameterverwaltung p where upper(p.parameterverwaltungPK.programmname) = ?1 and upper(p.parameterverwaltungPK.zielgruppe) = ?2 and upper(p.parameterverwaltungPK.gruppe) = ?3 and p.parameterverwaltungPK.bezeichnung = ?4" );
        query.setParameter( 1, Constants.PARAM_PROGNAME.toUpperCase() );
        query.setParameter( 2, dvNummer );
        query.setParameter( 3, Constants.PARAM_PARAMGRP.toUpperCase() );
        query.setParameter( 4, Constants.PARAM_MODELL.toUpperCase() );

        List<Parameterverwaltung> verw = query.getResultList();

        return !verw.isEmpty();

    }

    public Collection sucheKundenMitAnschrift( Collection personenIdCol ) {

        StringBuffer sql = new StringBuffer();
        Collection<KundeSearchBean> searchCol = new Vector<>();

        sql.append( "select k.kdnr, kf.kdfirmbez, kf.id, p.vname, p.nname, a.str, " );
        sql.append( "a.hsnr, a.plz, a.ort, a.hsnrzus1 " );
        sql.append( "from kunde k, kdart ka, kundenfirma kf, person p, adresse a " );
        sql.append( "where p.id in ( " );

        for( Iterator iter = personenIdCol.iterator(); iter.hasNext(); ) {
            sql.append( "'" + iter.next() + "'," );
        }
        // letztes "'" wegschneiden
        sql.deleteCharAt( sql.length() - 1 );
        sql.append( " )" );
        sql.append( "and p.id = k.personid " );
        sql.append( "and k.kundenfirmaid = kf.id " );
        sql.append( "and k.kdartid = ka.id " );
        sql.append( "and ka.kdart not in (53,54,57) " ); // Personaler
        // ausschließen
        sql.append( "and p.adresseid = a.id " );
        sql.append( "order by kf.kdfirmkz, k.kdnr " );

        Query query = em.createNativeQuery( sql.toString() );
        List<Object[]> resultList = query.getResultList();
        for( Object[] obj : resultList ) {

            KundeSearchBean searchBean = new KundeSearchBean();
            searchBean.setKdnr( obj[0] != null ? obj[0].toString() : "" );
            searchBean.setKdfirmBez( obj[1] != null ? obj[1].toString() : "" );
            searchBean.setKdfirmId( obj[2] != null ? obj[2].toString() : "" );
            searchBean.setVorName( obj[3] != null ? obj[3].toString() : "" );
            searchBean.setNachName( obj[4] != null ? obj[4].toString() : "" );
            searchBean.setStrasse( obj[5] != null ? obj[5].toString() : "" );
            searchBean.setHausNr( obj[6] != null ? obj[6].toString() : "" );
            searchBean.setPlz( obj[7] != null ? obj[7].toString() : "" );
            searchBean.setOrt( obj[8] != null ? obj[8].toString() : "" );
            searchBean.setHausNrZusatz( obj[9] != null ? obj[9].toString() : "" );

            searchCol.add( searchBean );
        }

        return searchCol;
    }

    @Override
    public void insertDiasStatistik( Long kdnr, Long artikelNr, String artgr, long erfassungsKz, String cn ) {

        StringBuffer sql = new StringBuffer();
        sql.append( "insert into dias_statistik values ( pkg_id.getid(), " );
        sql.append( artikelNr );
        sql.append( "," );
        sql.append( artgr );
        sql.append( "," );
        sql.append( erfassungsKz );
        sql.append( "," );
        sql.append( "(SELECT id FROM BENUTZER WHERE UPPER(DN) = UPPER( '" + cn + "'))" );
        sql.append( "," );
        sql.append( "sysdate" );
        sql.append( "," );
        sql.append( kdnr );
        sql.append( ")" );

        Query query = em.createNativeQuery( sql.toString() );
        query.executeUpdate();

    }

    @Override
    public Collection<StatistikBean> sucheDiasStatistikDaten( Calendar startCal, Calendar endCal ) {
        Collection<StatistikBean> reportCol = new ArrayList<>();

        StringBuffer sql = new StringBuffer();
        SimpleDateFormat sdfmt = new SimpleDateFormat( "dd.MM.yyyy" );
        DateUtils.truncate( startCal, Calendar.DAY_OF_MONTH );
        DateUtils.truncate( endCal, Calendar.DAY_OF_MONTH );

        sql.append( "select b.bednr, b.vname, b.nname,  count(*) as count " + "from benutzer b, dias_statistik d " + "where b.id = d.benutzerid " + "and trunc(d.erfdat) between to_date('" + sdfmt.format( startCal.getTime() )
                + "', 'DD.MM.YYYY') and " + "to_date('" + sdfmt.format( endCal.getTime() ) + "', 'DD.MM.YYYY') " + "group by b.bednr, b.vname, b.nname " + "order by b.nname " );

        Query query = em.createNativeQuery( sql.toString() );
        List<Object[]> resultList = query.getResultList();
        for( Object[] obj : resultList ) {

            StatistikBean statistikBean = new StatistikBean();
            statistikBean.setBedienerNr( obj[0] != null ? obj[0].toString() : "" );
            statistikBean.setVorname( obj[1] != null ? obj[1].toString() : "" );
            statistikBean.setNachname( obj[2] != null ? obj[2].toString() : "" );
            statistikBean.setAnzahl( obj[3] != null ? Integer.valueOf( toLong( obj[3] ).intValue() ) : Integer.valueOf( 0 ) );

            reportCol.add( statistikBean );
        }
        return reportCol;

    }

    public Collection<StatistikBean> sucheDiasStatistikDaten( Calendar startCal, Calendar endCal, Account account ) {

        SimpleDateFormat formatter = new SimpleDateFormat( "dd.MM.yyyy" );
        String vondat = formatter.format( startCal.getTime() );
        String bisdat = formatter.format( endCal.getTime() );
        StringBuffer sb = new StringBuffer();
        sb.append( " SELECT artgr, " );
        sb.append( "        artnr6, " );
        sb.append( "        identkz, " );
        sb.append( "        erfdat " );
        sb.append( "   FROM dias_statistik d, benutzer b " );
        sb.append( "  WHERE b.id = d.benutzerid " );
        sb.append( "    AND b.dn = 'CN=Schweiz Warenrücklauf02,OU=RL,OU=Heine,OU=konzern,DC=witt-ad,DC=wittgruppe,DC=eu' " );
        sb.append( "    AND d.erfdat BETWEEN TO_DATE ('" + vondat + "', 'dd.MM.yyyy') AND TO_DATE ('" + bisdat + "', 'dd.MM.yyyy') " );

        List<Object[]> resultList = em.createNativeQuery( sb.toString() ).getResultList();

        Collection<StatistikBean> rw = new Vector<>();
        for( Object[] oa : resultList ) {

            StatistikBean statistikBean = new StatistikBean();
            statistikBean.setArtikelGroesse( oa[0].toString() );
            statistikBean.setArtikelNummer( Long.valueOf( oa[1].toString() ) );
            int eintrag = Integer.parseInt( oa[2].toString() );
            statistikBean.setErfassungsDatum( ( Date )oa[3] );

            switch( eintrag ) {
            case Constants.STATISTIK_ARTIKEL_SEARCH :
                statistikBean.setIdentKzString( "Artikelsuche" );
                break;
            case Constants.STATISTIK_ARTIKEL_CRS_SEARCH :
                statistikBean.setIdentKzString( "Artikelsuche(Artikelnummer)" );
                break;
            case Constants.STATISTIK_RECHNUNG_SEARCH :
                statistikBean.setIdentKzString( "Kundenrechnungssauuche" );
                break;
            default :
                break;
            }
            statistikBean.setIdentKz((long) eintrag);
            statistikBean.setTruncErfassungsDatum( ( ( Date )oa[3] ) );
            rw.add( statistikBean );
        }

        return rw;

    }

    @Override
    public Bestandsfirma sucheBestandsFirma( int firmKz ) {

        Query queryBestandsfirma = em.createQuery( "select b from Bestandsfirma b where b.kennzeichen = ?1 " );
        queryBestandsfirma.setParameter( 1, (long) firmKz);
        Bestandsfirma bestandsfirma = ( Bestandsfirma )queryBestandsfirma.getSingleResult();

        return bestandsfirma;
    }

    @Override
    public OriginalArtikelstamm sucheOriginalArtikel( Long saison, Long artikelNr ) {

        Query query = em.createQuery( "select o from OriginalArtikelstamm o where o.pk.herkunftssaison = ?1 and o.pk.artikelnummer6 = ?2 " );
        query.setParameter( 1, saison );
        query.setParameter( 2, artikelNr );

        return ( OriginalArtikelstamm )query.getSingleResult();
    }

    @Override
    public String sucheLagerkoordinate( Long artikelNr, String artgr ) {

        StringBuffer sb = new StringBuffer();
        sb.append( " SELECT koord " );
        sb.append( "   FROM LG_GR_ARTSTA " );
        sb.append( "  WHERE ARTNR6 = ?1 AND ARTGR = ?2 " );

        Query query = em.createNativeQuery( sb.toString() );
        query.setParameter( 1, artikelNr );
        query.setParameter( 2, artgr );

        Object o = query.getSingleResult();
        if( o != null ) {
            return ( String )o;
        }
        // INCIDENT-186839 avoid "null"
        return "000000000000";
    }

    @Override
    public String formatLagerKoord( String koord ) {

        List resultList = em.createNativeQuery( "select pkg_lg.format('" + koord + "', 'LL.HH.GGG.FF.EE.P') from dual " ).getResultList();

        Iterator iter = resultList.iterator();
        while( iter.hasNext() ) {
            Object o = iter.next();
            return o.toString();
        }
        return "";
    }

}

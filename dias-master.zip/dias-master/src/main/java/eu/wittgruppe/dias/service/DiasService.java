package eu.wittgruppe.dias.service;

import eu.wittgruppe.dias.bean.*;
import eu.wittgruppe.dias.domain.*;
import witt.josef.benutzerverwaltung.Account;

import java.util.Calendar;
import java.util.Collection;

public interface DiasService {

    public String getLKZFromZLKZAndBukr( String bukr, String zlkz );

    public Collection sucheLieferanten();

    public Collection<MerkmalklasseDiamant> sucheMerkmalsKlassen();

    public Collection<Marktkennzeichen> sucheMarktKennzeichen( MerkmalklasseDiamant klasse );

    public Collection<Marktkennzeichen> sucheAllMarktKennzeichen();

    public Collection<FarbeDefBean> sucheFarben( String farbe );

    public Collection<VDiasArtikel> sucheArtikel( String artnr, Boolean isCrs );

    public Collection<VDiasArtikel> findByCriteria( String lkz, String artgr, String farbeId, String merkmalKlasse, String martkKz, Long aktSaison, int saison_zeitraum );

    public Collection<VDiasArtikel> findByCriteria( String artnr, Boolean isCrs, Long aktSaison, int saison_zeitraum );

    public Collection<VDiasArtikel> sucheArtikel( String lkz, String artgr, String farbeId, String merkmalKlasse, String marktKz );

    public ErsatzartikelBean getErsatzartikel( String artnr6, String artgr, String saison );

    public long getAktuelleSaison();

    public byte[] getBild( Long mvnr );

    public KatalogseiteBean getKatalogSeiteCas( Long saison, Long mvnr, String isoSpracheCode );

    public Collection sucheRechnungsPositionen( Kundenfirma kundenFirma, Long kdnr );

    public KundenrechnungskopfBean sucheRechnungsKopf( Long retschl, boolean onlyCH );

    public Collection sucheRechnungsPositionen( KundenrechnungskopfBean kopf );

    public Collection getRechnungsPositionen( KundenrechnungskopfBean kopf, Kundenfirma kundenFirma, Long P_kdnr, boolean vonKopf );

    public Collection sucheKunden( Long kdnr, boolean onlyCH );

    public Kunde sucheKunden( Kundenfirma firma, Long kdnr );

    public GroessenArtikelstamm sucheGroesseArtsta( Long artikelnummerWitt, String modellvariantengroesse );

    public Collection sucheParameter( String dvNummer );

    public Boolean druckerAngeschlossen( String dvNummer );

    public Collection sucheKundenMitAnschrift( Collection personenIdCol );

    public void insertDiasStatistik( Long kdnr, Long artikelNr, String artgr, long erfassungsKz, String cn );

    public Collection<StatistikBean> sucheDiasStatistikDaten( Calendar startCal, Calendar endCal );

    public Collection<StatistikBean> sucheDiasStatistikDaten( Calendar startCal, Calendar endCal, Account account );

    public OriginalArtikelstamm sucheOriginalArtikel( Long saison, Long artikelNr );

    public String sucheLagerkoordinate( Long artikelNr, String artgr );

    public String formatLagerKoord( String koord );

    public Bestandsfirma sucheBestandsFirma( int firmKz );

}

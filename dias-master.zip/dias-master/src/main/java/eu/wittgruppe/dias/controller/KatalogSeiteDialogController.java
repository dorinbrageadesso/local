package eu.wittgruppe.dias.controller;

import eu.wittgruppe.dias.bean.KatalogseiteBean;
import eu.wittgruppe.dias.ui.KatalogSeiteDialog;
import witt.josef.uiswing.ui.ImageLabel;
import witt.josef.uiswing.ui.UIUtils;

import javax.swing.*;

public class KatalogSeiteDialogController {

	private KatalogSeiteDialog seiteDialog = null;
	private KatalogseiteBean seiteBean = null;
	private ArtikelSearchController parentController = null;
	private byte[] seite = null;
	private Long artnr6 = null;

	public KatalogSeiteDialogController(ArtikelSearchController parentController, 
										KatalogseiteBean seiteBean, 
										byte[] seite,
										Long artnr6) {
		super();
		this.seite = seite;
		this.parentController = parentController;
		this.seiteBean = seiteBean;
		this.artnr6 = artnr6;
	}

	public void showDialog() {
				 
		seiteDialog = new KatalogSeiteDialog(parentController.getParentController().getMainWindow(), 
											 this);
		UIUtils.centerOverComponent(parentController.getParentController()
													.getMainWindow(), seiteDialog);
		
		// Header mit Seiteninformationen füllen
		seiteDialog.getKatalogTextField().setText(seiteBean.getKatTyp() + " " + 
											 	  seiteBean.getKatBez());
		seiteDialog.getSeiteTextField().setText(seiteBean.getDruckSeitenNr().toString());
		seiteDialog.getAbbTextField().setText(seiteBean.getAbbNr());
		seiteDialog.getArtnrTextField().setText(artnr6.toString());
		// Dialog anzeigen und seite skaliren
		seiteDialog.setVisible(true);
		//seiteDialog.setSize(1024, 768);
		//seiteDialog.getSeiteScrollPane().getViewport().setSize(1024,768);
		//seiteDialog.getSeiteScrollPane().getViewport().setPreferredSize(new Dimension(1024,768));		
		
		if (seite != null) {
			scalePicture(new Double( seiteDialog.getZoomSlider().getValue() ).doubleValue() / 100, seiteDialog.getSeiteScrollPane());
		}
		else {
			seiteDialog.getSeiteLabel().setText("keine Katalogseite gefunden");
		}
				
				
	}
	
	public void scalePicture( double scale, JScrollPane scrollPane ) {

      
        // aktuelle Anzeige resetten
        scrollPane.getViewport().removeAll();
        /*
        // Größe des akutellen Bildes ermitteln
        ImageIcon icon = new ImageIcon( seite );
        double iconHeight = icon.getIconHeight();
        double iconWidth = icon.getIconWidth();

        // Größe der sichtbaren Fläche ermitteln
        double viewHeight = scrollPane.getViewportBorderBounds().getHeight() * scale;
        double viewWidth = scrollPane.getViewportBorderBounds().getWidth() * scale;

        // Breite des möglicherweise erscheinenden ScrollBars
        // ermitteln
        // und sichtbare Fläche entsprechend sichtbaren Scrollbars
        // korrigieren.
        JScrollBar hor = scrollPane.getHorizontalScrollBar();
        JScrollBar ver = scrollPane.getVerticalScrollBar();
        int scrollBarWidth = 0;

        if( hor != null ) {
            int width = ( int )hor.getUI().getPreferredSize( hor ).getHeight();
            scrollBarWidth = width;
            viewHeight += ( hor.isVisible() ? width : 0 );
        }

        if( ver != null ) {
            int width = ( int )ver.getUI().getPreferredSize( ver ).getWidth();
            scrollBarWidth = ( ( scrollBarWidth == 0 ) ? width : scrollBarWidth );
            viewWidth += ( ver.isVisible() ? width : 0 );
        }

        // Neue Bildgröße berechnen
        for( int i = 0; i < 2; i++ ) {
            double scaleFactor = viewHeight / iconHeight;

            iconHeight *= scaleFactor;
            iconWidth *= scaleFactor;

            // Die erhöhte Breite hat zur Folge, dass ein ScrollBar
            // angezeigt wird -> muß berücksichtigt und die
            // Berechnung wiederholt werden!
            if( ( i < 1 ) && ( iconWidth > viewWidth ) ) {
                viewHeight -= scrollBarWidth;
            }
        }

        // Bild umrechnen
        Image image = icon.getImage();
        image = image.getScaledInstance( ( int )iconWidth, ( int )iconHeight, Image.SCALE_DEFAULT );
        icon.setImage( image );        
   
        // Bild anzeigen
        */
        seiteDialog.seiteLabel = new ImageLabel(seite, scale, false);
        scrollPane.getViewport().add(seiteDialog.seiteLabel);
        seiteDialog.getSeiteLabel().revalidate();
        /*
        // Wenn das Bild zu breit ist -> in die Mitte scrollen
        if( iconWidth > viewWidth ) {
            int x = ( int )( iconWidth - viewWidth ) / 2;
            int y = 0;
            int h = ( int )viewHeight;
            int w = ( int )viewWidth;
            scrollPane.getViewport().scrollRectToVisible( new Rectangle( x, y, w, h ) );
        }
        */      	
    }
    
	
	public void closeDialog() {
		seiteDialog.setVisible(false);	
		seiteDialog.dispose();
	}
	

}

package eu.wittgruppe.dias.domain;

import jakarta.persistence.*;
import java.io.Serializable;

@Embeddable
public class OriginalArtikelstammPK implements Serializable {

	private static final long serialVersionUID = 1L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "saison", referencedColumnName = "saison")
	private Saison saison = null;

	@Column(name = "ARTNR6")
	private Long artikelnummer6 = null;

	public OriginalArtikelstammPK() {
	}

	public OriginalArtikelstammPK(Long artikelnummer6, Saison saison) {
		super();
		this.artikelnummer6 = artikelnummer6;
		this.saison = saison;
	}

	public Saison getSaison() {
		return saison;
	}

	public void setSaison(Saison saison) {
		this.saison = saison;
	}

	public Long getArtikelnummer6() {
		return artikelnummer6;
	}

	public void setArtikelnummer6(Long artikelnummer6) {
		this.artikelnummer6 = artikelnummer6;
	}

}

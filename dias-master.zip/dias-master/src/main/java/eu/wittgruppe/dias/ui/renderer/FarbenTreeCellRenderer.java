package eu.wittgruppe.dias.ui.renderer;

import eu.wittgruppe.dias.bean.FarbeDefBean;
import eu.wittgruppe.dias.util.Images;
import eu.wittgruppe.dias.util.TreeNodeBean;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import java.awt.*;

public class FarbenTreeCellRenderer extends DefaultTreeCellRenderer {

	public FarbenTreeCellRenderer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Component getTreeCellRendererComponent(JTree tree, 
												  Object value, 
												  boolean sel, 
												  boolean expanded, 
												  boolean leaf, 
												  int row, 
												  boolean hasFocus) {
		super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);		
		
			
		DefaultMutableTreeNode node = (DefaultMutableTreeNode)value;
		
		if (!node.isRoot()) {
			TreeNodeBean nodeVO = (TreeNodeBean)node.getUserObject();
			FarbeDefBean farbe = (FarbeDefBean)nodeVO.getValueObject();
			
			if (farbe.getLevel().longValue()==1) {
				this.setIcon(Images.FARBE_LEVEL1);
			}
			else if (farbe.getLevel().longValue()==2) {
				this.setIcon(Images.FARBE_LEVEL2);
			}
			else if (farbe.getLevel().longValue()==3) {
				this.setIcon(Images.FARBE_LEVEL3);
			}					
		}	
		
		return this;
	}
	
}

package eu.wittgruppe.dias.ui;

import eu.wittgruppe.dias.bean.FarbeDefBean;
import eu.wittgruppe.dias.controller.ArtikelSearchController;
import eu.wittgruppe.dias.controller.FarbenChooserController;
import eu.wittgruppe.dias.controller.LieferantenChooserController;
import eu.wittgruppe.dias.controller.MerkmalsKlassenChooserController;
import eu.wittgruppe.dias.domain.Marktkennzeichen;
import eu.wittgruppe.dias.domain.MerkmalklasseDiamant;
import eu.wittgruppe.dias.util.Constants;
import eu.wittgruppe.dias.util.Images;
import eu.wittgruppe.dias.util.TreeNodeBean;
import org.apache.commons.lang.StringUtils;
import witt.josef.uiswing.ui.LimitedDocument;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;

public class ArtikelSearchCriteriaPanel extends GradientPanel {
	
	private ArtikelSearchController controller = null;
	
	private JLabel lkzLabel = null;
	private JTextField lkzTextField = null;
	private JButton lkzSearchButton = null;
	private JLabel artgrLabel = null;
	private JTextField artgrTextField = null;
	private JLabel farbenLabel = null;
	private JLabel merkmalLabel = null;
	private ValueTextField merkmalKlasseTextField = null;
	private JButton merkmalsKlassenSearchButton = null;
	private JButton searchButton = null;
	private JLabel spaceholderLabel = null;

	private ValueTextField farbeTextField = null;

	private JButton farbenButton = null;

	private JLabel clearFarbenLabel = null;

	private JLabel clearMerkmalLabel = null;

	public ArtikelSearchCriteriaPanel(ArtikelSearchController controller) {
	
		super();		
		this.controller = controller;	
		
		initialize();
	}

	

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {		
				
		GridBagConstraints gridBagConstraints6 = new GridBagConstraints();
		gridBagConstraints6.gridx = 8;
		gridBagConstraints6.insets = new java.awt.Insets(12,0,0,2);
		gridBagConstraints6.anchor = java.awt.GridBagConstraints.SOUTHEAST;
		gridBagConstraints6.gridy = 0;
		clearMerkmalLabel = new JLabel();
		clearMerkmalLabel.setToolTipText("Merkmal zurücksetzen");
		clearMerkmalLabel.setIcon(Images.CLEAR_CO);
		clearMerkmalLabel.addMouseListener(new OnMouseMoveMerkmalLabel());
		GridBagConstraints gridBagConstraints5 = new GridBagConstraints();
		gridBagConstraints5.gridx = 5;
		gridBagConstraints5.insets = new java.awt.Insets(12,0,0,2);
		gridBagConstraints5.anchor = java.awt.GridBagConstraints.SOUTHEAST;
		gridBagConstraints5.gridy = 0;
		clearFarbenLabel = new JLabel();
		clearFarbenLabel.setIcon(Images.CLEAR_CO);
		clearFarbenLabel.setToolTipText("Farbe zurücksetzen");
		clearFarbenLabel.addMouseListener(new OnMouseMoveFarbenLabel());
		
		GridBagConstraints gridBagConstraints2 = new GridBagConstraints();
		gridBagConstraints2.gridx = 6;
		gridBagConstraints2.insets = new java.awt.Insets(0,2,5,0);
		gridBagConstraints2.anchor = java.awt.GridBagConstraints.CENTER;
		gridBagConstraints2.gridy = 1;
		GridBagConstraints gridBagConstraints14 = new GridBagConstraints();
		gridBagConstraints14.fill = java.awt.GridBagConstraints.NONE;
		gridBagConstraints14.gridy = 1;
		gridBagConstraints14.weightx = 0.0;
		gridBagConstraints14.insets = new java.awt.Insets(0,2,8,0);
		gridBagConstraints14.anchor = java.awt.GridBagConstraints.CENTER;
		gridBagConstraints14.gridwidth = 2;
		gridBagConstraints14.gridx = 4;
		GridBagConstraints gridBagConstraints17 = new GridBagConstraints();
		gridBagConstraints17.gridx = 11;
		gridBagConstraints17.weightx = 1.0D;
		gridBagConstraints17.gridy = 1;
		spaceholderLabel = new JLabel();
		spaceholderLabel.setText("JLabel");
		spaceholderLabel.setMinimumSize(new java.awt.Dimension(1,16));
		spaceholderLabel.setPreferredSize(new java.awt.Dimension(1,16));
		spaceholderLabel.setMaximumSize(new java.awt.Dimension(1111111,16));
		GridBagConstraints gridBagConstraints16 = new GridBagConstraints();
		gridBagConstraints16.gridx = 10;
		gridBagConstraints16.insets = new java.awt.Insets(0,5,15,0);
		gridBagConstraints16.anchor = java.awt.GridBagConstraints.NORTH;
		gridBagConstraints16.gridy = 1;
		GridBagConstraints gridBagConstraints15 = new GridBagConstraints();
		gridBagConstraints15.gridx = 7;
		gridBagConstraints15.anchor = java.awt.GridBagConstraints.NORTHWEST;
		gridBagConstraints15.insets = new java.awt.Insets(0,5,10,0);
		gridBagConstraints15.gridy = 1;
		GridBagConstraints gridBagConstraints13 = new GridBagConstraints();
		gridBagConstraints13.gridx = 9;
		gridBagConstraints13.anchor = java.awt.GridBagConstraints.CENTER;
		gridBagConstraints13.insets = new java.awt.Insets(0,2,5,0);
		gridBagConstraints13.gridy = 1;
		GridBagConstraints gridBagConstraints12 = new GridBagConstraints();
		gridBagConstraints12.fill = java.awt.GridBagConstraints.HORIZONTAL;
		gridBagConstraints12.gridy = 1;
		gridBagConstraints12.weightx = 0.0D;
		gridBagConstraints12.anchor = java.awt.GridBagConstraints.CENTER;
		gridBagConstraints12.insets = new java.awt.Insets(0,2,8,0);
		gridBagConstraints12.gridwidth = 2;
		gridBagConstraints12.gridx = 7;
		GridBagConstraints gridBagConstraints11 = new GridBagConstraints();
		gridBagConstraints11.gridx = 7;
		gridBagConstraints11.insets = new java.awt.Insets(12,2,0,0);
		gridBagConstraints11.anchor = java.awt.GridBagConstraints.SOUTHWEST;
		gridBagConstraints11.gridy = 0;
		merkmalLabel = new JLabel();
		merkmalLabel.setText("Merkmalsklasse:");
		GridBagConstraints gridBagConstraints9 = new GridBagConstraints();
		gridBagConstraints9.gridx = 4;
		gridBagConstraints9.anchor = java.awt.GridBagConstraints.SOUTHWEST;
		gridBagConstraints9.insets = new java.awt.Insets(12,2,0,0);
		gridBagConstraints9.gridy = 0;
		farbenLabel = new JLabel();
		farbenLabel.setText("Farben:");
		farbenLabel.setMinimumSize(new java.awt.Dimension(42,16));
		farbenLabel.setPreferredSize(new java.awt.Dimension(42,16));
		farbenLabel.setMaximumSize(new java.awt.Dimension(42,16));
		GridBagConstraints gridBagConstraints8 = new GridBagConstraints();
		gridBagConstraints8.fill = java.awt.GridBagConstraints.NONE;
		gridBagConstraints8.gridy = 1;
		gridBagConstraints8.weightx = 0.0D;
		gridBagConstraints8.anchor = java.awt.GridBagConstraints.CENTER;
		gridBagConstraints8.insets = new java.awt.Insets(0,2,8,0);
		gridBagConstraints8.gridx = 3;
		GridBagConstraints gridBagConstraints7 = new GridBagConstraints();
		gridBagConstraints7.gridx = 3;
		gridBagConstraints7.insets = new java.awt.Insets(12,2,0,0);
		gridBagConstraints7.anchor = java.awt.GridBagConstraints.SOUTHWEST;
		gridBagConstraints7.gridy = 0;
		artgrLabel = new JLabel();
		artgrLabel.setText("ArtGr.:");
		artgrLabel.setMinimumSize(new java.awt.Dimension(42,16));
		artgrLabel.setPreferredSize(new java.awt.Dimension(42,16));
		artgrLabel.setMaximumSize(new java.awt.Dimension(42,16));
		GridBagConstraints gridBagConstraints4 = new GridBagConstraints();
		gridBagConstraints4.gridx = 1;
		gridBagConstraints4.anchor = java.awt.GridBagConstraints.CENTER;
		gridBagConstraints4.insets = new java.awt.Insets(0,2,5,0);
		gridBagConstraints4.gridy = 1;
		GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
		gridBagConstraints1.gridx = 0;
		gridBagConstraints1.anchor = java.awt.GridBagConstraints.SOUTHWEST;
		gridBagConstraints1.gridheight = 1;
		gridBagConstraints1.gridwidth = 1;
		gridBagConstraints1.insets = new java.awt.Insets(12,5,0,0);
		gridBagConstraints1.gridy = 0;
		GridBagConstraints gridBagConstraints = new GridBagConstraints();
		gridBagConstraints.ipadx = 20;
		gridBagConstraints.fill = java.awt.GridBagConstraints.NONE;
		gridBagConstraints.gridy = 1;
		gridBagConstraints.weightx = 0.0D;
		gridBagConstraints.gridwidth = 1;
		gridBagConstraints.gridheight = 1;
		gridBagConstraints.anchor = java.awt.GridBagConstraints.CENTER;
		gridBagConstraints.insets = new java.awt.Insets(0,5,8,0);
		gridBagConstraints.gridx = 0;
		lkzLabel = new JLabel();
		lkzLabel.setText("(Z)LKZ:");
		lkzLabel.setMinimumSize(new java.awt.Dimension(52,16));
		lkzLabel.setPreferredSize(new java.awt.Dimension(52,16));
		lkzLabel.setMaximumSize(new java.awt.Dimension(52,16));
		this.setLayout(new GridBagLayout());
		this.setSize(725, 69);
		this.setComponentOrientation(java.awt.ComponentOrientation.LEFT_TO_RIGHT);
		this.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.gray,1));
		this.setMaximumSize(new java.awt.Dimension(596,97));
		this.setMinimumSize(new java.awt.Dimension(596,97));
		this.add(lkzLabel, gridBagConstraints1);
		this.add(getLkzTextField(), gridBagConstraints);
		this.add(getLkzSearchButton(), gridBagConstraints4);
		this.add(artgrLabel, gridBagConstraints7);
		this.add(getArtgrTextField(), gridBagConstraints8);
		this.add(farbenLabel, gridBagConstraints9);
		this.add(merkmalLabel, gridBagConstraints11);
		this.add(getMerkmalKlasseTextField(), gridBagConstraints12);
		this.add(getMerkmalsKlassenSearchButton(), gridBagConstraints13);
		
		this.add(spaceholderLabel, gridBagConstraints17);
		this.add(getFarbeTextField(), gridBagConstraints14);
		this.add(getFarbenButton(), gridBagConstraints2);
		this.add(getSearchButton(), gridBagConstraints16);
		this.add(clearFarbenLabel, gridBagConstraints5);
		this.add(clearMerkmalLabel, gridBagConstraints6);
		
		
	}	

	/**
	 * This method initializes lkzTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	public JTextField getLkzTextField() {
		if (lkzTextField == null) {
			lkzTextField = new JTextField();			
			LimitedDocument doc = new LimitedDocument(11, LimitedDocument.NUMBER);
			lkzTextField.setDocument(doc);
			lkzTextField.setMaximumSize(new java.awt.Dimension(60,21));
			lkzTextField.setMinimumSize(new java.awt.Dimension(60,21));
			lkzTextField.setPreferredSize(new java.awt.Dimension(60,21));
		}
		return lkzTextField;
	}

	/**
	 * This method initializes lkzSearchButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getLkzSearchButton() {
		if (lkzSearchButton == null) {
			lkzSearchButton = new JButton();
			lkzSearchButton.setText("...");
			lkzSearchButton.setMinimumSize(new java.awt.Dimension(33,16));
			lkzSearchButton.setPreferredSize(new java.awt.Dimension(33,16));
			lkzSearchButton.setToolTipText("Lieferant suchen");
			lkzSearchButton.setMaximumSize(new java.awt.Dimension(33,16));
			
			lkzSearchButton.addActionListener(new OnLkzSearchButtonClicked());
		}
		return lkzSearchButton;
	}

	/**
	 * This method initializes artgrTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	public JTextField getArtgrTextField() {
		if (artgrTextField == null) {
			artgrTextField = new JTextField();
			LimitedDocument doc = new LimitedDocument(4);
			artgrTextField.setDocument(doc);
			artgrTextField.setMaximumSize(new java.awt.Dimension(52,21));
			artgrTextField.setPreferredSize(new java.awt.Dimension(52,21));
			artgrTextField.setMinimumSize(new java.awt.Dimension(52,21));
		}
		return artgrTextField;
	}

	/**
	 * This method initializes merkmalKlasseTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	public ValueTextField getMerkmalKlasseTextField() {
		if (merkmalKlasseTextField == null) {
			merkmalKlasseTextField = new ValueTextField();
			merkmalKlasseTextField.setPreferredSize(new java.awt.Dimension(200,21));
			merkmalKlasseTextField.setMaximumSize(new java.awt.Dimension(200,21));
			merkmalKlasseTextField.setBackground(new java.awt.Color(231,235,235));
			merkmalKlasseTextField.setEnabled(false);
			merkmalKlasseTextField.setDisabledTextColor(java.awt.Color.black);
			merkmalKlasseTextField.setMinimumSize(new java.awt.Dimension(200,21));
		}
		return merkmalKlasseTextField;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getMerkmalsKlassenSearchButton() {
		if (merkmalsKlassenSearchButton == null) {
			merkmalsKlassenSearchButton = new JButton();
			merkmalsKlassenSearchButton.setMaximumSize(new java.awt.Dimension(33,16));
			merkmalsKlassenSearchButton.setPreferredSize(new java.awt.Dimension(33,16));
			merkmalsKlassenSearchButton.setText("...");
			merkmalsKlassenSearchButton.setToolTipText("Merkmalsklasse auswählen");
			merkmalsKlassenSearchButton.setMinimumSize(new java.awt.Dimension(33,16));
			merkmalsKlassenSearchButton.addActionListener(new OnMerkmalsKlassenSearchButtonClicked());
		}
		return merkmalsKlassenSearchButton;
	}

	/**
	 * This method initializes searchButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getSearchButton() {
		if (searchButton == null) {
			searchButton = new JButton();
			searchButton.setText("Suchen (F3)");
			searchButton.setMinimumSize(new java.awt.Dimension(115,26));
			searchButton.setMaximumSize(new java.awt.Dimension(115,26));
			searchButton.setToolTipText("Artikel suchen");
			searchButton.setPreferredSize(new java.awt.Dimension(115,26));
			OnSearchButtonClicked listener = new OnSearchButtonClicked(); 
			searchButton.addActionListener(listener);
			searchButton.registerKeyboardAction( listener, 
												 "F3", KeyStroke.getKeyStroke( KeyEvent.VK_F3, 0 ), 
												 JComponent.WHEN_IN_FOCUSED_WINDOW );
			searchButton.registerKeyboardAction( listener, 
					 "ENTER", KeyStroke.getKeyStroke( KeyEvent.VK_ENTER, 0 ), 
					 JComponent.WHEN_IN_FOCUSED_WINDOW );	
		}
		return searchButton;
	}
	
	/**
	 * This method initializes frabeTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	public ValueTextField getFarbeTextField() {
		if (farbeTextField == null) {
			farbeTextField = new ValueTextField();
			farbeTextField.setMaximumSize(new java.awt.Dimension(150,21));
			farbeTextField.setPreferredSize(new java.awt.Dimension(150,21));
			farbeTextField.setEnabled(false);
			farbeTextField.setBackground(new java.awt.Color(231,235,235));
			farbeTextField.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
			farbeTextField.setDisabledTextColor(java.awt.Color.black);
			farbeTextField.setMinimumSize(new java.awt.Dimension(150,21));
		}
		return farbeTextField;
	}



	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getFarbenButton() {
		if (farbenButton == null) {
			farbenButton = new JButton();
			farbenButton.setMaximumSize(new Dimension(33, 16));
			farbenButton.setPreferredSize(new Dimension(33, 16));
			farbenButton.setText("...");
			farbenButton.setToolTipText("Farbe auswählen");
			farbenButton.setMinimumSize(new Dimension(33, 16));
			farbenButton.addActionListener(new OnFarbenButtonClicked());
			
		}
		return farbenButton;
	}
	
	
	/**
	 * Prüft die Eingabewerte und startet die Artikelsuche
	 */
	private void searchArtikel() {
		int anzCriterias = 0;
		// Werte aus den Eingabefeldern holen
		// LKZ
		String lkz = null;		
		if ( StringUtils.isNotEmpty( getLkzTextField().getText())  ) {
			lkz = getLkzTextField().getText();
			
			//Wenn 8-stellige ZLKZ dann Suchfenster öffnen
			if (lkz.length() == 8){
				
				LieferantenChooserController lieferantenController = new LieferantenChooserController(controller);
				lieferantenController.showDialog();
				lieferantenController.getChooser().getZlkzTextField().setText(lkz);
				lieferantenController.filterLieferantenByZentralLiefnr(controller.getParentController().getLieferanten(), lkz);		
				lieferantenController.getChooser().getZlkzTextField().requestFocus();
				
				return;
			}
			
			//LKZ auf Gültigkeit prüfen (entweder 5/6 oder 11-stellig)
			if (lkz.length() != 5 && lkz.length() != 6 && lkz.length() != 11){
				JOptionPane.showMessageDialog(this.controller.getParentController().getMainWindow(), "(Z)LKZ muss " +
						"entweder 5/6 oder 11-stellig sein!", "DIAS - (Z)LKZ nicht korrekt!", JOptionPane.WARNING_MESSAGE);
				
				return;
			}
			
			anzCriterias++;
		}		
		
		// Artikelgroesse
		String artgr = null;
		if (StringUtils.isNotEmpty(getArtgrTextField().getText()) ) {
			artgr = getArtgrTextField().getText();
			anzCriterias++;
		}
		// Farbe
		TreeNodeBean farbeNodeVO = getFarbeTextField().getValueObject();
		
		String farbeId = null;
		if (farbeNodeVO!= null) {
			
			FarbeDefBean farbe = (FarbeDefBean)farbeNodeVO.getValueObject();
			farbeId = farbe.getId();
			anzCriterias++;
			
		}
		// Merkmalklasse/Marktkz		
		TreeNodeBean nodeVO = getMerkmalKlasseTextField().getValueObject();
		String merkmalKlasse = null;
		String marktKz = null;
		
		if (nodeVO != null ) {
			// wurde eine Merkmalsklasse oder Marktkennzeichen ausgewählt
			if (nodeVO.getValueObject() instanceof MerkmalklasseDiamant) {
				merkmalKlasse = ((MerkmalklasseDiamant)nodeVO.getValueObject())
															 .getNr().toString();
				anzCriterias++;
			}
			else if (nodeVO.getValueObject() instanceof Marktkennzeichen) {
				marktKz = ((Marktkennzeichen)nodeVO.getValueObject())
												   .getMarktKennzeichen().toString();
				anzCriterias++;
			}			
		}
		// Es müssen mindestens 2 Suchkriterien ausgewählt sein
		if (anzCriterias >= 2 ) {
			controller.searchArtikel(lkz, artgr, farbeId, merkmalKlasse, marktKz, Constants.STATISTIK_ARTIKEL_SEARCH);
		}
		else {
			JOptionPane.showMessageDialog(controller.getParentController().getMainWindow(), 
					  "Es müssen mindestens 2 Suchkriterien ausgewählt sein!",
					  "Suchen",
					  JOptionPane.WARNING_MESSAGE);	
		}
	}


	private class OnLkzSearchButtonClicked implements java.awt.event.ActionListener {
		
		public void actionPerformed(java.awt.event.ActionEvent e) {
			
			LieferantenChooserController lieferantenController = new LieferantenChooserController(controller);
			lieferantenController.showDialog();		
			lieferantenController.getChooser().getBukrTextField().requestFocus();
		}
		
	}

	private class OnMerkmalsKlassenSearchButtonClicked implements java.awt.event.ActionListener {
		
		public void actionPerformed(java.awt.event.ActionEvent e) {
			new MerkmalsKlassenChooserController(controller).showDialog();
		}
		
	}
	
	private class OnFarbenButtonClicked implements java.awt.event.ActionListener {
		
		public void actionPerformed(java.awt.event.ActionEvent e) {
			
			 new FarbenChooserController(controller).showDialog();
			
		}
		
	}

	/**
	 * Starten des Artikelsuchvorgangs über suchButton
	 * @author Mather
	 *
	 */
	private class OnSearchButtonClicked implements java.awt.event.ActionListener {
		
		public void actionPerformed(java.awt.event.ActionEvent e) {
			
			searchArtikel();
			
		}
	}
	/*
	// Starten des Suchvorgang über F3
	private class KeyPressedF3 extends java.awt.event.KeyAdapter {
		public void keyPressed(java.awt.event.KeyEvent e) {
			System.out.println(e);
			if ( e.getKeyCode() == KeyEvent.VK_F3) {
				searchArtikel();
			}
			
		}
	};
	
	*/
	private class OnMouseMoveFarbenLabel extends java.awt.event.MouseAdapter {   
		public void mouseExited(java.awt.event.MouseEvent e) {    
			((JLabel)e.getSource()).setIcon(Images.CLEAR_CO);
		}
		public void mouseEntered(java.awt.event.MouseEvent e) {
			((JLabel)e.getSource()).setIcon(Images.CLEAR);
		}
		public void mouseClicked(java.awt.event.MouseEvent e) {
			getFarbeTextField().setText("");
			getFarbeTextField().setValueObject(null);
		} 
	};
	
	private class OnMouseMoveMerkmalLabel extends java.awt.event.MouseAdapter {   
		public void mouseExited(java.awt.event.MouseEvent e) {    
			((JLabel)e.getSource()).setIcon(Images.CLEAR_CO);
		}
		public void mouseEntered(java.awt.event.MouseEvent e) {
			((JLabel)e.getSource()).setIcon(Images.CLEAR);
		}
		public void mouseClicked(java.awt.event.MouseEvent e) {
			
			getMerkmalKlasseTextField().setText("");
			getMerkmalKlasseTextField().setValueObject(null);
		}
	};
	
}  //  @jve:decl-index=0:visual-constraint="10,10"

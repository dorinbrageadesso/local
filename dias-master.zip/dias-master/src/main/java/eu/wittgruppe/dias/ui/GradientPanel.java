package eu.wittgruppe.dias.ui;

import javax.swing.*;
import java.awt.*;

public class GradientPanel extends JPanel {

	public GradientPanel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	 public void paint( Graphics g ) {
		 
	        // super.paint( g );
	        Graphics2D g2d = ( Graphics2D )g;

	        Point pA = new Point( 0, 0 );
	        Color cA = Color.LIGHT_GRAY;
	        Point pB = new Point( this.getWidth(), 0 );
	        Color cB = this.getBackground();

	      
	        g2d.setPaint( new GradientPaint( pA, cB, pB, cA ) );
	        
	        g2d.fillRect( 0, 0, this.getWidth(), this.getHeight() );

	        this.printBorder( g );

	        this.printChildren( g );
	        this.printComponents( g );
	    }


}

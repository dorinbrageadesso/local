package eu.wittgruppe.dias.util.printer;


import witt.josef.printer.valentin.Etikett;

import java.util.Collection;

/**
 *  Interface für alle Valentin Etiketten
 * @author Mather
 *
 */
public interface ValentinEtikettRenderer {
	
    public Collection<String> addMask(Etikett etikett);
    
    /**
     * Die L&auml;ngen kann genau ermittelt werden, indem eine Messung am Valentin Drucker erfolgt!
     * @return die L&auml;nge in Millimeter
     */
    public long getEtikettLaengeInMillimeter();
    
    /**
     * Die L&auml;ngen kann genau ermittelt werden, indem eine Messung am Valentin Drucker erfolgt!
     * @return die L&auml;nge in Millimeter
     */
    public long getSchlitzabstandInMillimeter();
}

package eu.wittgruppe.dias.domain;

import jakarta.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class ParameterverwaltungPK implements Serializable {

	private String bezeichnung = null;
	private String gruppe = null;
	private String programmname = null;
	private String zielgruppe = null;

	public ParameterverwaltungPK() {
	};

	public ParameterverwaltungPK(String bezeichnung, String gruppe,
			String programmname, String zielgruppe) {
		super();
		this.bezeichnung = bezeichnung;
		this.gruppe = gruppe;
		this.programmname = programmname;
		this.zielgruppe = zielgruppe;
	}

	public String getBezeichnung() {
		return bezeichnung;
	}

	public void setBezeichnung(String bezeichnung) {
		this.bezeichnung = bezeichnung;
	}

	public String getGruppe() {
		return gruppe;
	}

	public void setGruppe(String gruppe) {
		this.gruppe = gruppe;
	}

	public String getProgrammname() {
		return programmname;
	}

	public void setProgrammname(String programmname) {
		this.programmname = programmname;
	}

	public String getZielgruppe() {
		return zielgruppe;
	}

	public void setZielgruppe(String zielgruppe) {
		this.zielgruppe = zielgruppe;
	}
}

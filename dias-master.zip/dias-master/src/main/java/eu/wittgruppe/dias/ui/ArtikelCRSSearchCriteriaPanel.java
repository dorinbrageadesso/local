package eu.wittgruppe.dias.ui;

import eu.wittgruppe.dias.controller.ArtikelSearchController;
import eu.wittgruppe.dias.util.Constants;
import org.apache.commons.lang.StringUtils;
import witt.josef.uiswing.ui.LimitedDocument;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;

public class ArtikelCRSSearchCriteriaPanel extends GradientPanel {
	
	private ArtikelSearchController controller = null;
	
	private JLabel artgrLabel = null;
	private JTextField artnrTextField = null;
	private JButton searchButton = null;
	private JLabel spaceholderLabel = null;

	private JCheckBox crsCheckBox = null;
	
	
	public ArtikelCRSSearchCriteriaPanel(ArtikelSearchController controller) {
	
		super();
		
		this.controller = controller;
		initialize();
	}

	

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		
		GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
		gridBagConstraints1.gridx = 1;
		gridBagConstraints1.insets = new java.awt.Insets(0,4,6,0);
		gridBagConstraints1.gridy = 1;
		GridBagConstraints gridBagConstraints17 = new GridBagConstraints();
		gridBagConstraints17.gridx = 3;
		gridBagConstraints17.weightx = 1.0D;
		gridBagConstraints17.gridy = 1;
		spaceholderLabel = new JLabel();
		spaceholderLabel.setText("JLabel");
		spaceholderLabel.setMinimumSize(new java.awt.Dimension(1,16));
		spaceholderLabel.setPreferredSize(new java.awt.Dimension(1,16));
		spaceholderLabel.setMaximumSize(new java.awt.Dimension(1111111,16));
		GridBagConstraints gridBagConstraints16 = new GridBagConstraints();
		gridBagConstraints16.gridx = 2;
		gridBagConstraints16.insets = new java.awt.Insets(0,2,15,0);
		gridBagConstraints16.gridy = 1;
		GridBagConstraints gridBagConstraints15 = new GridBagConstraints();
		gridBagConstraints15.gridx = 7;
		gridBagConstraints15.anchor = java.awt.GridBagConstraints.NORTHWEST;
		gridBagConstraints15.insets = new java.awt.Insets(0,5,10,0);
		gridBagConstraints15.gridy = 1;
		GridBagConstraints gridBagConstraints8 = new GridBagConstraints();
		gridBagConstraints8.fill = java.awt.GridBagConstraints.NONE;
		gridBagConstraints8.gridy = 1;
		gridBagConstraints8.weightx = 0.0D;
		gridBagConstraints8.anchor = java.awt.GridBagConstraints.WEST;
		gridBagConstraints8.insets = new java.awt.Insets(0,5,8,0);
		gridBagConstraints8.gridx = 0;
		GridBagConstraints gridBagConstraints7 = new GridBagConstraints();
		gridBagConstraints7.gridx = 0;
		gridBagConstraints7.insets = new java.awt.Insets(12,5,0,0);
		gridBagConstraints7.anchor = java.awt.GridBagConstraints.SOUTHWEST;
		gridBagConstraints7.gridy = 0;
		artgrLabel = new JLabel();
		artgrLabel.setText("Artikelnummer:");
		artgrLabel.setMinimumSize(new java.awt.Dimension(104,16));
		artgrLabel.setPreferredSize(new java.awt.Dimension(104,16));
		artgrLabel.setMaximumSize(new java.awt.Dimension(104,16));
		this.setLayout(new GridBagLayout());
		this.setSize(725, 69);
		this.setOpaque(false);
		this.setComponentOrientation(java.awt.ComponentOrientation.LEFT_TO_RIGHT);
		this.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.gray,1));
		this.setMaximumSize(new java.awt.Dimension(596,97));
		this.setMinimumSize(new java.awt.Dimension(596,97));
		this.add(artgrLabel, gridBagConstraints7);
		this.add(getArtnrTextField(), gridBagConstraints8);
		this.add(getSearchButton(), gridBagConstraints16);
		this.add(spaceholderLabel, gridBagConstraints17);
		this.add(getCrsCheckBox(), gridBagConstraints1);
	}

	/**
	 * This method initializes artgrTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	public JTextField getArtnrTextField() {
		if (artnrTextField == null) {
			artnrTextField = new JTextField();
			LimitedDocument doc = new LimitedDocument(6, LimitedDocument.NUMBER);
			artnrTextField.setDocument(doc);
			artnrTextField.setMaximumSize(new java.awt.Dimension(104,21));
			artnrTextField.setPreferredSize(new java.awt.Dimension(104,21));
			artnrTextField.setMinimumSize(new java.awt.Dimension(104,21));
		}
		return artnrTextField;
	}

	/**
	 * This method initializes searchButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getSearchButton() {
		if (searchButton == null) {
			searchButton = new JButton();
			searchButton.setText("Suchen (F3)");
			searchButton.setMinimumSize(new java.awt.Dimension(115,26));
			searchButton.setMaximumSize(new java.awt.Dimension(115,26));
			searchButton.setToolTipText("Artikel suchen");
			searchButton.setPreferredSize(new java.awt.Dimension(115,26));
			
			OnSearchButtonClicked listener = new OnSearchButtonClicked();
			searchButton.addActionListener(new OnSearchButtonClicked());
			searchButton.registerKeyboardAction( listener, 
					 "F3", KeyStroke.getKeyStroke( KeyEvent.VK_F3, 0 ), 
					 JComponent.WHEN_IN_FOCUSED_WINDOW );
			searchButton.registerKeyboardAction( listener, 
					 "ENTER", KeyStroke.getKeyStroke( KeyEvent.VK_ENTER, 0 ), 
					 JComponent.WHEN_IN_FOCUSED_WINDOW );	
		}
		return searchButton;
	}
	
	/**
	 * This method initializes crsCheckBox	
	 * 	
	 * @return javax.swing.JCheckBox	
	 */
	public JCheckBox getCrsCheckBox() {
		if (crsCheckBox == null) {
			crsCheckBox = new JCheckBox();
			crsCheckBox.setText("CRS");
			crsCheckBox.setMinimumSize(new java.awt.Dimension(49,21));
			crsCheckBox.setMaximumSize(new java.awt.Dimension(49,21));
			crsCheckBox.setOpaque(false);
			crsCheckBox.setPreferredSize(new java.awt.Dimension(49,21));
		}
		return crsCheckBox;
	};
	

	// L I S T E N E R S	
	
	private class OnSearchButtonClicked implements java.awt.event.ActionListener {
		
		public void actionPerformed(java.awt.event.ActionEvent e) {
						
			// Artikelnummer
			String artnr = null;
			if (StringUtils.isNotEmpty(getArtnrTextField().getText()) ) {
				artnr = getArtnrTextField().getText();
			}
			
			controller.searchArtikel(artnr, 
									 new Boolean(getCrsCheckBox().isSelected()), 
									 Constants.STATISTIK_ARTIKEL_CRS_SEARCH);
		}
	}
	
	
}  //  @jve:decl-index=0:visual-constraint="10,10"

package eu.wittgruppe.dias.service;

import eu.wittgruppe.dias.bean.*;
import eu.wittgruppe.dias.domain.*;
import eu.wittgruppe.dias.service.dao.DiasDAO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import witt.josef.benutzerverwaltung.Account;

import java.util.Calendar;
import java.util.Collection;

@Service
@Slf4j
public class DiasServiceImpl implements DiasService {

    @Autowired
    private DiasDAO diasDAO = null;

    public void setDiasDAO( DiasDAO diasDAO ) {
        this.diasDAO = diasDAO;
    }

    @Override
    public String getLKZFromZLKZAndBukr( String bukr, String zlkz ) {
        return diasDAO.getLKZFromZLKZAndBukr( bukr, zlkz );
    }

    @Override
    public Collection sucheLieferanten() {
        log.debug( "Lieferanten laden..." );
        return diasDAO.sucheLieferanten();
    }

    @Override
    public Collection<MerkmalklasseDiamant> sucheMerkmalsKlassen() {
        return diasDAO.sucheMerkmalsKlassen();
    }

    @Override
    public Collection<Marktkennzeichen> sucheMarktKennzeichen( MerkmalklasseDiamant klasse ) {
        return diasDAO.sucheMarktKennzeichen( klasse );
    }

    @Override
    public Collection<Marktkennzeichen> sucheAllMarktKennzeichen() {
        return diasDAO.sucheAllMarktKennzeichen();
    }

    @Override
    public Collection<FarbeDefBean> sucheFarben( String farbe ) {
        return diasDAO.sucheFarben( farbe );
    }

    @Override
    public Collection<VDiasArtikel> sucheArtikel( String artnr, Boolean isCrs ) {
        return diasDAO.sucheArtikel( artnr, isCrs );
    }

    @Override
    public Collection<VDiasArtikel> findByCriteria( String lkz, String artgr, String farbeId, String merkmalKlasse, String martkKz, Long aktSaison, int saison_zeitraum ) {
        return diasDAO.findByCriteria( lkz, artgr, farbeId, merkmalKlasse, martkKz, aktSaison, saison_zeitraum );
    }

    @Override
    public Collection<VDiasArtikel> findByCriteria( String artnr, Boolean isCrs, Long aktSaison, int saison_zeitraum ) {
        return diasDAO.findByCriteria( artnr, isCrs, aktSaison, saison_zeitraum );
    }

    @Override
    public Collection<VDiasArtikel> sucheArtikel( String lkz, String artgr, String farbeId, String merkmalKlasse, String marktKz ) {
        return diasDAO.sucheArtikel( lkz, artgr, farbeId, merkmalKlasse, marktKz );
    }

    @Override
    public ErsatzartikelBean getErsatzartikel( String artnr6, String artgr, String saison ) {
        return diasDAO.getErsatzartikel( artnr6, artgr, saison );
    }

    @Override
    public long getAktuelleSaison() {
        return diasDAO.getAktuelleSaison();
    }

    @Override
    public byte[] getBild( Long mvnr ) {
        return diasDAO.getBild( mvnr );
    }

    @Override
    public KatalogseiteBean getKatalogSeiteCas( Long saison, Long mvnr, String isoSpracheCode ) {
        return diasDAO.getKatalogSeiteCas( saison, mvnr, isoSpracheCode );
    }

    @Override
    public Collection sucheRechnungsPositionen( Kundenfirma kundenFirma, Long kdnr ){
        return diasDAO.sucheRechnungsPositionen( kundenFirma, kdnr );
    }

    @Override
    public KundenrechnungskopfBean sucheRechnungsKopf( Long retschl, boolean onlyCH )  {
        return diasDAO.sucheRechnungsKopf( retschl,onlyCH );
    }

    @Override
    public Collection sucheRechnungsPositionen( KundenrechnungskopfBean kopf )  {
        return diasDAO.sucheRechnungsPositionen( kopf );
    }

    @Override
    public Collection getRechnungsPositionen( KundenrechnungskopfBean kopf, Kundenfirma kundenFirma, Long P_kdnr, boolean vonKopf ) {
        return diasDAO.getRechnungsPositionen( kopf, kundenFirma, P_kdnr, vonKopf );
    }

    @Override
    public Collection sucheKunden( Long kdnr, boolean onlyCH ) {
        return diasDAO.sucheKunden( kdnr, onlyCH );
    }

    @Override
    public Kunde sucheKunden( Kundenfirma firma, Long kdnr ) {
        return diasDAO.sucheKunden( firma, kdnr );
    }

    @Override
    public GroessenArtikelstamm sucheGroesseArtsta( Long artikelnummerWitt, String modellvariantengroesse ) {
        return diasDAO.sucheGroesseArtsta( artikelnummerWitt, modellvariantengroesse );
    }

    @Override
    public Collection sucheParameter( String dvNummer ) {
        return diasDAO.sucheParameter( dvNummer );
    }

    @Override
    public Boolean druckerAngeschlossen( String dvNummer ) {
        return diasDAO.druckerAngeschlossen( dvNummer );
    }

    @Override
    public Collection sucheKundenMitAnschrift( Collection personenIdCol ) {
        return diasDAO.sucheKundenMitAnschrift( personenIdCol );
    }

    @Override
    public void insertDiasStatistik( Long kdnr, Long artikelNr, String artgr, long erfassungsKz, String cn ) {
        diasDAO.insertDiasStatistik( kdnr, artikelNr, artgr, erfassungsKz, cn );
    }

    @Override
    public Collection<StatistikBean> sucheDiasStatistikDaten( Calendar startCal, Calendar endCal ) {
        return diasDAO.sucheDiasStatistikDaten( startCal, endCal );
    }

    @Override
    public Collection<StatistikBean> sucheDiasStatistikDaten( Calendar startCal, Calendar endCal, Account account ) {
        return diasDAO.sucheDiasStatistikDaten( startCal, endCal, account );
    }

    @Override
    public OriginalArtikelstamm sucheOriginalArtikel( Long saison, Long artikelNr ) {
        return diasDAO.sucheOriginalArtikel( saison, artikelNr );
    }

    @Override
    public String sucheLagerkoordinate( Long artikelNr, String artgr ) {
        return diasDAO.sucheLagerkoordinate( artikelNr, artgr );
    }

    @Override
    public String formatLagerKoord( String koord ) {
        return diasDAO.formatLagerKoord( koord );
    }

    @Override
    public Bestandsfirma sucheBestandsFirma( int firmKz ) {
        return diasDAO.sucheBestandsFirma( firmKz );
    }


}

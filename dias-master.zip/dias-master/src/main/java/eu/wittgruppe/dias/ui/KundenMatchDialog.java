package eu.wittgruppe.dias.ui;

import eu.wittgruppe.dias.bean.KundeSearchBean;
import eu.wittgruppe.dias.controller.KundenMatchDialogController;
import org.apache.commons.lang.math.NumberUtils;

import javax.swing.*;
import java.awt.*;

public class KundenMatchDialog extends JDialog {
	
	private KundenMatchDialogController controller = null;
	
	private JPanel jContentPane = null;
	private KundenMatchPanel matchPanel = null;
	private JButton okButton = null;
	private JButton cancelButton = null;
	private JPanel southPanel = null;


	 
	public KundenMatchDialog(KundenMatchDialogController controller) {
		super(controller.getParentController().getParentController().getMainWindow());
		this.controller = controller;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(1024, 556);
		this.setTitle("Kunde matchen");
		this.setContentPane(getJContentPane());
		controller.getMatchPanel().getKundeTable().addMouseListener(new OnKundeTableDoubleClicked());
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getCenterPanel(), java.awt.BorderLayout.CENTER);
			jContentPane.add(getSouthPanel(), java.awt.BorderLayout.SOUTH);
			
		}
		return jContentPane;
	}

	

	/**
	 * This method initializes southPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getSouthPanel() {
		if (southPanel == null) {
			southPanel = new JPanel();
			southPanel.add(getOkButton(), null);
			southPanel.add(getCancelButton(), null);
		}
		return southPanel;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getOkButton() {
		if (okButton == null) {
			okButton = new JButton();
			okButton.setMaximumSize(new Dimension(108, 26));
			okButton.setPreferredSize(new Dimension(108, 26));
			okButton.setText("OK");
			okButton.setMinimumSize(new Dimension(108, 26));
			okButton.addActionListener(new OnOkButtonClicked());
		}
		return okButton;
	}
	
	/**
	 * This method initializes centerPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private KundenMatchPanel getCenterPanel() {
		if (matchPanel == null) {
			matchPanel = controller.getMatchPanel();
		}
		return matchPanel;
	};

	/**
	 * This method initializes jButton1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getCancelButton() {
		if (cancelButton == null) {
			cancelButton = new JButton();
			cancelButton.setMaximumSize(new Dimension(108, 26));
			cancelButton.setPreferredSize(new Dimension(108, 26));
			cancelButton.setText("Abbrechen");
			cancelButton.setMinimumSize(new Dimension(108, 26));
			cancelButton.addActionListener(new OnCancelButtonClicked());
		}
		return cancelButton;
	};
	
//	 L I S T E N E R S	
	
	private class OnOkButtonClicked implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			
			KundeSearchBean selectedBean = controller.getSelectedSearchBean();
			if (selectedBean != null) {
				if (controller.getParentController().getKundenRechnungenPanel() != null) {
					controller.getParentController().getKundenRechnungenPanel()							
			  		  		  .getKdnrTextField().setText(selectedBean.getKdnr());
					controller.closeDialog();
				}
			}
			
		}
	};
	
	private class OnCancelButtonClicked implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			controller.closeDialog();
		}
	}
	

	private class OnKundeTableDoubleClicked extends java.awt.event.MouseAdapter {
		public void mouseClicked(java.awt.event.MouseEvent e) {
			
			if (e.getClickCount() == 2) {
				KundeSearchBean selectedBean = (KundeSearchBean)controller.getMatchPanel().getKundeTable()
												.getValueAt(controller.getMatchPanel().getKundeTable()
			                                    .getSelectedRow(), 0);
				
				if (controller.getParentController().getKundenRechnungenPanel() != null) {
					controller.getParentController().getKundenRechnungenPanel().
			  		  		  getKdnrTextField().setText(selectedBean.getKdnr());
				//	controller.getParentController().clearPanel();
					controller.getParentController().sucheRechnungsPositionen( selectedBean.getKdfirmId(),
											NumberUtils.createLong(selectedBean.getKdnr()));
				}				
			}
		}
	}


}  //  @jve:decl-index=0:visual-constraint="10,10"

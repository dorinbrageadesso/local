package eu.wittgruppe.dias.domain;

import org.apache.commons.lang.builder.ToStringBuilder;

import jakarta.persistence.*;
import java.io.Serializable;
import java.sql.Date;

import static jakarta.persistence.FetchType.LAZY;

@Entity(name = "Person")
@Table(name = "person")
public class Person implements Serializable {

	private static final long serialVersionUID = 1L;

	@ManyToOne(fetch = LAZY)
	@JoinColumn(name = "ADRESSEID")
	private Adresse adresse;

	@Column(name = "ADRHDLGESDAT")
	private Date datumAdressHandleKennzeichenGesetzt = null;

	@Column(name = "ADRHDLID")
	private String adressHandleId = null;

	@Column(name = "ADRZUS")
	private String adressZusatz = null;

	@Column(name = "GEBDAT")
	private Date geburtsdatum = null;

	@Column(name = "GEBDATSTATUS")
	private Long geburtsdatumStatus = null;

	@Id
	private String id = null;

	@Column(name = "NNAME")
	private String nachname = null;

	@ManyToOne(fetch = LAZY)
	@JoinColumn(name = "PERSANREDEID")
	private PersonAnrede personAnrede;

	@Column(name = "PRINTNAME")
	private String printName = null;

	@Column(name = "TI")
	private String titel = null;

	@Column(name = "VNAME")
	private String vorname = null;

	public Person() {
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public Adresse getAdresse() {
		return adresse;
	}

	public void setAdresse(Adresse adresse) {
		this.adresse = adresse;
	}

	public Date getDatumAdressHandleKennzeichenGesetzt() {
		return datumAdressHandleKennzeichenGesetzt;
	}

	public void setDatumAdressHandleKennzeichenGesetzt(
			Date datumAdressHandleKennzeichenGesetzt) {
		this.datumAdressHandleKennzeichenGesetzt = datumAdressHandleKennzeichenGesetzt;
	}

	public String getAdressHandleId() {
		return adressHandleId;
	}

	public void setAdressHandleId(String adressHandleId) {
		this.adressHandleId = adressHandleId;
	}

	public String getAdressZusatz() {
		return adressZusatz;
	}

	public void setAdressZusatz(String adressZusatz) {
		this.adressZusatz = adressZusatz;
	}

	public Date getGeburtsdatum() {
		return geburtsdatum;
	}

	public void setGeburtsdatum(Date geburtsdatum) {
		this.geburtsdatum = geburtsdatum;
	}

	public Long getGeburtsdatumStatus() {
		return geburtsdatumStatus;
	}

	public void setGeburtsdatumStatus(Long geburtsdatumStatus) {
		this.geburtsdatumStatus = geburtsdatumStatus;
	}

	public String getId() {
		return id;
	}

	public String getNachname() {
		return nachname;
	}

	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	public PersonAnrede getPersonAnrede() {
		return personAnrede;
	}

	public void setPersonAnrede(PersonAnrede personAnrede) {
		this.personAnrede = personAnrede;
	}

	public String getPrintName() {
		return printName;
	}

	public void setPrintName(String printName) {
		this.printName = printName;
	}

	public String getTitel() {
		return titel;
	}

	public void setTitel(String titel) {
		this.titel = titel;
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

}

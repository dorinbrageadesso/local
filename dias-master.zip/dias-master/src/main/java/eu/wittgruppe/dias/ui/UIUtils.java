/*
 * J O S E F Java Object Solutions Enterprise Framework Copyright 2002 - 2004 Josef Witt GmbH
 */

package eu.wittgruppe.dias.ui;

import eu.wittgruppe.dias.util.GenericTableModel;
import eu.wittgruppe.dias.util.SortUtilities;
import eu.wittgruppe.dias.util.TableSorter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.exception.ExceptionUtils;

import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.table.*;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

/**
 * Utility Methoden f&uuml;r UI Componenten
 * 
 * @author ulrkle
 * @author thohoe
 */
@Slf4j
public final class UIUtils {
	public static JDialog getErrorDialog(Component parent, String errorMessage, String title, Throwable t) {
		JOptionPane optionPane = new JOptionPane();
		JTextArea textArea = null;

		if (t == null) {
			textArea = new JTextArea("");
			optionPane.setMessage(new Object[] { errorMessage });
		} else {
			textArea = new JTextArea(ExceptionUtils.getStackTrace(t));
			optionPane.setMessage(new Object[] { errorMessage, new JScrollPane(textArea) });
		}

		optionPane.setMessageType(JOptionPane.ERROR_MESSAGE);

		return optionPane.createDialog(parent, title);
	}

	public static boolean setFrameState(Frame frame, int state) {
		if (Toolkit.getDefaultToolkit().isFrameStateSupported(state)) {
			log.debug("state is supported");
			frame.setExtendedState(state);

			return true;
		} else {
			return false;
		}
	}

	public static Dimension getScreenSize() {
		Toolkit t = Toolkit.getDefaultToolkit();

		return t.getScreenSize();
	}

	public static void clearFillSortTable(JTable table, GenericTableModel model, Collection data, Class comparator,
                                         boolean ascending) {
		data = (Collection) SortUtilities.sort(data, SortUtilities.CollectionDataHandler.class, comparator, true);

		clearFillSortTable(table, model, data);
	}
	
	public static void clearFillSortTable(JTable table, GenericTableModel model, Collection data) {
		// Tablemodel leeren.
		while (model.getRowCount() > 0) {
			model.deleteRow(0);
		}

		// Alle Daten in die Tabelle schreiben (gleicher Wert
		// in jeder Spalte), aber nur wenn Daten da sind.
		if (data != null) {
			Iterator iter = data.iterator();

			while (iter.hasNext()) {
				model.addRow(UIUtils.createRow(model, iter.next()));
			}
		}

		// Daten sortieren und anzeigen
		TableSorter tableSorter = new TableSorter(model, table.getTableHeader());
		tableSorter.setTable(table);
		table.setModel(tableSorter);
	}

	
	public static void centerOnScreen(Component c) {
		Dimension d = getScreenSize();
		int widthComponent = c.getWidth();
		int heightComponent = c.getHeight();

		int screenWidth = (int) (d.getWidth() - widthComponent) / 2;
		int screenHeight = (int) (d.getHeight() - heightComponent) / 2;

		c.setLocation(screenWidth, screenHeight);
	}

	public static void centerOverComponent(Component parent, Component child) {
		int x = (int) parent.getLocationOnScreen().getX() + ((parent.getWidth() - child.getWidth()) / 2);
		int y = (int) parent.getLocationOnScreen().getY() + ((parent.getHeight() - child.getHeight()) / 2);

		child.setLocation(x, y);
	}

	public static void collapseAll(JTree tree) {
		TreeNode root = (TreeNode) tree.getModel().getRoot();

		// Traverse tree from root
		expandOrCollapseAll(tree, new TreePath(root), false);
	}

	public static void expandAll(JTree tree) {
		TreeNode root = (TreeNode) tree.getModel().getRoot();

		// Traverse tree from root
		expandOrCollapseAll(tree, new TreePath(root), true);
	}

	public static void expandOrCollapseAll(JTree tree, TreePath parent, boolean expand) {
		// Traverse children
		TreeNode node = (TreeNode) parent.getLastPathComponent();

		if (node.getChildCount() >= 0) {
			for (Enumeration e = node.children(); e.hasMoreElements();) {
				TreeNode n = (TreeNode) e.nextElement();
				TreePath path = parent.pathByAddingChild(n);
				expandOrCollapseAll(tree, path, expand);
			}
		}

		// Expansion or collapse must be done bottom-up
		if (expand) {
			tree.expandPath(parent);
		} else {
			tree.collapsePath(parent);
		}
	}

	public static boolean maximizeFrame(Frame frame) {
		return setFrameState(frame, Frame.MAXIMIZED_BOTH);
	}

	public static void scrollComponentToCenter(JViewport viewport, Component component) {
		Rectangle rect = component.getBounds();
		Rectangle viewRect = viewport.getViewRect();

		rect.setLocation(rect.x - viewRect.x, rect.y - viewRect.y);

		int centerX = (viewRect.width - rect.width) / 2;
		int centerY = (viewRect.height - rect.height) / 2;

		if (rect.x < centerX) {
			centerX = -centerX;
		}
		if (rect.y < centerY) {
			centerY = -centerY;
		}

		rect.translate(centerX, centerY);

		viewport.scrollRectToVisible(rect);
	}

	public static void setFixColumnWidth(TableColumn col, int width) {
		col.setMinWidth(width);
		col.setMaxWidth(width);
		col.setPreferredWidth(width);
	}


	public static Object getSelectedRowObject(JTable table) {
		int row = table.getSelectedRow();

		if ((row < 0) || (row > table.getRowCount()) || (table.getColumnCount() <= 0)) {
			return null;
		}

		try {
			return table.getValueAt(row, 0);
		} catch (Exception e) {
			return null;
		}
	}

	public static void clearComboBox(JComboBox comboBox) {
		// Alle Elemente löschen
		comboBox.removeAllItems();
		int count = comboBox.getItemCount();

		for (int i = 0; i < count; i++) {
			comboBox.removeItemAt(0);
		}
	}

	public static void clearFillComboBox(JComboBox comboBox, Collection objects) {
		// ComboBox leeren
		UIUtils.clearComboBox(comboBox);

		// ComboBox mit neuen Werten befüllen.
		DefaultComboBoxModel model = new DefaultComboBoxModel(objects.toArray());
		comboBox.setModel(model);
	}

	public static void clearFillList(JList list, Collection objects) {
		// ComboBox mit neuen Werten befüllen.
		list.setListData(objects.toArray());
	}

	public static void clearList(JList list) {
		list.setListData(new Object[] {});
	}

	
	public static void repaintTable(JTable table) {
		// Tabelle aktualisieren
		TableModel model = table.getModel();

		if (model != null) {
			int count = model.getRowCount();

			if (count > 0) {
				TableModelEvent tme = new TableModelEvent(model, 0, count);
				table.tableChanged(tme);
			}
		}
	}

	public static void scrollRowToVisible(JTable table, int row) {
		int maxRow = table.getRowCount() - 1;

		// Grenzen abfangen
		row = ((row < 0) ? 0 : row);
		row = ((row > maxRow) ? maxRow : row);

		// zur row scrollen
		table.scrollRectToVisible(table.getCellRect(row, 0, true));
	}

	public static void setupTableHeader(JTable table) {
		JTableHeader th = table.getTableHeader();
		th.setFont(new Font("Arial", 0, 12));
		table.setTableHeader(th);
		table.getTableHeader().setReorderingAllowed(false);
	}

	private static int changeTableSelection(JTable table, boolean next) {
		int currentRow = table.getSelectedRow();
		int maxRow = table.getRowCount() - 1;

		// Wenn Zeilen zum selektieren vorhanden...
		if (maxRow >= 0) {
			int nextRow = currentRow + (next ? 1 : (-1));
			nextRow = ((nextRow < 0) ? maxRow : nextRow); // unteres Ende
			// erreicht?
			nextRow = ((nextRow > maxRow) ? 0 : nextRow); // oberes Ende
			// erreicht?

			// gefundene Zeile markieren
			table.setRowSelectionInterval(nextRow, nextRow);
			UIUtils.scrollRowToVisible(table, nextRow);

			return nextRow;
		} else {
			return -1;
		}
	}

	private static Object[] createRow(TableModel model, Object o) {
		int columnCount = model.getColumnCount();
		Object[] rowData = new Object[columnCount];

		for (int i = 0; i < columnCount; i++) {
			rowData[i] = o;
		}

		return rowData;
	}

	public static Collection getColumnValues(JTable table, int columnIndex) {
		Collection c = new Vector();
		for (int i = 0; i < table.getRowCount(); i++) {
			c.add(table.getValueAt(i, columnIndex));
		}

		return c;
	}

	public static Collection getListValues(JList list) {
		ListModel model = list.getModel();
		Collection c = new Vector();
		for (int i = 0; i < model.getSize(); i++) {
			c.add(model.getElementAt(i));
		}

		return c;
	}

	public static void packColumns(JTable table, int margin) {
		for (int c = 0; c < table.getColumnCount(); c++) {
			packColumn(table, c, margin);
		}
	}

	public static int packColumn(JTable table, int colIndex, int margin) {
		// TableModel model = table.getModel();
		DefaultTableColumnModel colModel = (DefaultTableColumnModel) table.getColumnModel();
		TableColumn col = colModel.getColumn(colIndex);
		int width = 0;

		TableCellRenderer renderer = col.getHeaderRenderer();
		if (renderer == null) {
			renderer = table.getTableHeader().getDefaultRenderer();
		}

		Component comp = renderer.getTableCellRendererComponent(table, col.getHeaderValue(), false, false, 0, 0);
		width = comp.getPreferredSize().width;

		for (int r = 0; r < table.getRowCount(); r++) {
			renderer = table.getCellRenderer(r, colIndex);
			comp = renderer.getTableCellRendererComponent(table, table.getValueAt(r, colIndex), false, false, r,
					colIndex);
			width = Math.max(width, comp.getPreferredSize().width);
		}

		width += 2 * margin;
		col.setPreferredWidth(width);
        return width;
	}

	public static class UpDownListener implements ActionListener {
		// ~ Static fields/initializers
		// -------------------------------------------------------------

		private static boolean lastAction = true;

		// ~ Instance fields
		// ------------------------------------------------------------------------

		private JTable table = null;
		private boolean next = true;

		// ~ Constructors
		// ---------------------------------------------------------------------------

		public UpDownListener(JTable table, boolean next) {
			this.table = table;
			this.next = next;
		}

		// ~ Methods
		// --------------------------------------------------------------------------------

		public static boolean isNextLastAction() {
			return UpDownListener.lastAction;
		}

		public void actionPerformed(ActionEvent e) {
			UpDownListener.lastAction = this.next;
			UIUtils.changeTableSelection(this.table, this.next);
		}
	}

}

package eu.wittgruppe.dias.ui;

import eu.wittgruppe.dias.controller.LieferantenChooserController;
import eu.wittgruppe.dias.ui.renderer.LieferantenTableRenderer;
import eu.wittgruppe.dias.util.GenericTableModel;
import lombok.extern.slf4j.Slf4j;
import witt.josef.uiswing.ui.LimitedDocument;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Collection;


@Slf4j
public class LieferantenChooser extends JDialog {
	
	public JTextField getZlkzTextField() {
		return zlkzTextField;
	}

	public JTextField getBukrTextField() {
		return bukrTextField;
	}


	private static final long serialVersionUID = -2897036223861461928L;

	private LieferantenChooserController controller = null;
	
	private String tableColumns[] = { "BuKr", "ZLKZ", "LKZ", "Lieferantenname" };
	
	private GenericTableModel tableModel = null;
	 
	private JPanel jContentPane = null;
	
	private JPanel northPanel = null;
	
	private JLabel lkzLabel = null;
	
	private JTextField lkzTextField = null;
	
	private JLabel liefNameLabel = null;
	
	private JTextField liefNameTextField = null;
	
	private JButton okButton = null;
	
	private JPanel cetnerPanel = null;
	
	private JScrollPane lieferantenScrollPane = null;
	
	private JTable lieferantenTable = null;
	
	private JButton cancelButton = null;
	
	private JTextField zlkzTextField = null;
	
	private JTextField bukrTextField = null;

	public LieferantenChooser(JFrame parent, LieferantenChooserController controller) {
		super(parent);
		this.controller = controller;
		initialize();
	}
		
	public void setLieferanten(Collection lieferanten) {
		
		UIUtils.clearFillSortTable(getLieferantenTable(), tableModel, lieferanten);
	}
	

	private void initialize() {
		
		this.setSize(621, 403);
		this.setContentPane(getJContentPane());
		
		this.setTitle("Lieferantenauswahl");
		this.tableModel = new GenericTableModel( tableColumns, 0 );
		getLieferantenTable().setModel(tableModel);
		getLieferantenTable().setRowHeight( 20 );
		getLieferantenTable().setDefaultRenderer( Object.class, new LieferantenTableRenderer() );
		getLieferantenTable().getColumnModel().getColumn(3).setPreferredWidth(150);
		
		LimitedDocument lkz = new LimitedDocument(6, LimitedDocument.NUMBER);
		this.getLkzTextField().setDocument(lkz);
		
		LimitedDocument zlkz = new LimitedDocument(8, LimitedDocument.NUMBER);
		this.getZlkzTextField().setDocument(zlkz);
					
		LimitedDocument bukr = new LimitedDocument(3, LimitedDocument.NUMBER);
		this.getBukrTextField().setDocument(bukr);
				
		UIUtils.centerOnScreen(this);
	}

	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.setComponentOrientation(java.awt.ComponentOrientation.RIGHT_TO_LEFT);
			jContentPane.add(getJPanel(), java.awt.BorderLayout.NORTH);
			jContentPane.add(getCetnerPanel(), java.awt.BorderLayout.CENTER);
		}
		return jContentPane;
	}

	private JPanel getJPanel() {
		if (northPanel == null) {
			liefNameLabel = new JLabel();
			liefNameLabel.setText("Lieferantenname:");
			lkzLabel = new JLabel();
			lkzLabel.setText("LKZ:");
			northPanel = new JPanel();
			northPanel.setComponentOrientation(java.awt.ComponentOrientation.LEFT_TO_RIGHT);
			northPanel.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.gray,1));

			JLabel bukrLabel;
			bukrLabel = new JLabel();
			bukrLabel.setText("BuKr:");

			bukrTextField = new JTextField();
			bukrTextField.addKeyListener(new KeyAdapter() {
				public void keyReleased(final KeyEvent e) {
					
					controller.filterLieferantenByBuchungskreis(LieferantenChooser.this.controller.getParentController()
							.getParentController().getLieferanten()
					 ,LieferantenChooser.this.getBukrTextField().getText());
				}
			});

			zlkzTextField = new JTextField();
			zlkzTextField.addKeyListener(new KeyAdapter() {
				public void keyReleased(final KeyEvent e) {
					
					controller.filterLieferantenByZentralLiefnr(LieferantenChooser.this.controller.getParentController()
							.getParentController().getLieferanten()
					 ,LieferantenChooser.this.getZlkzTextField().getText());
				}
			});

			JLabel zlkzLabel;
			zlkzLabel = new JLabel();
			zlkzLabel.setText("ZLKZ:");
			final GroupLayout groupLayout = new GroupLayout((JComponent) northPanel);
			groupLayout.setHorizontalGroup(
				groupLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
					.addGroup(groupLayout.createSequentialGroup()
						.addContainerGap()
						.addGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
							.addComponent(bukrTextField, GroupLayout.PREFERRED_SIZE, 42, GroupLayout.PREFERRED_SIZE)
							.addComponent(bukrLabel))
						.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
							.addComponent(zlkzTextField, GroupLayout.PREFERRED_SIZE, 63, GroupLayout.PREFERRED_SIZE)
							.addComponent(zlkzLabel))
						.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
							.addComponent(lkzLabel)
							.addComponent(getLkzTextField(), GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
							.addComponent(getLiefNameTextField(), GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addComponent(liefNameLabel))
						.addGap(48, 48, 48)
						.addGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.TRAILING)
							.addComponent(getOkButton(), GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addComponent(getJButton(), GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addContainerGap())
			);
			groupLayout.setVerticalGroup(
				groupLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
					.addGroup(groupLayout.createSequentialGroup()
						.addGap(10, 10, 10)
						.addGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.TRAILING)
							.addGroup(groupLayout.createSequentialGroup()
								.addGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
									.addComponent(bukrLabel)
									.addComponent(lkzLabel)
									.addComponent(zlkzLabel)
									.addComponent(liefNameLabel))
								.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
								.addGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
									.addComponent(bukrTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
									.addComponent(zlkzTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
									.addComponent(getLkzTextField(), GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
									.addComponent(getLiefNameTextField(), GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
							.addGroup(groupLayout.createSequentialGroup()
								.addComponent(getOkButton(), GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(getJButton(), GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
						.addContainerGap())
			);
			northPanel.setLayout(groupLayout);
		}
		return northPanel;
	}

	public JTextField getLkzTextField() {
		if (lkzTextField == null) {
			lkzTextField = new JTextField();
			lkzTextField.setMinimumSize(new java.awt.Dimension(50,21));
			lkzTextField.setMaximumSize(new java.awt.Dimension(50,21));
			lkzTextField.setPreferredSize(new java.awt.Dimension(50,21));
			lkzTextField.addKeyListener(new LkzTextFieldKeyReleased());
		}
		return lkzTextField;
	}

	private JTextField getLiefNameTextField() {
		if (liefNameTextField == null) {
			liefNameTextField = new JTextField();
			liefNameTextField.setPreferredSize(new java.awt.Dimension(240,21));
			liefNameTextField.setMaximumSize(new java.awt.Dimension(240,21));
			liefNameTextField.setMinimumSize(new java.awt.Dimension(240,21));
			liefNameTextField.addKeyListener(new LiefNameTextFieldKeyReleased());
			
			
		}
		return liefNameTextField;
	}

	private JButton getOkButton() {
		if (okButton == null) {
			okButton = new JButton();
			okButton.setText("OK");
			okButton.setMinimumSize(new java.awt.Dimension(108,26));
			okButton.setPreferredSize(new java.awt.Dimension(108,26));
			okButton.setMaximumSize(new java.awt.Dimension(108,26));
			okButton.addActionListener(new OnOKButton());
		}
		return okButton;
	}

	private JPanel getCetnerPanel() {
		if (cetnerPanel == null) {
			GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
			gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
			gridBagConstraints1.gridy = 0;
			gridBagConstraints1.ipadx = 160;
			gridBagConstraints1.weightx = 1.0;
			gridBagConstraints1.weighty = 1.0;
			gridBagConstraints1.insets = new java.awt.Insets(10,10,10,10);
			gridBagConstraints1.gridx = 0;
			cetnerPanel = new JPanel();
			cetnerPanel.setLayout(new GridBagLayout());
			cetnerPanel.add(getLieferantenScrollPane(), gridBagConstraints1);
		}
		return cetnerPanel;
	}

	private JScrollPane getLieferantenScrollPane() {
		if (lieferantenScrollPane == null) {
			lieferantenScrollPane = new JScrollPane();
			lieferantenScrollPane.setViewportView(getLieferantenTable());
		}
		return lieferantenScrollPane;
	}

	public JTable getLieferantenTable() {
		if (lieferantenTable == null) {
			lieferantenTable = new JTable();
			lieferantenTable.setSelectionBackground(new java.awt.Color(255,255,145));
			lieferantenTable.addMouseListener(new DoubleClickOnLieferantenTable());
		}
		return lieferantenTable;
	}

	private JButton getJButton() {
		if (cancelButton == null) {
			cancelButton = new JButton();
			cancelButton.setMaximumSize(new java.awt.Dimension(108,26));
			cancelButton.setPreferredSize(new java.awt.Dimension(108,26));
			cancelButton.setText("Abbrechen");
			cancelButton.setMinimumSize(new java.awt.Dimension(108,26));
			cancelButton.addActionListener(new OnCanelButton());
		}
		return cancelButton;
	}
	

	private class LkzTextFieldKeyReleased extends java.awt.event.KeyAdapter {
		public void keyReleased(java.awt.event.KeyEvent e) {		
	
			controller.filterLieferantenByLiefnr(LieferantenChooser.this.controller.getParentController()
														.getParentController().getLieferanten()
												 ,LieferantenChooser.this.getLkzTextField().getText());
			
		}
	}
	
	private class LiefNameTextFieldKeyReleased extends java.awt.event.KeyAdapter {
		public void keyReleased(java.awt.event.KeyEvent e) {
						
			controller.filterLieferantenByLiefName(LieferantenChooser.this.controller.getParentController()
															.getParentController().getLieferanten()
					                               ,LieferantenChooser.this.getLiefNameTextField().getText());
			
		}
	}
	
	private class DoubleClickOnLieferantenTable extends java.awt.event.MouseAdapter {
		public void mouseClicked(java.awt.event.MouseEvent e) {
			
			if (e.getClickCount()==2) {
				setChooesdLkzInTextField();
			}
			
			
		}
	}
	
	private class OnOKButton implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			setChooesdLkzInTextField();
		}
	}
	
	private class OnCanelButton implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			LieferantenChooser.this.dispose();
		}
	}
	
	
	private void setChooesdLkzInTextField() {
		
		Long liefnr = controller.getSelectedLiefnr();
		
		if (liefnr != null) {
			((ArtikelSearchCriteriaPanel)LieferantenChooser.this.controller.getParentController()
					.getArtikelSearchPanel().getSearchPanel()).getLkzTextField().setText(liefnr.toString());
			
		} 
		
		
		
	}	

}  

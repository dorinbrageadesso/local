package eu.wittgruppe.dias.util;

import javax.swing.*;
import javax.swing.tree.TreePath;

/**
 * Util Methoden für den treeView 
 * @author Mather
 * @version 1.0
 */
public class TreeUtils {

	
	/**
	 * @param tree
	 * Klappt alle Nodes des Trees auf
	 */
	public static void expandAll(JTree tree) {
		
		for (int i = 0; i < tree.getRowCount(); i++) {
			if (!tree.isExpanded(i)) {
				tree.expandRow(i);
			} 
		}		
	}
	
	/**
	 * @param tree
	 * Klappt den Baum zusammen, nur noch Root sichtbar
	 */
	public static void collapseAll(JTree tree) {
		
		for (int i = tree.getRowCount(); i >= 0 ; i--) {			
			if (!tree.isCollapsed(i)) {
				tree.collapseRow(i);
			} 
		}		
	}
	
	/**
	 * @param tree
	 * Klappt den Baum zusammen, bis auf die Root, d.h. erster Level sichtbar
	 */
	public static void collapseWithoutRoot(JTree tree) {
		
		for (int i = 0; i < tree.getRowCount(); i++) {
			TreePath path = tree.getPathForRow(i);
			
			if (path.getLastPathComponent() != tree.getModel().getRoot()) {
				//if (!tree.isCollapsed(i)) {
					tree.collapseRow(i);
				//} 
			}			
			
		}		
	}
	

}

package eu.wittgruppe.dias.controller;

import eu.wittgruppe.core.medien.client.CenteraOperations;
import eu.wittgruppe.core.medien.transfer.CenteraClipReadBean;
import eu.wittgruppe.dias.bean.ErsatzartikelBean;
import eu.wittgruppe.dias.bean.KatalogseiteBean;
import eu.wittgruppe.dias.domain.Bestandsfirma;
import eu.wittgruppe.dias.domain.GroessenArtikelstamm;
import eu.wittgruppe.dias.domain.Parameterverwaltung;
import eu.wittgruppe.dias.domain.VDiasArtikel;
import eu.wittgruppe.dias.service.DiasService;
import eu.wittgruppe.dias.ui.*;
import eu.wittgruppe.dias.util.Constants;
import eu.wittgruppe.dias.util.Images;
import eu.wittgruppe.dias.util.StringUtilities;
import eu.wittgruppe.dias.util.printer.ValentinEtikettRenderer;
import eu.wittgruppe.dias.util.printer.ValentinLagerplatzEtikett;
import eu.wittgruppe.dias.util.printer.ValentinLagerplatzEtikettRenderer;
import eu.wittgruppe.dias.util.printer.ValentinPrinter2;
import eu.wittgruppe.enumerations.PoolType;
import foxtrot.Job;
import foxtrot.Worker;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.json.JSONObject;
import purejavacomm.NoSuchPortException;
import purejavacomm.PortInUseException;
import purejavacomm.SerialPort;
import purejavacomm.UnsupportedCommOperationException;
import witt.josef.infrastructure.Message;
import witt.josef.peripheral.SerialConnector;
import witt.josef.uiswing.ui.ErrorDialog;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

@Slf4j
public class ArtikelSearchController {

    private static final String METERWARE = "1";

    private ArtikelSearchPanel artikelSearchPanel = null;

    private MainWindowController parentController = null;

    private Collection<VDiasArtikel> searchedArtikel = null;

    private Vector startPageIndex = null;

    private String aktArtGr = null;

    private int aktPage;

    private long searchIdentKz;

    public DiasService getDiasService() {
        return parentController.getDiasService();
    }

    public ArtikelSearchController( MainWindowController parentController ) {
        this.parentController = parentController;
        artikelSearchPanel = new ArtikelSearchPanel( this );
    }

    public ArtikelSearchPanel getArtikelSearchPanel() {
        return artikelSearchPanel;
    }

    public void setArtikelSearchPanel( ArtikelSearchPanel panel ) {
        this.artikelSearchPanel = panel;
    }

    public MainWindowController getParentController() {
        return parentController;
    }

    public void setParentController( MainWindowController parentController ) {
        this.parentController = parentController;
    }

    public void runRetab( String artNr, String artGr ) {

        JSONObject jsonObject = new JSONObject();

        try {
            jsonObject.put( "artnr", artNr );
            jsonObject.put( "artgr", artGr );
        } catch( Exception e ) {

            log.error( "Fehler beim Erzeugen des JSON-Objekts:", e );
        }

        getParentController().getDefaultApplication().sendMessage( new Message( "RETAB", "DIAS", 1, jsonObject.toString() ) );
    }

    public void searchArtikel( final String lkz, final String artgr, final String farbeId, final String merkmalKlasse, final String marktKz, final long identkz ) {

        WaitView waitView = beforeSearchArtikel();
        setSearchIdentKz( identkz );
        searchedArtikel = ( Collection )Worker.post( new Job() {

            @Override
            public Object run() {

                Collection artikel = null;
                artikel = getDiasService().sucheArtikel( lkz, artgr, farbeId, merkmalKlasse, marktKz );
                return artikel;
            }
        }

        );

        afterSearchArtikel( waitView );
    }

    public void searchArtikel( final String artnr, final Boolean isCrs, long identkz ) {

        WaitView waitView = beforeSearchArtikel();
        // Suchidentkz merken, wird beim Drucken wieder abgefragt
        setSearchIdentKz( identkz );
        searchedArtikel = ( Collection )Worker.post( new Job() {

            @Override
            public Object run() {

                Collection artikel = null;

                artikel = getDiasService().sucheArtikel( artnr, isCrs );
                return artikel;
            }
        }

        );

        afterSearchArtikel( waitView );
    }

    private void afterSearchArtikel( WaitView waitView ) {
        int anzArtikel = 0;

        if( searchedArtikel != null && searchedArtikel.size() > 0 ) {
            // Vector mit Indexwerten erzeugen
            startPageIndex = createPageStartArtikelposIndex( searchedArtikel );

            setAktPage( getFirstPage() );

            createArtikelPanels( searchedArtikel, getAktPage() );

            anzArtikel = searchedArtikel.size();
        }

        // Anzahl der gefunden Positionen setzen
        parentController.getMainWindow().setStatusTextLeft( Integer.toString( anzArtikel ) + " Positionen gefunden" );

        waitView.setVisible( false );

        artikelSearchPanel.getCenterPanel().repaint();
        artikelSearchPanel.getCenterPanel().revalidate();
    }

    private WaitView beforeSearchArtikel() {

        parentController.getMainWindow().setStatusTextLeft( "suche..." );

        WaitView waitView = new WaitView( parentController.getMainWindow() );
        UIUtils.centerOverComponent( parentController.getMainWindow(), waitView );

        waitView.setVisible( true );

        clearArtikelPanel();
        clearNavigatorPanel();
        return waitView;
    }

    public void createArtikelPanels( final Collection artikelCol, final int pageNr ) {

        final WaitView waitView = new WaitView( getParentController().getMainWindow() );
        UIUtils.centerOverComponent( getParentController().getMainWindow(), waitView );

        waitView.setVisible( true );

        final String aktArtGr = this.aktArtGr;

        Thread workerThread = new Thread() {

            @Override
            public void run() {

                // Wurden Artikel gefunden
                if( artikelCol != null ) {

                    clearArtikelPanel();

                    int indexBegin;
                    int indexEnd;

                    // erste Seite Startpos bei 0
                    if( pageNr == getFirstPage() ) {
                        indexBegin = 0;
                    }
                    // ansonsten ist die Startposition die Seite vorher + 1
                    else {
                        indexBegin = ( ( Integer )startPageIndex.get( pageNr - 2 ) ).intValue() + 1;
                    }

                    // Start Artikelposition aus dem IndexVektor zur übergebenen
                    // Seite
                    // holen
                    // -1 da Seite Im Array mit 0 beginnt
                    indexEnd = ( ( Integer )startPageIndex.get( pageNr - 1 ) ).intValue();

                    // Aus dem aritkelCol einen Vector machen um nicht den ganzen Code umstellung zu müssen
                    Collection subArtikelVector = new Vector();
                    Iterator iterArtikelCol = artikelCol.iterator();
                    while( iterArtikelCol.hasNext() ) {
                        subArtikelVector.add( iterArtikelCol.next() );
                    }

                    // Artikel die angezeigt werden sollen aus dem Array
                    // ausschneiden
                    Collection subArtikel = ( ( Vector )subArtikelVector ).subList( indexBegin, indexEnd + 1 );

                    Long artnr6Sav = null;
                    Long saisonSav = null;
                    int posIndex = 0;
                    ArtikelPanel artikelPanel = null;

                    Vector vecSubArtikel = new Vector( subArtikel );

                    try {
                        VDiasArtikel artikel = ( VDiasArtikel )( vecSubArtikel.firstElement() );

                        // solange Artikel vorhanden
                        while( posIndex < vecSubArtikel.size() ) {
                            // Gruppenwechselkriterium merken
                            artnr6Sav = artikel.getArtikelnummerWitt();
                            saisonSav = artikel.getSaison();
                            Vector vecLieferanten = new Vector();
                            Vector vecMvgr = new Vector();

                            // vor dem Gruppenwechsel
                            artikelPanel = createArtikelPanel( artikel, parentController.getDruckerVorhanden() );
                            artikelSearchPanel.getCenterPanel().add( artikelPanel );

                            // solange gleicher Artikel in einer Saison
                            while( artnr6Sav.longValue() == artikel.getArtikelnummerWitt().longValue() && saisonSav.longValue() == artikel.getSaison().longValue() && posIndex < vecSubArtikel.size() ) {
                                //System.out.println( "groesse: " + artikel.getModellvariantengroesse() );
                                // es kann mehreres Lieferanten zu einem Artikel
                                // geben,
                                // Lieferanten
                                // merken die es gibt
                                if( !vecLieferanten.contains( artikel.getLieferantennummer() + " " + artikel.getLieferantenname() ) ) {

                                    vecLieferanten.add( artikel.getLieferantennummer() + " " + artikel.getLieferantenname() );
                                }
                                // wenn es mehrere Lieferanten gibt, kommen
                                // mehrere
                                // gleiche Größen zurück
                                // eindeutige Größen merken
                                if( !vecMvgr.contains( artikel.getModellvariantengroesse() ) ) {

                                    vecMvgr.add( artikel.getModellvariantengroesse() );
                                }

                                posIndex++;
                                // ArrayIndexOutOfBoundsException vermeiden
                                if( posIndex < vecSubArtikel.size() ) {
                                    artikel = ( VDiasArtikel )vecSubArtikel.get( posIndex );
                                }
                            }

                            // alle ermittelten Größen in Combobox aufnehmen
                            for( Iterator iter = vecMvgr.iterator(); iter.hasNext(); ) {
                                String mvgr = ( String )iter.next();
                                artikelPanel.getArtgrComboBox().addItem( mvgr );
                            }
                            // alle ermittelten Lieferanten in Combobox
                            // aufnehmen
                            for( Iterator iter = vecLieferanten.iterator(); iter.hasNext(); ) {
                                String lieferant = ( String )iter.next();
                                artikelPanel.getLieferantenComboBox().addItem( lieferant );
                            }

                            // Workaraound um die richtige Größe bei Rechnungen
                            // anzuzeigen
                            if( aktArtGr != null )
                                artikelPanel.getArtgrComboBox().setSelectedItem( aktArtGr );
                        }
                    } catch( ArrayIndexOutOfBoundsException e ) {
                        log.error( "Fehler beim erzeugen der ArtikelPanels", e );
                    }
                }

                waitView.setVisible( false );
            }
        };
        workerThread.start();
    }

    public ArrayList<ErsatzartikelBean> getErsatzartikel(String artnr6, String artgr, String saison ) {

        ArrayList<ErsatzartikelBean> ersatzartikel = null;

        try {
            ersatzartikel = new ArrayList<ErsatzartikelBean>();

            // Aktuellen Ersatzartikel laden...
            ErsatzartikelBean ersArtikel = getDiasService().getErsatzartikel( artnr6, artgr, saison );

            if( ersArtikel.getArtikelnummer() != null )
                ersatzartikel.add( ersArtikel );

            return ersatzartikel;

        } catch( Exception e ) {
            log.debug( "Fehler beim Laden der Ersatzartikel", e );

            new ErrorDialog( getParentController().getMainWindow(), "DIAS", true, e, "", true ).setVisible( true );

            // Einfach leere ArrayList zurückliefern
            return new ArrayList<ErsatzartikelBean>();
        }
    }

    public ArtikelPanel createArtikelPanel( final VDiasArtikel artikel, final Boolean durckerVorhanden ) {

        ArrayList<ErsatzartikelBean> ersatzartikel = getErsatzartikel( artikel.getArtikelnummerWitt().toString(), artikel.getModellvariantengroesse(), artikel.getSaison().toString() );

        final ArtikelPanel artikelPanel = new ArtikelPanel( this, artikel, durckerVorhanden, ersatzartikel );
        artikelPanel.getBildLabel().setIcon( Images.WAIT );

        // Holen der Artikelbilder in einem eigenen Thread auslagern
        // und wait beim Artikelbild anzeigen
        Thread t = new Thread() {

            @Override
            public void run() {
                byte[] bild = null;

                // Artikel selektieren und im Controller merken
                bild = getDiasService().getBild( artikel.getModellvariantennummer() );

                if( bild != null ) {
                    ImageIcon icon = scalePicture( artikelPanel.getBildLabel().getPreferredSize(), bild );
                    artikelPanel.getBildLabel().setIcon( icon );
                } else {
                    artikelPanel.getBildLabel().setText( "kein Bild" );
                    artikelPanel.getBildLabel().setIcon( null );
                }
            }
        };

        t.setDaemon( true );
        t.setPriority( Thread.MAX_PRIORITY );
        t.start();

        return artikelPanel;
    }

    public ImageIcon scalePicture( Dimension rec, byte[] bild ) {

        // Größe des akutellen Bildes ermitteln
        ImageIcon icon = new ImageIcon( bild );
        double iconHeight = icon.getIconHeight();
        double iconWidth = icon.getIconWidth();

        // Größe der sichtbaren Fläche ermitteln
        // double viewHeight =
        // panel.getBildLabel().getPreferredSize().getHeight() ;
        // double viewWidth = panel.getBildLabel().getPreferredSize().getWidth()
        // ;

        double viewHeight = rec.getHeight();
        double viewWidth = rec.getWidth();

        double scaleHFactor = viewHeight / iconHeight;
        double scaleWFactor = viewWidth / iconWidth;

        iconHeight *= scaleHFactor < scaleWFactor ? scaleHFactor : scaleWFactor;
        iconWidth *= scaleHFactor < scaleWFactor ? scaleHFactor : scaleWFactor;
        ;

        // Bild umrechnen
        Image image = icon.getImage();
        image = image.getScaledInstance( ( int )iconWidth, ( int )iconHeight, Image.SCALE_DEFAULT );
        icon.setImage( image );

        return icon;
    }

    private void clearNavigatorPanel() {

        artikelSearchPanel.getPageNumberPanel().removeAll();

        artikelSearchPanel.getPageNumberPanel().repaint();
        artikelSearchPanel.getPageNumberPanel().revalidate();

    }

    private void clearArtikelPanel() {

        artikelSearchPanel.getCenterPanel().removeAll();
        artikelSearchPanel.getCenterPanel().repaint();
        artikelSearchPanel.getCenterPanel().revalidate();
    }

    private Vector createPageStartArtikelposIndex( Collection searchedArtikelCol ) {

        Vector pageIndex = null;

        // Aus dem aritkelCol einen Vector machen um nicht den ganzen Code umstellung zu müssen
        Collection searchedArtikel = new Vector();
        Iterator iterArtikelCol = searchedArtikelCol.iterator();
        while( iterArtikelCol.hasNext() ) {
            searchedArtikel.add( iterArtikelCol.next() );
        }

        if( searchedArtikel != null && searchedArtikel.size() > 0 ) {

            pageIndex = new Vector();
            int anzArtikel = 0;
            int index = 0;
            int page = 0;

            clearNavigatorPanel();
            artikelSearchPanel.createNavigationArrows();

            try {

                Vector vecArtikel = ( Vector )searchedArtikel;
                VDiasArtikel artikel = ( VDiasArtikel )( vecArtikel.firstElement() );
                // solange Artikel vorhanden
                while( index < vecArtikel.size() ) {
                    // Gruppenwechselkriterium merken
                    Long artnr6Sav = artikel.getArtikelnummerWitt();
                    Long saisonSav = artikel.getSaison();
                    // solange gleicher Artikel
                    while( artnr6Sav.longValue() == artikel.getArtikelnummerWitt().longValue() && saisonSav.longValue() == artikel.getSaison().longValue() && index < vecArtikel.size() ) {

                        index++;
                        if( index < vecArtikel.size() ) {
                            artikel = ( VDiasArtikel )vecArtikel.get( index );
                        }
                    }
                    anzArtikel++;
                    // Seitenumbruch
                    if( anzArtikel >= Constants.PAGE_SIZE ) {

                        anzArtikel = 0;
                        // - 1 weil nach dem Gruppenwechsel
                        pageIndex.add( page, new Integer( index - 1 ) );
                        page++;

                        // PageNummer im ArtikelSearchPanel erzeugen
                        artikelSearchPanel.setPageNumber( page );
                    }
                }

                // letzte Seite hinzufügen falls AnzahlArtikel < Page_size
                // if ( vecArtikel.size()%Constants.PAGE_SIZE != 0) {
                if( anzArtikel > 0 ) {

                    pageIndex.add( page, new Integer( vecArtikel.lastIndexOf( vecArtikel.lastElement() ) ) );
                    page++;
                    artikelSearchPanel.setPageNumber( page );
                }

            } catch( ArrayIndexOutOfBoundsException e ) {
                log.error( "Fehler beim Erzeugen des IndexVectors", e );
            }
        }

        artikelSearchPanel.getPageNumberPanel().repaint();
        artikelSearchPanel.getPageNumberPanel().revalidate();

        return pageIndex;
    }

    public Collection getSearchedArtikel() {
        return searchedArtikel;
    }

    public void setSearchedArtikel( Collection searchedArtikel ) {
        this.searchedArtikel = searchedArtikel;
    }

    public int getFirstPage() {
        // + 1 da Array bei 0 beginnt und die richtige Seite zurückgegeben wird
        return startPageIndex.indexOf( startPageIndex.firstElement() ) + 1;

    }

    public int getLastPage() {

        return startPageIndex.indexOf( startPageIndex.lastElement() ) + 1;
    }

    public int getPrevPage( int page ) {

        int prevPage;

        if( page == getFirstPage() ) {
            prevPage = getLastPage();
        } else {
            prevPage = page - 1;
        }
        return prevPage;
    }

    public int getNextPage( int page ) {

        int nextPage;

        if( page == getLastPage() ) {
            nextPage = getFirstPage();
        } else {
            nextPage = page + 1;
        }
        return nextPage;
    }

    public void resetPageLabelColor( JPanel pageNoPanel ) {

        Component[] pageNoLabels = pageNoPanel.getComponents();

        for( int i = 0; i < pageNoLabels.length; i++ ) {
            Component component = pageNoLabels[i];

            if( component instanceof JLabel ) {
                ( ( JLabel )component ).setForeground( Color.BLUE );
            }
        }
    }

    public int getAktPage() {
        return aktPage;
    }

    public void setAktPage( int aktPageNr ) {
        this.aktPage = aktPageNr;
        setPageNoLabelClicked( artikelSearchPanel.getPageNumberPanel(), aktPageNr );

    }

    public void setPageNoLabelClicked( JPanel pageNoPanel, int page ) {

        // Alle PageNr Labels auf blau setzen
        resetPageLabelColor( pageNoPanel );

        Component[] pageNoLabels = pageNoPanel.getComponents();

        for( int i = 0; i < pageNoLabels.length; i++ ) {
            Component component = pageNoLabels[i];

            if( component instanceof JLabel ) {
                JLabel label = ( JLabel )component;

                if( label.getToolTipText() != null && label.getToolTipText().equals( Integer.toString( page ) ) ) {

                    label.setForeground( new Color( 204, 0, 255 ) );
                }
            }
        }
    }

    public void openKatalogSeite( final Long saison, final Long mvnr, final Long artnr6 ) {

        WaitView waitView = new WaitView( parentController.getMainWindow() );
        UIUtils.centerOverComponent( parentController.getMainWindow(), waitView );

        waitView.setVisible( true );

        KatalogseiteBean seiteBean = ( KatalogseiteBean )Worker.post(new Job() {

            @Override
            public Object run() {

                byte[] seiteBlob = null;
                KatalogseiteBean seite = null;

                // Cas für CenteraZugriff mit Abb und Seite selektieren
                // als erstes deutsche Seiten
                seite = getDiasService().getKatalogSeiteCas( saison, mvnr, "DE" );
                // nichts gefunden erneut suchen, Sprache egal
                if( seite == null ) {
                    seite = getDiasService().getKatalogSeiteCas( saison, mvnr, null );
                }
                // definitv keine Seite vorhanden
                if( seite == null ) {
                    JOptionPane.showMessageDialog( artikelSearchPanel, "Keine Katalogseite gefunden!", "Katalogseitensuche", JOptionPane.INFORMATION_MESSAGE );
                } else {

                    log.debug( "Zugriff auf Centera mit cas: " + seite.getCenteraID() );

                    CenteraOperations centera = parentController.getMedienRestClient().centera();
                    CenteraClipReadBean read = centera.getFile( seite.getCenteraID(), PoolType.CATALOG_PRODUCTION );

                    if( read != null ) {
                        seiteBlob = read.getContent();
                    }

                    // Katalogseite anzeigen Parentcontroller, SeitenBean
                    // und Bild übergeben
                    new KatalogSeiteDialogController( ArtikelSearchController.this, seite, seiteBlob, artnr6 ).showDialog();

                }

                return seite;
            }
        } );
        waitView.setVisible( false );
    }

    public void print( VDiasArtikel artikel ) {

        SerialPort serialPort = null;
        try {
            // Serielle Schnittstelle holen
            serialPort = getSerialPort();

            // aus der Tabelle gr_artst retsortkz und bestfirmkz holen
            GroessenArtikelstamm grArtsta = getDiasService().sucheGroesseArtsta( artikel.getArtikelnummerWitt(), StringUtils.remove( artikel.getModellvariantengroesse(), "," ) );
            // Lagerort für LPE holen
            String koord = getDiasService().sucheLagerkoordinate( artikel.getArtikelnummerWitt(), StringUtils.remove( artikel.getModellvariantengroesse(), "," ) );
            // mgeinh holen um festzustellen ob meterware

            if( koord != null ) {
                koord = getDiasService().formatLagerKoord( koord );
            }
            Long mengeCm = new Long( 0 );
            if( artikel.getMengeneinheit() != null && artikel.getMengeneinheit().equals( METERWARE ) ) {
                MengeInputDialog inputMenge = new MengeInputDialog( parentController.getMainWindow() );
                inputMenge.showDialog();
                mengeCm = inputMenge.getMenge();
            }
            if( mengeCm == null ) {
                return;
            }
            String bestfirmBez = "??";
            String retSortKz = "?";
            if( grArtsta != null ) {
                retSortKz = grArtsta.getRetouresortkennzeichen().toString();
                // Firmenkurzbezeichnung aus tabelle bestandsfirma selekterien
                Bestandsfirma bestFirma = getDiasService().sucheBestandsFirma( grArtsta.getBestandsfirma().getKennzeichen().intValue() );
                bestfirmBez = bestFirma.getFirmenKurzbezeichnung2();
            }

            // SerialConnector.enableFlowControlModeXonXoffOut(serialPort);
            ValentinLagerplatzEtikett etikett = new ValentinLagerplatzEtikett( StringUtilities.spreadCharacters( artikel.getArtikelbezeichnung().toUpperCase() ), StringUtilities.spreadCharacters( artikel.getFarbe() != null ? artikel.getFarbe()
                    .toUpperCase() : "KEINE FARBE" ), StringUtils.remove( artikel.getModellvariantengroesse(), "," ), retSortKz, bestfirmBez, artikel.getArtikelnummerWitt(), getParentController().getActiveUserBedienernummer(), koord, mengeCm );
            // Drucker mit seriellen Port verbinden

            ValentinPrinter2 printer = new ValentinPrinter2( serialPort );
            printer.print( etikett, (ValentinEtikettRenderer)new ValentinLagerplatzEtikettRenderer() );
            // - Statistikeintrag machen
            getDiasService().insertDiasStatistik( null, artikel.getArtikelnummerWitt(), artikel.getModellvariantengroesse(), getSearchIdentKz(), getParentController().getActiveUserNDS() );
        } catch( NoSuchPortException e ) {
            log.error( "Serieller Port nicht gefunden", e );
        } catch( PortInUseException e ) {
            log.error( "Serieller Port ist in Gebrauch", e );
        } catch( UnsupportedCommOperationException e ) {
            log.error( "Nicht unterstützes Kommando auf seriellen Port", e );
        } catch( IOException e ) {
            log.error( "Fehler beim Input/Output auf seriellen Port", e );
        } finally {
            if( serialPort != null ) {
                serialPort.close();
            }
        }
    }

    private SerialPort getSerialPort() throws UnsupportedCommOperationException, NoSuchPortException, PortInUseException {

        String dvNummer = System.getenv( "DVNR" );
        // Parameterverwaltungseinstellungen zur Station holen
        Collection parameters = getDiasService().sucheParameter( dvNummer );

        // Default Parameter
        int bitRate = 38400;
        int dataBits = SerialPort.DATABITS_8;
        int stopBits = SerialPort.STOPBITS_1;
        int parity = SerialPort.PARITY_NONE;
        String portName = null;
        // Parameter auslesen und setzen
        for( Iterator iter = parameters.iterator(); iter.hasNext(); ) {
            Parameterverwaltung param = ( Parameterverwaltung )iter.next();

            if( param.getParameterverwaltungPK().getBezeichnung().equalsIgnoreCase( Constants.PARAM_BITRATE ) ) {
                bitRate = NumberUtils.toInt( param.getWert() );
            } else if( param.getParameterverwaltungPK().getBezeichnung().equalsIgnoreCase( Constants.PARAM_DATABITS ) ) {
                dataBits = NumberUtils.toInt( param.getWert() );
            } else if( param.getParameterverwaltungPK().getBezeichnung().equalsIgnoreCase( Constants.PARAM_STOPBITS ) ) {
                stopBits = NumberUtils.toInt( param.getWert() );
            } else if( param.getParameterverwaltungPK().getBezeichnung().equalsIgnoreCase( Constants.PARAM_PORT ) ) {
                portName = param.getWert();
            } else if( param.getParameterverwaltungPK().getBezeichnung().equalsIgnoreCase( Constants.PARAM_PARITAET ) ) {
                if( param.getWert().equalsIgnoreCase( "N" ) ) {
                    parity = SerialPort.PARITY_NONE;
                }
            }
        }

        // Serielle Schnitstelle anfordern und Einstellung setzen timeout 2000
        // ms
        SerialPort serialPort = SerialConnector.getSerialPort( portName, Constants.PARAM_PROGNAME, 2000 );

        SerialConnector.setSerialPortParams( serialPort, bitRate, dataBits, stopBits, parity );

        return serialPort;
    }

    public void showArtikelSearchDialog() {

        ArtikelSearchPanel searchPanel = getArtikelSearchPanel();
        final ArtikelSearchCriteriaPanel criteriaPanel = new ArtikelSearchCriteriaPanel( this );
        searchPanel.setSearchPanel( criteriaPanel );

        parentController.getMainWindow().setStatusTextLeft( "" );
        final JInternalFrame artikelSearchFrame = parentController.getMainWindow().addMDIWindow( searchPanel, "Artikelsuche", true, true, true, true, null, 0, 0 );
        artikelSearchFrame.setFrameIcon( Images.ARTIKEL_SEARCH );

        SwingUtilities.invokeLater( new Runnable() {
            @Override
            public void run() {
                criteriaPanel.getLkzTextField().selectAll();
                criteriaPanel.getLkzTextField().requestFocus();
                try {
                    artikelSearchFrame.setMaximum( true );
                } catch( Exception e ) {
                    log.error( "Fehler beim Maximieren des ArtikelSearchDialogs", e );
                }
            }
        } );
    }

    public void showCrsArtikelSearchDialog() {

        ArtikelSearchPanel searchPanel = getArtikelSearchPanel();
        ArtikelCRSSearchCriteriaPanel criteriaPanel = new ArtikelCRSSearchCriteriaPanel( this );
        searchPanel.setSearchPanel( criteriaPanel );

        parentController.getMainWindow().setStatusTextLeft( "" );
        final JInternalFrame artikelSearchFrame = parentController.getMainWindow().addMDIWindow( searchPanel, "Artikelsuche/CRS", true, true, true, true, null, 0, 0 );
        try {
            artikelSearchFrame.setMaximum( true );
        } catch( Exception e ) {
            log.error( "Fehler beim Maximieren des ArtikelSearchDialogs", e );
        }

        criteriaPanel.getArtnrTextField().requestFocus();
        artikelSearchFrame.setFrameIcon( Images.CRS_SEARCH );
        SwingUtilities.invokeLater( new Runnable() {
            @Override
            public void run() {
                try {
                    artikelSearchFrame.setMaximum( true );
                } catch( Exception e ) {
                    log.error( "Fehler beim Maximieren des ArtikelSearchDialogs", e );
                }
            }
        } );
    }

    public void showArtikelSearchDialog( Long artnr6, String artikelGroesse, long identkz ) {

        this.aktArtGr = artikelGroesse;

        // Suchpanel in dem Suchergebnisse angezeigt werden holen
        ArtikelSearchPanel searchPanel = getArtikelSearchPanel();
        // Suchpanel mit Kriterienpanel bestücken
        ArtikelCRSSearchCriteriaPanel criteriaPanel = new ArtikelCRSSearchCriteriaPanel( this );
        // Als Kriterium Artikelnummer setzen
        criteriaPanel.getArtnrTextField().setText( artnr6.toString() );
        searchPanel.setSearchPanel( criteriaPanel );
        // nach der übergebenen Artikel suchen
        this.searchArtikel( artnr6.toString(), new Boolean( criteriaPanel.getCrsCheckBox().isSelected() ), identkz );

        parentController.getMainWindow().setStatusTextLeft( "" );
        final JInternalFrame artikelSearchFrame = parentController.getMainWindow().addMDIWindow( searchPanel, "Artikelsuche/CRS", true, true, true, true, null, 0, 0 );
        criteriaPanel.getArtnrTextField().requestFocus();
        artikelSearchFrame.setFrameIcon( Images.CRS_SEARCH );
        SwingUtilities.invokeLater( new Runnable() {
            @Override
            public void run() {
                try {
                    artikelSearchFrame.setMaximum( true );
                } catch( Exception e ) {
                    log.error( "Fehler beim Maximieren des CRSArtikelSearchDialog", e );
                }
            }
        } );

        this.aktArtGr = null;
    }

    public long getSearchIdentKz() {
        return searchIdentKz;
    }

    public void setSearchIdentKz( long searchIdentKz ) {
        this.searchIdentKz = searchIdentKz;
    }
}

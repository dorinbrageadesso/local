package eu.wittgruppe.dias.ui;

import eu.wittgruppe.dias.domain.Kundenfirma;
import witt.josef.uiswing.ui.ComboBoxBean;

import javax.swing.*;
import java.awt.*;
import java.util.Collection;
import java.util.Iterator;

public class KundenFirmaChooserDialog extends JDialog {

	private JPanel jContentPane = null;
	private JPanel centerPanel = null;
	private JComboBox kundenfirmaComboBox = null;
	private JButton okButton = null;
	private JButton cancelButton = null;
	private Kundenfirma selectedKundenfirma = null;
	private JFrame parent = null;
	
	public Kundenfirma getSelectedKundenfirma() {
		return selectedKundenfirma;
	}

	

	 
	public KundenFirmaChooserDialog(JFrame parent, Collection kundenFirmen) {
		super(parent);
		this.parent = parent;
		initialize();
		
		for (Iterator iter = kundenFirmen.iterator(); iter.hasNext();) {
			Kundenfirma firma = (Kundenfirma) iter.next();
			ComboBoxBean boxBean = new ComboBoxBean(firma.getKundenfirmenKennzeichen().intValue() + " " +
													firma.getBezeichnung(),
													firma);
			getKundenfirmaComboBox().addItem(boxBean);
		}
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(324, 113);
		this.setTitle("Kundenfirma auswählen");
		this.setModal(true);
		this.setContentPane(getJContentPane());
		UIUtils.centerOverComponent(parent, this);
		
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getCenterPanel(), java.awt.BorderLayout.CENTER);
		}
		return jContentPane;
	}

	/**
	 * This method initializes centerPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getCenterPanel() {
		if (centerPanel == null) {
			GridBagConstraints gridBagConstraints2 = new GridBagConstraints();
			gridBagConstraints2.gridx = 1;
			gridBagConstraints2.insets = new java.awt.Insets(2,5,0,5);
			gridBagConstraints2.gridy = 1;
			GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
			gridBagConstraints1.gridx = 1;
			gridBagConstraints1.insets = new java.awt.Insets(0,5,0,5);
			gridBagConstraints1.gridy = 0;
			GridBagConstraints gridBagConstraints = new GridBagConstraints();
			gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
			gridBagConstraints.gridy = 0;
			gridBagConstraints.weightx = 1.0;
			gridBagConstraints.gridheight = 2;
			gridBagConstraints.insets = new java.awt.Insets(0,5,0,0);
			gridBagConstraints.gridx = 0;
			centerPanel = new JPanel();
			centerPanel.setLayout(new GridBagLayout());
			centerPanel.add(getKundenfirmaComboBox(), gridBagConstraints);
			centerPanel.add(getOkButton(), gridBagConstraints1);
			centerPanel.add(getCancelButton(), gridBagConstraints2);
		}
		return centerPanel;
	}

	/**
	 * This method initializes jComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getKundenfirmaComboBox() {
		if (kundenfirmaComboBox == null) {
			kundenfirmaComboBox = new JComboBox();
		}
		return kundenfirmaComboBox;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getOkButton() {
		if (okButton == null) {
			okButton = new JButton();
			okButton.setPreferredSize(new java.awt.Dimension(100,26));
			okButton.setMaximumSize(new java.awt.Dimension(100,26));
			okButton.setText("OK");
			okButton.setMinimumSize(new java.awt.Dimension(100,26));
			okButton.addActionListener(new OnOkButton());
		}
		return okButton;
	}

	/**
	 * This method initializes jButton1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getCancelButton() {
		if (cancelButton == null) {
			cancelButton = new JButton();
			cancelButton.setMaximumSize(new java.awt.Dimension(100,26));
			cancelButton.setPreferredSize(new java.awt.Dimension(100,26));
			cancelButton.setText("Abbrechen");
			cancelButton.setMinimumSize(new java.awt.Dimension(100,26));
			cancelButton.addActionListener(new OnCancelButton());
		}
		return cancelButton;
	}
	
	
	// L I S T E N E R S
	private class OnOkButton implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			selectedKundenfirma = (Kundenfirma)((ComboBoxBean)getKundenfirmaComboBox()
										.getSelectedItem()).getValue();
			KundenFirmaChooserDialog.this.setVisible(false);
		}
	};
	
	private class OnCancelButton implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			KundenFirmaChooserDialog.this.setVisible(false);
		}
	};

}  //  @jve:decl-index=0:visual-constraint="10,10"

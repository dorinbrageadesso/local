# DIAS 
<img alt="DIAS Logo" height="100" src="src/main/resources/gfx/dias_splash_klein.gif">

## Documentation
Official technical documentation to be found in [Confluence](https://confluence.witt-gruppe.eu/display/PROD/DIAS). 

## Development
On Praxis Witt-Toolbar, DIAS currently runs on OpenJDK 17 (see ``.gitlab-ci.yml``).
As Language Level is devined in Maven (pom.xml), it should be safe to use a higher OpenJDK Version locally.

### Startup configuration
Define a Run Config of type Application with Main Class ``eu.wittgruppe.dias.Dias``.
No command line arguments are needed.

#### JVM Parameters
Keystore: Refer to your local version of the ``wittcacerts`` 
(original to be found in \\witt-ad.wittgruppe.eu\vol1\JavaRuntime\ca-bundle, in Citrix defined as F-Drive).

Active Profile / Josef-Instance: Specify an environment, check ``application-[environment].yml`` files 
in resources-folder.

Example of a full working set of JVM Parameters:
```
-Djavax.net.ssl.trustStore=C:\\path\\to\\wittcacerts
-Dspring.profiles.active=test
-DdevelopmentMode=true
-Dlog4j.debug=true
-Djosef.instance.name=test
-Dspring.datasource.username=Your-UDB-Userame
-Dspring.datasource.password=Your-UDB-Password
-Dspring.jpa.show-sql=true
-Dcore.medien.auth.username=CORE-MEDIEN-REST
-Dcore.medien.auth.password=4fb12ab74dc451bf9830ae37a162ee2f
-Dcore.benutzer.auth.username=CORE-BENUTZER-REST
-Dcore.benutzer.auth.password=26cc2d1b896be2c9b1e8a131f267f240
-Dservicelocator.scope=test
-Xmx512m
-Dspring.main.allow-bean-definition-overriding=true
-Dspring.main.allow-circular-references=true
--add-opens=java.base/java.lang=ALL-UNNAMED
--add-opens=java.base/java.lang.reflect=ALL-UNNAMED
--add-opens=java.base/java.io=ALL-UNNAMED
--add-opens=java.desktop/java.awt=ALL-UNNAMED
--add-exports=java.base/sun.nio.ch=ALL-UNNAMED
--add-exports=jdk.unsupported/sun.misc=ALL-UNNAMED
--add-exports=jdk.unsupported/sun.awt=ALL-UNNAMED
--add-exports=java.desktop/java.awt=ALL-UNNAMED
```
